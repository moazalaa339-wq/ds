Game.defineParams([
  {key:'seed',label:'رقم المدينة (seed) - يغير التوزيع كله',type:'number',value:7,min:1,max:9999,step:1},
  {key:'blocksX',label:'عدد البلوكات عرض (زوجي أحسن)',type:'number',value:4,min:2,max:8,step:1},
  {key:'blocksZ',label:'عدد البلوكات طول (زوجي أحسن)',type:'number',value:4,min:2,max:8,step:1},
  {key:'blockSize',label:'حجم البلوك',type:'number',value:44,min:30,max:80,step:1},
  {key:'streetWidth',label:'عرض الشارع',type:'number',value:12,min:8,max:24,step:1},
  {key:'sidewalkWidth',label:'عرض الرصيف',type:'number',value:3,min:1.5,max:6,step:0.5},
  {key:'curbHeight',label:'ارتفاع الرصيف',type:'number',value:0.08,min:0.02,max:0.4,step:0.01},
  {key:'lotDepth',label:'عمق العمارة',type:'number',value:10,min:6,max:16,step:1},
  {key:'lotWidth',label:'متوسط عرض العمارة',type:'number',value:11,min:7,max:18,step:1},
  {key:'minFloors',label:'أقل عدد أدوار',type:'number',value:3,min:2,max:12,step:1},
  {key:'maxFloors',label:'أكبر عدد أدوار',type:'number',value:8,min:3,max:14,step:1},
  {key:'floorHeight',label:'ارتفاع الدور',type:'number',value:3.1,min:2.6,max:4,step:0.1},
  {key:'shopHeight',label:'ارتفاع الدور الأرضي (محلات)',type:'number',value:4.2,min:3,max:6,step:0.1},
  {key:'facadeVariants',label:'تنوع الواجهات',type:'number',value:4,min:1,max:10,step:1},
  {key:'windowLitChance',label:'نسبة الشبابيك المنورة',type:'number',value:0.18,min:0,max:1,step:0.01},
  {key:'unfinishedChance',label:'نسبة العمارات اللي حديدها طالع (تحت التشطيب)',type:'number',value:0.3,min:0,max:1,step:0.05},
  {key:'awningChance',label:'نسبة المحلات اللي عليها تندة',type:'number',value:0.5,min:0,max:1,step:0.05},
  {key:'tankChance',label:'نسبة خزانات الميه على الأسطح',type:'number',value:0.7,min:0,max:1,step:0.05},
  {key:'dishChance',label:'نسبة الدش على الأسطح',type:'number',value:0.6,min:0,max:1,step:0.05},
  {key:'marketI',label:'بلوك السوق - رقم العمود',type:'number',value:1,min:0,max:7,step:1},
  {key:'marketJ',label:'بلوك السوق - رقم الصف',type:'number',value:2,min:0,max:7,step:1},
  {key:'mosqueI',label:'بلوك الجامع - رقم العمود',type:'number',value:2,min:0,max:7,step:1},
  {key:'mosqueJ',label:'بلوك الجامع - رقم الصف',type:'number',value:1,min:0,max:7,step:1},
  {key:'plazaI',label:'بلوك الميدان - رقم العمود',type:'number',value:1,min:0,max:7,step:1},
  {key:'plazaJ',label:'بلوك الميدان - رقم الصف',type:'number',value:1,min:0,max:7,step:1},
  {key:'stalls',label:'عدد فرشات السوق',type:'number',value:14,min:0,max:40,step:1},
  {key:'minaretHeight',label:'ارتفاع المئذنة',type:'number',value:30,min:15,max:50,step:1},
  {key:'treeChance',label:'نسبة الشجر على الأرصفة',type:'number',value:0.45,min:0,max:1,step:0.05},
  {key:'lampSpacing',label:'المسافة بين أعمدة النور',type:'number',value:22,min:10,max:40,step:1},
  {key:'poleChance',label:'نسبة أعمدة الكهرباء والأسلاك',type:'number',value:0.7,min:0,max:1,step:0.05},
  {key:'carChance',label:'نسبة العربيات الواقفة',type:'number',value:0.3,min:0,max:1,step:0.05},
  {key:'cafes',label:'عدد القهاوي على الرصيف',type:'number',value:4,min:0,max:20,step:1},
  {key:'npcWalkers',label:'عدد الناس اللي ماشية على الأرصفة',type:'number',value:36,min:0,max:200,step:1},
  {key:'npcShoppers',label:'عدد الناس اللي بتتسوق في السوق',type:'number',value:12,min:0,max:80,step:1},
  {key:'npcSpeed',label:'سرعة مشي الناس',type:'number',value:1.3,min:0.3,max:4,step:0.1},
  {key:'stepLength',label:'طول الخطوة (للأنيميشن)',type:'number',value:0.7,min:0.4,max:1.2,step:0.05},
  {key:'asphaltColor',label:'لون الأسفلت',type:'color',value:'#3b3d40'},
  {key:'lineColor',label:'لون خطوط الشارع',type:'color',value:'#e8e2c8'},
  {key:'sidewalkColor',label:'لون الرصيف',type:'color',value:'#9d9a92'},
  {key:'wallColorA',label:'لون عمارة 1 (بيج)',type:'color',value:'#d9c6a2'},
  {key:'wallColorB',label:'لون عمارة 2 (أصفر باهت)',type:'color',value:'#e3d5a6'},
  {key:'wallColorC',label:'لون عمارة 3 (خرسانة رمادي)',type:'color',value:'#a9a59b'},
  {key:'wallColorD',label:'لون عمارة 4 (وردي باهت)',type:'color',value:'#d4a99a'},
  {key:'brickColor',label:'لون الطوب الأحمر',type:'color',value:'#a4523a'},
  {key:'roofColor',label:'لون الأسطح',type:'color',value:'#6e6a64'},
  {key:'shutterColorA',label:'لون شيش 1',type:'color',value:'#3d6b4a'},
  {key:'shutterColorB',label:'لون شيش 2',type:'color',value:'#7a5230'},
  {key:'shutterColorC',label:'لون شيش 3',type:'color',value:'#2f4f6f'},
  {key:'signColorA',label:'لون يافطة 1',type:'color',value:'#1f6f43'},
  {key:'signColorB',label:'لون يافطة 2',type:'color',value:'#b3261e'},
  {key:'signColorC',label:'لون يافطة 3',type:'color',value:'#1d4f91'},
  {key:'signTextColor',label:'لون كتابة اليافطات',type:'color',value:'#fff6d6'},
  {key:'awnColorA',label:'لون تندة 1',type:'color',value:'#c0392b'},
  {key:'awnColorB',label:'لون تندة 2',type:'color',value:'#2e86c1'},
  {key:'awnColorC',label:'لون تندة 3',type:'color',value:'#d4a017'},
  {key:'woodColor',label:'لون الخشب',type:'color',value:'#6b4a2f'},
  {key:'produceA',label:'لون خضار/فاكهة 1',type:'color',value:'#d62828'},
  {key:'produceB',label:'لون خضار/فاكهة 2',type:'color',value:'#f77f00'},
  {key:'produceC',label:'لون خضار/فاكهة 3',type:'color',value:'#4c9a2a'},
  {key:'produceD',label:'لون خضار/فاكهة 4',type:'color',value:'#f2c94c'},
  {key:'mosqueColor',label:'لون الجامع',type:'color',value:'#e8dcc0'},
  {key:'mosqueStripeColor',label:'لون مدماك الجامع',type:'color',value:'#b5523b'},
  {key:'domeColor',label:'لون القبة',type:'color',value:'#6f8f86'},
  {key:'goldColor',label:'لون الذهبي (الهلال)',type:'color',value:'#d4a72c'},
  {key:'treeLeafColor',label:'لون ورق الشجر',type:'color',value:'#3f7d3a'},
  {key:'trunkColor',label:'لون الجذع',type:'color',value:'#5a3d26'},
  {key:'lampColor',label:'لون عمود النور',type:'color',value:'#3a3d42'},
  {key:'carColorA',label:'لون عربية 1',type:'color',value:'#f0f0f0'},
  {key:'carColorB',label:'لون عربية 2',type:'color',value:'#1e1e22'},
  {key:'carColorC',label:'لون عربية 3',type:'color',value:'#8a2b2b'},
  {key:'carColorD',label:'لون عربية 4',type:'color',value:'#3f6fa8'},
  {key:'skinA',label:'لون بشرة 1',type:'color',value:'#e0ac82'},
  {key:'skinB',label:'لون بشرة 2',type:'color',value:'#c68a5f'},
  {key:'skinC',label:'لون بشرة 3',type:'color',value:'#a56b43'},
  {key:'hairColor',label:'لون الشعر',type:'color',value:'#1e1511'},
  {key:'clothA',label:'لون هدوم 1',type:'color',value:'#c0392b'},
  {key:'clothB',label:'لون هدوم 2',type:'color',value:'#2e86c1'},
  {key:'clothC',label:'لون هدوم 3',type:'color',value:'#f4d03f'},
  {key:'clothD',label:'لون هدوم 4',type:'color',value:'#27ae60'},
  {key:'clothE',label:'لون هدوم 5',type:'color',value:'#7d3c98'},
  {key:'pantsA',label:'لون بنطلون 1',type:'color',value:'#2c3e50'},
  {key:'pantsB',label:'لون بنطلون 2',type:'color',value:'#4b4b4b'},
  {key:'galabeyaA',label:'لون جلابية 1',type:'color',value:'#f1ede2'},
  {key:'galabeyaB',label:'لون جلابية 2',type:'color',value:'#8d9aa5'},
  {key:'galabeyaC',label:'لون جلابية 3',type:'color',value:'#b9a98a'}
]);

const HOST = (typeof root !== 'undefined' && root && typeof root.add === 'function') ? root : null;
let S = null;
let clock = 0;
let failedSig = null;
let solidsDone = false;

function mulberry(seed){
  let a = seed >>> 0;
  return function(){
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function buildCity(P){
  const G = (typeof Game.game === 'object' && Game.game) ? Game.game : {};
  const T = Game.THREE || G.THREE || window.THREE;
  const cands = [['root',HOST],['Game.scene',Game.scene],['Game.root',Game.root],['Game.world',Game.world],['game.scene',G.scene],['camera.parent',Game.camera && Game.camera.parent],['game.camera.parent',G.camera && G.camera.parent]];
  const hit = cands.find(c => c[1] && typeof c[1].add === 'function');
  const scene = hit && hit[1], srcName = hit ? hit[0] : '';
  if(!T) throw new Error('THREE مش موجود: Game.THREE فاضي');
  if(!scene) throw new Error('المشهد مش موجود: Game.scene فاضي');
  const rnd = mulberry(P.seed);
  const R = (a,b) => a + rnd()*(b-a);
  const pick = arr => arr[(rnd()*arr.length)|0];

  const root = new T.Group();
    scene.add(root);
  const ox = (HOST ? HOST.position.x : 0), oy = (HOST ? HOST.position.y : 0), oz = (HOST ? HOST.position.z : 0);
  const solids = [];
  const sol = (x,y,z,w,h,d) => solids.push([x+ox,y+oy,z+oz,w,h,d]);

  const mats = {}, geos = {}, texs = [], facCache = {}, signCache = {};
  const M = (c, ex) => {
    const k = c + (ex ? JSON.stringify(ex) : '');
    return mats[k] || (mats[k] = new T.MeshLambertMaterial(Object.assign({color: new T.Color(c)}, ex || {})));
  };
  const BG = new T.BoxGeometry(1,1,1);
  const CG = (rt,rb,h,s) => { const k='c'+rt+'_'+rb+'_'+h+'_'+s; return geos[k] || (geos[k] = new T.CylinderGeometry(rt,rb,h,s)); };
  const SG = (r) => { const k='s'+r; return geos[k] || (geos[k] = new T.SphereGeometry(r,12,8)); };
  const box = (p,w,h,d,x,y,z,c,ex) => { const m = new T.Mesh(BG, M(c,ex)); m.scale.set(w,h,d); m.position.set(x,y,z); p.add(m); return m; };
  const cyl = (p,rt,rb,h,x,y,z,c,s) => { const m = new T.Mesh(CG(rt,rb,h,s||10), M(c)); m.position.set(x,y,z); p.add(m); return m; };
  const sph = (p,r,x,y,z,c,sy) => { const m = new T.Mesh(SG(r), M(c)); m.position.set(x,y,z); if(sy) m.scale.y = sy; p.add(m); return m; };
  const cvs = (w,h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  const mkTex = c => { const t = new T.CanvasTexture(c); texs.push(t); return t; };

  const cloths = [P.clothA,P.clothB,P.clothC,P.clothD,P.clothE];
  const names = ['صيدلية الأمل','محل النور','سوبر ماركت السلام','كشري التحرير','مكتبة المعرفة','عصير قصب','ورشة الأسطى','بقالة الحاج','موبايلات الشروق','مخبز الفجر','حلواني السعادة','مكوجي الأمانة','قهوة البلد','فول وطعمية','ملابس الفرحة','أدوات كهربائية','جزارة الرحمة','عيادة الدكتور'];

  const bs = P.blockSize, sw = P.sidewalkWidth, ld = P.lotDepth, curb = P.curbHeight;
  const pitch = bs + 2*sw + P.streetWidth;
  const nx = P.blocksX|0, nz = P.blocksZ|0;
  const cxOf = i => (i-(nx-1)/2)*pitch;
  const czOf = j => (j-(nz-1)/2)*pitch;

  // ---------- واجهات العمارات (كانفس) ----------
  const facade = (floors, wall) => {
    const key = floors + wall + ((rnd()*P.facadeVariants)|0);
    if(facCache[key]) return facCache[key];
    const fh = 64, gh = 84, W = 256, H = gh + fh*(floors-1);
    const c = cvs(W,H), g = c.getContext('2d');
    g.fillStyle = wall; g.fillRect(0,0,W,H);
    for(let i=0;i<46;i++){ g.fillStyle='rgba(40,30,20,'+(0.03+rnd()*0.07)+')'; g.fillRect(rnd()*W,rnd()*H,8+rnd()*40,12+rnd()*70); }
    g.fillStyle='rgba(70,64,58,0.45)'; g.fillRect(0,0,9,H); g.fillRect(W-9,0,9,H);
    const cols = 2 + ((rnd()*2)|0), slot = (W-18)/cols;
    const shut = pick([P.shutterColorA,P.shutterColorB,P.shutterColorC]);
    const balc = rnd() < 0.75;
    for(let r=0;r<floors-1;r++){
      const y0 = r*fh;
      g.fillStyle='rgba(60,55,50,0.35)'; g.fillRect(0,y0+fh-3,W,3);
      for(let s=0;s<cols;s++){
        const ww = slot*0.58, wx = 9 + s*slot + (slot-ww)/2, wy = y0+9, wh = 36;
        g.fillStyle='#e9e5dc'; g.fillRect(wx-3,wy-3,ww+6,wh+6);
        g.fillStyle = rnd() < P.windowLitChance ? '#ffd98a' : '#44576a'; g.fillRect(wx,wy,ww,wh);
        g.fillStyle='rgba(255,255,255,0.18)'; g.fillRect(wx,wy,ww*0.4,wh);
        g.fillStyle='#d9d4c8'; g.fillRect(wx+ww/2-1,wy,2,wh);
        if(rnd() < 0.65){
          g.fillStyle = shut;
          g.fillRect(wx-ww*0.33,wy-2,ww*0.33,wh+4); g.fillRect(wx+ww,wy-2,ww*0.33,wh+4);
          g.fillStyle='rgba(0,0,0,0.25)';
          for(let k=0;k<8;k++){ g.fillRect(wx-ww*0.33,wy+k*5,ww*0.33,1); g.fillRect(wx+ww,wy+k*5,ww*0.33,1); }
        }
        if(rnd() < 0.18){ g.fillStyle='#eeeeee'; g.fillRect(wx+ww*0.1,wy+wh+4,20,10); g.fillStyle='#888'; g.fillRect(wx+ww*0.1+3,wy+wh+7,14,2); }
      }
      if(balc){
        g.fillStyle='#6f6a63'; g.fillRect(6,y0+fh-9,W-12,6);
        g.fillStyle='#222'; for(let x=8;x<W-8;x+=7) g.fillRect(x,y0+fh-24,1.5,15);
        g.fillRect(6,y0+fh-25,W-12,2);
        if(rnd() < 0.4){ for(let k=0;k<4;k++){ g.fillStyle = pick(cloths); g.fillRect(20+rnd()*200,y0+fh-23,10+rnd()*8,12+rnd()*6); } }
      }
    }
    const gy = H - gh;
    g.fillStyle='rgba(55,50,46,0.55)'; g.fillRect(0,gy,W,gh);
    const sx = 34, swd = W-34-16, type = (rnd()*3)|0;
    if(type === 0){
      g.fillStyle='#231d19'; g.fillRect(sx,gy+14,swd,gh-14);
      for(let k=0;k<22;k++){ g.fillStyle = pick(cloths); g.fillRect(sx+6+rnd()*(swd-20),gy+22+rnd()*(gh-40),8+rnd()*10,8+rnd()*8); }
      g.fillStyle='#8a8f94'; g.fillRect(sx,gy+10,swd,6);
    } else if(type === 1){
      g.fillStyle='#7d8489'; g.fillRect(sx,gy+14,swd,gh-14);
      g.fillStyle='rgba(0,0,0,0.3)'; for(let y=gy+16;y<H;y+=4) g.fillRect(sx,y,swd,1.2);
    } else {
      g.fillStyle='#35505e'; g.fillRect(sx,gy+14,swd,gh-14);
      g.fillStyle='rgba(255,255,255,0.2)'; g.fillRect(sx+4,gy+16,swd*0.35,gh-18);
      g.fillStyle='#d4d0c6'; g.fillRect(sx+swd/2-2,gy+14,4,gh-14);
    }
    g.fillStyle='#4a2f1d'; g.fillRect(8,gy+16,22,gh-16);
    g.fillStyle='#b8860b'; g.fillRect(24,gy+50,3,3);
    g.fillStyle='rgba(0,0,0,0.25)'; g.fillRect(0,0,W,4);
    const t = mkTex(c);
    const m = new T.MeshLambertMaterial({map: t});
    facCache[key] = m;
    return m;
  };

  const signMat = (name, bg) => {
    const key = name + bg;
    if(signCache[key]) return signCache[key];
    const c = cvs(256,64), g = c.getContext('2d');
    g.fillStyle = bg; g.fillRect(0,0,256,64);
    g.strokeStyle = P.signTextColor; g.lineWidth = 3; g.strokeRect(4,4,248,56);
    g.fillStyle = P.signTextColor; g.font = 'bold 32px Arial';
    g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = 'rtl';
    g.fillText(name,128,34);
    const m = new T.MeshLambertMaterial({map: mkTex(c)});
    signCache[key] = m;
    return m;
  };

  // ---------- عمارة ----------
  const makeBuilding = (par, w, d, floors) => {
    const g = new T.Group(); par.add(g);
    const H = P.shopHeight + (floors-1)*P.floorHeight;
    const wall = pick([P.wallColorA,P.wallColorB,P.wallColorC,P.wallColorD]);
    const side = M(rnd() < 0.45 ? P.brickColor : wall);
    const roof = M(P.roofColor);
    const body = new T.Mesh(BG, [side,side,roof,roof,facade(floors,wall),side]);
    body.scale.set(w,H,d); body.position.y = H/2; g.add(body);
    box(g,w+0.3,0.5,d+0.3,0,H+0.1,0,wall);
    if(rnd() < P.tankChance){
      const tx = R(-w/3,w/3), tz = R(-d/3,d/3);
      box(g,1.2,0.5,1.2,tx,H+0.6,tz,'#8d8a84');
      cyl(g,0.65,0.65,1.2,tx,H+1.45,tz,'#23262b',12);
    }
    if(rnd() < P.dishChance){
      const dish = new T.Mesh(new T.SphereGeometry(0.4,8,6,0,Math.PI*2,0,Math.PI/2), M('#eeeeee'));
      dish.position.set(R(-w/3,w/3), H+1.0, R(-d/3,d/3)); dish.rotation.x = -1.0; g.add(dish);
    }
    if(rnd() < P.unfinishedChance){
      [-1,1].forEach(sx => [-1,1].forEach(sz => {
        box(g,0.35,1.8,0.35,sx*(w/2-0.5),H+1.15,sz*(d/2-0.5),'#8d8a84');
        cyl(g,0.03,0.03,1.0,sx*(w/2-0.5),H+2.5,sz*(d/2-0.5),'#7a4a2a',5);
      }));
    } else if(rnd() < 0.4){
      box(g,3,2.2,3,R(-w/4,w/4),H+1.35,R(-d/4,d/4),wall);
    }
    const sgw = Math.min(w*0.8,6);
    const sm = signMat(pick(names), pick([P.signColorA,P.signColorB,P.signColorC]));
    const dark = M('#222222');
    const sign = new T.Mesh(BG,[dark,dark,dark,dark,sm,dark]);
    sign.scale.set(sgw,0.9,0.15); sign.position.set(0.04*w,P.shopHeight-0.4,d/2+0.1); g.add(sign);
    if(rnd() < P.awningChance){
      const aw = box(g,sgw,0.08,1.3,0.04*w,P.shopHeight-1.1,d/2+0.65,pick([P.awnColorA,P.awnColorB,P.awnColorC]));
      aw.rotation.x = 0.35;
    }
    return g;
  };

  // ---------- ناس ----------
  const makeNPC = (kind) => {
    const g = new T.Group(), body = new T.Group(); g.add(body);
    const kid = kind === 'kid';
    body.scale.setScalar(kid ? 0.62 : R(0.94,1.06));
    const skin = pick([P.skinA,P.skinB,P.skinC]);
    const robe = pick([P.galabeyaA,P.galabeyaB,P.galabeyaC]);
    const shirt = pick(cloths), pants = pick([P.pantsA,P.pantsB]);
    const sleeve = kind === 'galabeya' ? robe : (kind === 'woman' ? shirt : shirt);
    const legL = new T.Group(), legR = new T.Group();
    legL.position.set(-0.11,0.88,0); legR.position.set(0.11,0.88,0);
    [legL,legR].forEach(l => { body.add(l); box(l,0.17,0.88,0.2,0,-0.44,0,kind==='woman'||kind==='galabeya'?'#2a2a2a':pants); box(l,0.18,0.08,0.28,0,-0.86,0.04,'#1c1c1c'); });
    if(kind === 'galabeya') box(body,0.5,1.35,0.3,0,0.97,0,robe);
    else if(kind === 'woman') box(body,0.5,1.25,0.3,0,0.95,0,shirt);
    else box(body,0.46,0.6,0.26,0,1.2,0,shirt);
    const armL = new T.Group(), armR = new T.Group();
    armL.position.set(-0.31,1.46,0); armR.position.set(0.31,1.46,0);
    [armL,armR].forEach(a => { body.add(a); box(a,0.12,0.5,0.14,0,-0.25,0,sleeve); box(a,0.1,0.12,0.1,0,-0.56,0,skin); });
    cyl(body,0.05,0.05,0.1,0,1.54,0,skin,6);
    if(kind === 'woman'){
      sph(body,0.18,0,1.7,-0.01,shirt,1.1);
      box(body,0.36,0.3,0.24,0,1.5,-0.02,shirt);
      sph(body,0.115,0,1.68,0.07,skin);
    } else {
      sph(body,0.14,0,1.68,0,skin);
      if(kind === 'galabeya') sph(body,0.145,0,1.76,0,'#f5f5f5',0.55);
      else { box(body,0.27,0.07,0.28,0,1.79,-0.01,P.hairColor); if(kind === 'man') box(body,0.1,0.02,0.02,0,1.63,0.135,P.hairColor); }
    }
    return {g, body, legL, legR, armL, armR};
  };

  // ---------- أدوات صغيرة ----------
  const lamp = (par,x,z) => {
    cyl(par,0.07,0.09,6.2,x,3.1,z,P.lampColor,6);
    box(par,0.9,0.12,0.25,x,6.25,z,P.lampColor);
    box(par,0.35,0.1,0.2,x,6.15,z,'#fff3b0',{emissive:new T.Color('#fff3b0'),emissiveIntensity:0.9});
  };
  const tree = (par,x,z) => {
    cyl(par,0.14,0.2,2.2,x,1.1,z,P.trunkColor,6);
    sph(par,1.3,x,3.0,z,P.treeLeafColor,0.9);
    sph(par,0.9,x+0.5,3.9,z-0.2,P.treeLeafColor,0.9);
  };
  const car = (par,x,z,rot,col) => {
    const g = new T.Group(); par.add(g); g.position.set(x,-curb+0.03,z); g.rotation.y = rot;
    box(g,1.8,0.65,4.2,0,0.7,0,col); box(g,1.6,0.6,2.2,0,1.3,-0.1,col); box(g,1.62,0.45,2.0,0,1.32,-0.1,'#2c3e50');
    [-1,1].forEach(sx => [-1,1].forEach(sz => { const w = cyl(g,0.35,0.35,0.25,sx*0.9,0.35,sz*1.4,'#111111',10); w.rotation.z = Math.PI/2; }));
  };
  const cable = (par,a,b,sag) => {
    const pts = [];
    for(let k=0;k<=8;k++){ const u = k/8; pts.push(new T.Vector3(a.x+(b.x-a.x)*u, a.y+(b.y-a.y)*u - sag*4*u*(1-u), a.z+(b.z-a.z)*u)); }
    par.add(new T.Line(new T.BufferGeometry().setFromPoints(pts), new T.LineBasicMaterial({color:0x111111})));
  };
  const cafe = (par,x,z) => {
    for(let k=0;k<3;k++){
      const tx = x + k*2.6;
      cyl(par,0.4,0.4,0.05,tx,0.75,z,'#e8e8e8',10); cyl(par,0.04,0.04,0.75,tx,0.37,z,'#555555',6);
      const cc = pick([P.awnColorA,P.awnColorB,P.awnColorC]);
      [[-0.65,0],[0.65,0],[0,0.65]].forEach(o => { box(par,0.4,0.05,0.4,tx+o[0],0.45,z+o[1],cc); box(par,0.4,0.45,0.05,tx+o[0],0.7,z+o[1]+0.2,cc); });
    }
  };
  const addNpcTo = (list,kind,extra) => { const n = makeNPC(kind); n.g.userData.npc = 1; root.add(n.g); Object.assign(n,extra,{kind}); list.push(n); return n; };

  // ---------- أرضية ----------
  const Wd = nx*pitch + P.streetWidth, Dp = nz*pitch + P.streetWidth;
  const asphalt = new T.Mesh(new T.PlaneGeometry(Wd,Dp), M(P.asphaltColor));
  asphalt.rotation.x = -Math.PI/2; asphalt.position.y = 0.03; root.add(asphalt);
  sol(0,-1,0,Wd,2,Dp);

  const dashes = [];
  for(let j=0;j<nz-1;j++){ const z = (czOf(j)+czOf(j+1))/2; for(let x=-Wd/2+4;x<Wd/2-2;x+=8) dashes.push([x,z,0]); }
  for(let i=0;i<nx-1;i++){ const x = (cxOf(i)+cxOf(i+1))/2; for(let z=-Dp/2+4;z<Dp/2-2;z+=8) dashes.push([x,z,1]); }
  if(dashes.length){
    const im = new T.InstancedMesh(BG, M(P.lineColor), dashes.length);
    const dm = new T.Object3D();
    dashes.forEach((d,k) => { dm.position.set(d[0],0.045,d[1]); dm.scale.set(d[2]?0.25:3,0.02,d[2]?3:0.25); dm.updateMatrix(); im.setMatrixAt(k,dm.matrix); });
    root.add(im);
  }

  // ---------- أنواع البلوكات ----------
  const houses = (bg) => {
    box(bg,bs-2*ld,3,bs-2*ld,0,1.5,0,P.roofColor);
    sol(bg.position.x,curb+1.5,bg.position.z,bs-2*ld,3,bs-2*ld);
    const sides = [{ax:'x',z:-1,rot:Math.PI},{ax:'x',z:1,rot:0},{ax:'z',x:1,rot:Math.PI/2},{ax:'z',x:-1,rot:-Math.PI/2}];
    sides.forEach(sd => {
      const len = sd.ax === 'x' ? bs : bs-2*ld;
      const n = Math.max(1,Math.round(len/P.lotWidth));
      const wts = []; let sum = 0;
      for(let k=0;k<n;k++){ const w = 0.65 + rnd(); wts.push(w); sum += w; }
      let pos = -len/2;
      for(let k=0;k<n;k++){
        const w = wts[k]/sum*len, c = pos + w/2; pos += w;
        const fl = Math.round(R(P.minFloors,P.maxFloors));
        const b = makeBuilding(bg,w-0.15,ld,fl);
        const off = bs/2 - ld/2, bh = P.shopHeight + (fl-1)*P.floorHeight;
        if(sd.ax === 'x'){ b.position.set(c,0,sd.z*off); sol(bg.position.x+c,curb+bh/2,bg.position.z+sd.z*off,w-0.15,bh,ld); }
        else { b.position.set(sd.x*off,0,c); sol(bg.position.x+sd.x*off,curb+bh/2,bg.position.z+c,ld,bh,w-0.15); }
        b.rotation.y = sd.rot;
      }
    });
  };

  const stall = (bg,x,z) => {
    const g = new T.Group(); bg.add(g); g.position.set(x,0,z);
    box(g,3.2,0.9,1.4,0,0.45,0,P.woodColor);
    sol(bg.position.x+x,curb+0.5,bg.position.z+z,3.2,1.0,1.4);
    for(let k=0;k<12;k++) sph(g,0.12,R(-1.4,1.4),1.0,R(-0.5,0.5),pick([P.produceA,P.produceB,P.produceC,P.produceD]));
    [-1,1].forEach(sx => [-1,1].forEach(sz => cyl(g,0.04,0.04,2.5,sx*1.7,1.25,sz*0.95,P.woodColor,6)));
    const aw = box(g,3.8,0.08,2.4,0,2.55,0,pick([P.awnColorA,P.awnColorB,P.awnColorC]));
    aw.rotation.x = 0.12;
  };

  const market = (bg,bx,bz,npcs) => {
    box(bg,bs-2,0.04,bs-2,0,0.02,0,P.sidewalkColor);
    const gap = 5, colsN = Math.max(1,Math.floor((bs-12)/gap)+1), rowsN = Math.max(1,Math.ceil(P.stalls/colsN));
    let made = 0;
    for(let r=0;r<rowsN;r++) for(let c=0;c<colsN && made<P.stalls;c++){
      const x = (c-(colsN-1)/2)*gap, z = (r-(rowsN-1)/2)*8;
      made++; stall(bg,x,z);
      const kind = rnd() < 0.7 ? 'galabeya' : 'man';
      addNpcTo(npcs,kind,{type:'static',x:bx+x,z:bz+z-1.3,yaw:0,ph:rnd()*6.28});
    }
    const cx = bs/2 - 4;
    box(bg,1.6,0.7,1.0,cx,0.9,-cx,P.woodColor);
    [-0.7,0.7].forEach(o => { const w = cyl(bg,0.35,0.35,0.1,cx+o,0.35,-cx,'#222222',10); w.rotation.z = Math.PI/2; });
    for(let k=0;k<6;k++) sph(bg,0.13,cx+R(-0.6,0.6),1.3,-cx+R(-0.4,0.4),pick([P.produceA,P.produceB,P.produceC,P.produceD]));
  };

  const mosque = (bg) => {
    const g = new T.Group(); bg.add(g);
    const W = 20, D = 18, H = 11;
    const c = cvs(256,128), x = c.getContext('2d');
    x.fillStyle = P.mosqueColor; x.fillRect(0,0,256,128);
    x.fillStyle = P.mosqueStripeColor; for(let y=0;y<128;y+=16) x.fillRect(0,y,256,8);
    for(let k=0;k<4;k++){
      const wx = 24 + k*60;
      x.fillStyle = '#2a2420'; x.fillRect(wx,50,24,64); x.beginPath(); x.arc(wx+12,50,12,Math.PI,0); x.fill();
    }
    const wt = mkTex(c);
    const wm = new T.MeshLambertMaterial({map: wt});
    const body = new T.Mesh(BG,[wm,wm,M(P.roofColor),M(P.roofColor),wm,wm]);
    body.scale.set(W,H,D); body.position.y = H/2; g.add(body);
    sol(bg.position.x,curb+H/2,bg.position.z,W,H,D);
    cyl(g,5.2,5.4,2.4,0,H+1.2,0,P.mosqueColor,16);
    sph(g,5.4,0,H+2.4,0,P.domeColor,0.85);
    cyl(g,0.05,0.05,2.2,0,H+7.4,0,P.goldColor,5);
    sph(g,0.25,0,H+8.6,0,P.goldColor);
    const cr = new T.Mesh(new T.TorusGeometry(0.45,0.08,6,14,Math.PI*1.5), M(P.goldColor)); cr.position.set(0,H+9.2,0); cr.rotation.z = -Math.PI*0.75; g.add(cr);
    const Hm = P.minaretHeight;
    [-1,1].forEach(sx => {
      const mx = sx*(W/2-1.2), mz = D/2-1.2;
      cyl(g,1.0,1.3,Hm,mx,Hm/2,mz,P.mosqueColor,8);
      sol(bg.position.x+mx,curb+Hm/2,bg.position.z+mz,2.6,Hm,2.6);
      cyl(g,1.7,1.7,0.5,mx,Hm*0.72,mz,P.goldColor,8);
      cyl(g,1.5,1.5,0.5,mx,Hm*0.92,mz,P.goldColor,8);
      cyl(g,0.05,1.0,2.4,mx,Hm+1.2,mz,P.domeColor,8);
      sph(g,0.2,mx,Hm+2.6,mz,P.goldColor);
    });
  };

  const plaza = (bg) => {
    box(bg,bs-2,0.04,bs-2,0,0.02,0,P.sidewalkColor);
    cyl(bg,4.5,4.5,0.7,0,0.35,0,P.mosqueColor,20);
    sol(bg.position.x,curb+0.35,bg.position.z,8.6,0.7,8.6);
    cyl(bg,4.0,4.0,0.72,0,0.37,0,'#4aa3c7',20);
    cyl(bg,0.4,0.6,2.4,0,1.4,0,P.mosqueColor,10);
    sph(bg,0.7,0,2.8,0,'#8fd0e8',0.5);
    for(let k=0;k<4;k++){ const a = k*Math.PI/2+0.4; box(bg,2,0.5,0.6,Math.cos(a)*8,0.3,Math.sin(a)*8,P.woodColor).rotation.y = -a+Math.PI/2; }
    for(let k=0;k<8;k++){ const a = k*Math.PI/4; tree(bg,Math.cos(a)*14,Math.sin(a)*14); }
  };

  // ---------- البلوكات ----------
  const blocks = [], npcs = [];
  let marketBlock = null, cafeSlots = [];
  for(let i=0;i<nx;i++) for(let j=0;j<nz;j++){
    const bx = cxOf(i), bz = czOf(j);
    const bg = new T.Group(); bg.position.set(bx,curb,bz); root.add(bg);
    box(root,bs+2*sw,curb,bs+2*sw,bx,curb/2,bz,P.sidewalkColor);
    const role = (i===P.marketI && j===P.marketJ) ? 'market' : (i===P.mosqueI && j===P.mosqueJ) ? 'mosque' : (i===P.plazaI && j===P.plazaJ) ? 'plaza' : 'houses';
    blocks.push({bx,bz,role});
    if(role === 'houses') houses(bg);
    else if(role === 'market'){ market(bg,bx,bz,npcs); marketBlock = {bx,bz}; }
    else if(role === 'mosque') mosque(bg);
    else plaza(bg);

    const edge = bs/2 + sw - 0.5;
    for(let s=0;s<4;s++){
      const ax = s < 2 ? 'x' : 'z', sg = (s%2) ? 1 : -1;
      const place = (t,fn) => { if(ax === 'x') fn(t,sg*edge); else fn(sg*edge,t); };
      for(let t=-bs/2+4; t<bs/2-2; t+=P.lampSpacing){
        place(t,(x,z) => lamp(bg,x,z));
        if(rnd() < P.treeChance) place(t+P.lampSpacing/2,(x,z) => { if(Math.abs(ax==='x'?x:z) < bs/2) tree(bg,x,z); });
      }
      if(rnd() < P.poleChance && ax === 'x'){
        const pz = sg*(edge+0.4), xs = [-bs/2+5, bs/2-5];
        xs.forEach(px => cyl(bg,0.12,0.16,8,px,4,pz,'#7a746b',6));
        [0,1,2].forEach(k => cable(bg,new T.Vector3(xs[0],7.5-k*0.4,pz),new T.Vector3(xs[1],7.5-k*0.4,pz),0.6));
        box(bg,2.2,0.12,0.12,xs[0],7.6,pz,P.woodColor); box(bg,2.2,0.12,0.12,xs[1],7.6,pz,P.woodColor);
      }
      const cedge = bs/2 + sw + 1.4;
      for(let t=-bs/2+5; t<bs/2-3; t+=7){
        if(rnd() < P.carChance){
          const col = pick([P.carColorA,P.carColorB,P.carColorC,P.carColorD]);
          if(ax === 'x'){ car(bg,t,sg*cedge,Math.PI/2,col); sol(bx+t,0.8,bz+sg*cedge,4.2,1.6,1.8); }
          else { car(bg,sg*cedge,t,0,col); sol(bx+sg*cedge,0.8,bz+t,1.8,1.6,4.2); }
        }
      }
      if(role === 'houses') cafeSlots.push({bg, x: ax==='x' ? -bs/4 : sg*(bs/2+sw*0.5), z: ax==='x' ? sg*(bs/2+sw*0.5) : -bs/4, ax});
    }
  }
  for(let k=0;k<P.cafes && cafeSlots.length;k++){
    const idx = (rnd()*cafeSlots.length)|0, cs = cafeSlots.splice(idx,1)[0];
    cafe(cs.bg,cs.x,cs.z);
  }

  // ---------- المشاة ----------
  const kinds = ['man','man','galabeya','woman','woman','kid'];
  for(let k=0;k<P.npcWalkers;k++){
    const b = pick(blocks);
    const half = bs/2 + sw*R(0.3,0.7);
    addNpcTo(npcs,pick(kinds),{type:'ring',bx:b.bx,bz:b.bz,half,dir:rnd()<0.5?-1:1,u0:R(0,8*half),spd:R(0.8,1.15)});
  }
  for(let k=0;k<P.npcShoppers;k++){
    const b = marketBlock || pick(blocks);
    const half = bs/2 - 2.5 - R(0,0.8);
    addNpcTo(npcs,pick(kinds),{type:'ring',bx:b.bx,bz:b.bz,half,dir:rnd()<0.5?-1:1,u0:R(0,8*half),spd:R(0.5,0.9),inner:true});
  }

  const freeze = (o) => {
    if(o.userData && o.userData.npc) return;
    if(o !== root){ o.updateMatrix(); o.matrixAutoUpdate = false; }
    for(let k=0;k<o.children.length;k++) freeze(o.children[k]);
  };
  freeze(root);

  const cleanup = () => {
    if(root.parent) root.parent.remove(root);
    root.traverse(o => { if(o.geometry && o.geometry !== BG) o.geometry.dispose(); });
    Object.keys(mats).forEach(k => mats[k].dispose());
    Object.keys(facCache).forEach(k => facCache[k].dispose());
    Object.keys(signCache).forEach(k => signCache[k].dispose());
    texs.forEach(t => t.dispose());
    BG.dispose();
  };

  const update = (t, Pn) => {
    const freq = Math.PI / Pn.stepLength;
    for(let n=0;n<npcs.length;n++){
      const p = npcs[n];
      if(p.type === 'static'){
        p.g.position.set(p.x,curb,p.z); p.g.rotation.y = p.yaw;
        const s = Math.sin(t*1.5+p.ph);
        p.armL.rotation.x = s*0.08; p.armR.rotation.x = -s*0.08 - 0.15;
        p.body.position.y = 0;
        continue;
      }
      const S2 = 2*p.half, L = 4*S2;
      const u = p.u0 + p.dir*Pn.npcSpeed*p.spd*t;
      const w = ((u % L) + L) % L;
      const side = Math.floor(w/S2), f = w - side*S2, h = p.half;
      let x, z, dx, dz;
      if(side === 0){ x = -h+f; z = -h; dx = 1; dz = 0; }
      else if(side === 1){ x = h; z = -h+f; dx = 0; dz = 1; }
      else if(side === 2){ x = h-f; z = h; dx = -1; dz = 0; }
      else { x = -h; z = h-f; dx = 0; dz = -1; }
      p.g.position.set(p.bx+x,curb,p.bz+z);
      p.g.rotation.y = Math.atan2(dx*p.dir,dz*p.dir);
      const sw2 = Math.sin(Math.abs(u)*freq)*0.65;
      p.legL.rotation.x = sw2; p.legR.rotation.x = -sw2;
      p.armL.rotation.x = -sw2*0.8; p.armR.rotation.x = sw2*0.8;
      p.body.position.y = Math.abs(Math.sin(Math.abs(u)*freq))*0.03;
    }
  };

  return {cleanup, update, root, src: srcName, solids};
}


Game.onUpdate(function(dt){
  const P = Game.params;
  clock += dt;
  const sig = JSON.stringify(P, (k,v) => (k === 'npcSpeed' || k === 'stepLength') ? undefined : v);
  if(failedSig === sig) return;
  if(!S || S.sig !== sig){
    if(S) S.cleanup();
    S = null;
    try{
      S = buildCity(P);
      S.sig = sig;
      let cnt = 0; S.root.traverse(o => { if(o.isMesh) cnt++; });
      if(typeof Game.subtitle === 'function') Game.subtitle('المدينة اتبنت: ' + cnt + ' مجسم - المصدر: ' + S.src);
    }catch(e){
      failedSig = sig;
      console.error('egypt_city build error:', e);
      if(typeof Game.subtitle === 'function') Game.subtitle('خطأ في بناء المدينة: ' + e.message);
      return;
    }
  }
  if(!solidsDone && S.solids.length){
    const f = S.solids[0];
    if(Game.addSolidBox(f[0],f[1],f[2],f[3],f[4],f[5])){
      for(let k=1;k<S.solids.length;k++){ const b = S.solids[k]; Game.addSolidBox(b[0],b[1],b[2],b[3],b[4],b[5]); }
      solidsDone = true;
    }
  }
  S.update(Date.now()/1000, P);
});
