

const CFG = {
  enabled: true,        
  toggleKey: 'KeyG',    
  talk: true,           
  talkCooldown: 6,      
  face: true,           
  pauseWhenSeated: true 
};

const TAU = Math.PI * 2, PI = Math.PI, sin = Math.sin, cos = Math.cos;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const wrap = a => ((a % TAU) + TAU) % TAU;
const env = (a, D) => sin(clamp(a / D, 0, 1) * PI);        
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = a => a[(Math.random() * a.length) | 0];
const q = v => Math.round((+v || 0) * 1000) / 1000;         

const LINES = {
  watch:  ['هو أنا هستنى كتير؟', 'الساعة بتقول إنك متأخر.', 'أنا مستني من الصبح.'],
  shrug:  ['ولا أعرف.. أنا ماشي بس.', 'مش مشكلتي.', 'يعني؟'],
  headspin: ['هي الدنيا بتلف ولا أنا؟', 'بنعمل إيه النهارده؟ بنلف.'],
  stretch: ['أنا نايم واقف.', 'الجاذبية دي بتتعبني.'],
  dance:  ['محدش بيتفرج؟ تمام، هرقص لنفسي.', 'ده رقص احترافي. صدّقني.'],
  eyeroll: ['آه طبعاً، فكرة عبقرية.', 'واو. مبهور.'],
  tada:   ['تصفيق من فضلكم 👏', 'متحاولوش تقلدوا ده.'],
  doom:   ['مش دلوقتي يا جاذبية!', 'أنا كنت لسه بقول حاجة!', 'ياااااني!'],
  wheel:  ['نسيت الفرن شغال!', 'عندي ميعاد مهم مع الكنبة.'],
  land:   ['هبوط ناعم. ناعم جداً.', 'الأرض لسه هناك.. تمام.']
};

function kids(o) { return (o && o.children ? o.children : []).filter(c => !c.isMesh); }
function firstKid(par, pred) { for (const c of kids(par)) if (pred(c)) return c; return null; }
function chainDown(node, n) {
  const out = []; let cur = node;
  for (let i = 0; i < n && cur; i++) {
    const ch = firstKid(cur, g => g.position.y < -0.05) || firstKid(cur, () => true);
    if (!ch) break; out.push(ch); cur = ch;
  }
  return out;
}
function hook(o) {
  if (!o || o.__fh) return;
  o.__fh = { on: false, r: [null, null, null], py: null, s: null };
  const orig = o.updateMatrixWorld;
  o.updateMatrixWorld = function (force) {
    const h = o.__fh;
    if (h && h.on) {
      if (h.r[0] != null) o.rotation.x = h.r[0];
      if (h.r[1] != null) o.rotation.y = h.r[1];
      if (h.r[2] != null) o.rotation.z = h.r[2];
      if (h.py != null) o.position.y = h.py;
      if (h.s) o.scale.set(h.s[0], h.s[1], h.s[2]);
    }
    return orig.call(this, force);
  };
}
function discover(game) {
  const root = game.player && game.player.mesh;
  if (!root) return null;
  let pelvis = kids(root).find(c => c.position && c.position.y > 0.25) || kids(root)[0];
  if (!pelvis) return null;
  const waist = firstKid(pelvis, g => Math.abs(g.position.x) < 0.06 && g.position.y > 0.02 && g.position.y < 0.25) || firstKid(pelvis, g => Math.abs(g.position.x) < 0.1);
  const chest = waist ? (firstKid(waist, g => g.position.y > 0.04) || firstKid(waist, () => true)) : null;
  let armR = null, armL = null, head = null;
  const meshes = o => { let n = 0; o.traverse(q => { if (q.isMesh) n++; }); return n; };
  let best = -1;
  if (chest) for (const c of kids(chest)) {
    const x = c.position.x, y = c.position.y;
    if (y > 0.12 && Math.abs(x) < 0.1) { const n = meshes(c); if (n > best) { best = n; head = c; } }
    if (Math.abs(x) > 0.12 && y > 0.04) { if (x > 0) armR = c; else armL = c; }
  }
  if (head) { const d = firstKid(head, g => g.position.y >= 0); if (d) head = d; }
  const aR = chainDown(armR, 1), aL = chainDown(armL, 1);
  let legR = null, legL = null;
  for (const c of kids(pelvis)) {
    if (c === waist) continue;
    if (Math.abs(c.position.x) > 0.04 && c.position.y < 0.15) { if (c.position.x > 0) legR = c; else legL = c; }
  }
  const lR = chainDown(legR, 2), lL = chainDown(legL, 2);
  const map = { pelvis, waist, chest, head, armR, armL, foreR: aR[0], foreL: aL[0], legR, legL, shinR: lR[0], shinL: lL[0], footR: lR[1], footL: lL[1] };
  for (const k in map) hook(map[k]);
  const miss = Object.keys(map).filter(k => !map[k]);
  try { console.log('[HawaFunny] bones ok:', Object.keys(map).filter(k => map[k]).join(','), miss.length ? '| missing: ' + miss.join(',') : ''); } catch (_) {}
  return map.pelvis && map.legR && map.legL && map.armR && map.armL ? map : null;
}

function mapEngineRig(rig) {
  if (!rig || !rig.pelvis) return null;
  return {
    pelvis: rig.pelvis,
    waist: rig.waist,
    chest: rig.chest,
    head: rig.head,
    armR: rig.AR && rig.AR.sh,
    armL: rig.AL && rig.AL.sh,
    foreR: rig.AR && rig.AR.el,
    foreL: rig.AL && rig.AL.el,
    legR: rig.R && rig.R.hip,
    legL: rig.L && rig.L.hip,
    shinR: rig.R && rig.R.knee,
    shinL: rig.L && rig.L.knee,
    footR: rig.R && rig.R.ankle,
    footL: rig.L && rig.L.ankle,
    hipY: rig.hipY || 0.74
  };
}

function neutralPose() {
  return { px: 0, py: 0, pz: 0, bounce: 0, hover: 0,
    wX: 0, wY: 0, wZ: 0, cX: 0, cZ: 0, hX: 0, hY: null, hZ: 0,
    Lh: .02, Lk: .1, La: 0, Rh: .02, Rk: .1, Ra: 0,
    LaX: .04, LaZ: -.09, LfX: -.16, RaX: .04, RaZ: .09, RfX: -.16,
    mo: 0, su: 0, sm: 0, direct: false, legDirect: false, armDirect: false };
}
function compute(S, m, dt) {
  const P = neutralPose(), F = S.f, t = m.t, p = m.ph;
  const say = (k) => talk(S, k);
  if (m.air && !F.prevAir) {
    F.jT = 0; F.fl = 0; const r = Math.random();
    F.jk = r < .27 ? 'flip' : r < .5 ? 'twirl' : r < .75 ? 'pedal' : 'super';
    if (m.vy > 1) F.sqV = 10;
  }
  if (!m.air && F.prevAir) {
    const qq = clamp(-F.pvy / 13, .25, 1); F.sqV = -30 * qq; F.wob = qq;
    if (F.jk === 'flip' || F.jk === 'twirl') { F.gag = 'tada'; F.gT = 0; F.gD = 1.2; say('tada'); }
    else if (qq > .75) say('land');
  }
  F.prevAir = m.air; F.pvy = m.vy; if (m.air) F.jT += dt;
  const sqT = m.air ? (m.vy > 0 ? .22 : .12) : 0;
  F.sqV += ((sqT - F.sq) * 240 - F.sqV * 9) * dt; F.sq = clamp(F.sq + F.sqV * dt, -.55, .5);
  F.wob = Math.max(0, F.wob - dt * 1.4);
  if (F.gag) { F.gT += dt; if (F.gT >= F.gD || (m.mv && F.gag !== 'tada')) { F.gag = ''; F.gNext = 3 + Math.random() * 4; } }
  else if (!m.mv && !m.air) {
    F.gNext -= dt;
    if (F.gNext <= 0) {
      const G = [['shrug', 1.7], ['watch', 2.8], ['headspin', 1.1], ['stretch', 2.2], ['dance', 2.6], ['eyeroll', 2.0]], g = pick(G);
      F.gag = g[0]; F.gD = g[1]; F.gT = 0; say(g[0]);
    }
  } else F.gNext = Math.max(F.gNext, 1.5);
  if (F.wc > 0) F.wc -= dt;
  else if (m.run && m.mv && !m.air) { F.wNext -= dt; if (F.wNext <= 0) { F.wc = .95; F.wNext = 2.5 + Math.random() * 3.5; say('wheel'); } }

  const g = F.gT, ge = env(g, F.gD);
  if (m.air) {
    const rise = m.vy > 0, doom = !rise && m.vy < -7 && F.jT > .35 && F.jk !== 'flip' && F.jk !== 'twirl';
    if (doom) {
      if (!F.doomSaid) { F.doomSaid = true; say('doom'); }
      P.Lh = -.9 + sin(t * 30) * .9; P.Rh = -.9 - sin(t * 30) * .9; P.Lk = 1.1 + sin(t * 30 + 1.6) * .7; P.Rk = 1.1 - sin(t * 30 + 1.6) * .7;
      P.LaX = -2.8 + sin(t * 26) * .45; P.RaX = -2.8 - sin(t * 26) * .45; P.LaZ = -.5 - sin(t * 21) * .35; P.RaZ = .5 + sin(t * 21) * .35;
      P.LfX = -.5 + sin(t * 29) * .4; P.RfX = -.5 - sin(t * 29) * .4; P.mo = 1; P.su = 1; P.hX = -.3; P.hZ = sin(t * 25) * .25;
    } else if (F.jk === 'flip') {
      F.fl = Math.min(TAU, F.fl + dt * 9.5); P.px = F.fl >= TAU ? 0 : F.fl; P.direct = true;
      P.Lh = P.Rh = -1.9; P.Lk = P.Rk = 2.2; P.La = P.Ra = .3; P.LaX = P.RaX = -1.2; P.LaZ = -.2; P.RaZ = .2; P.LfX = P.RfX = -1.6; P.mo = .4; P.su = 1;
    } else if (F.jk === 'twirl') {
      F.fl = Math.min(TAU * 2, F.fl + dt * 15); P.py = F.fl >= TAU * 2 ? 0 : F.fl; P.direct = true;
      P.Lh = -.8; P.Rh = .5; P.Lk = .6; P.Rk = .3; P.LaX = P.RaX = -.2; P.LaZ = -1.45; P.RaZ = 1.45; P.LfX = P.RfX = -.1; P.sm = 1; P.su = 1;
    } else if (F.jk === 'super') {
      P.px = 1.25; P.wX = .1; P.cX = .1; P.Lh = P.Rh = .15; P.Lk = P.Rk = .12; P.LaX = P.RaX = -3.0; P.LaZ = -.12; P.RaZ = .12; P.LfX = P.RfX = -.05; P.hX = -1.0; P.sm = 1;
    } else {
      P.Lh = -1.0 + sin(t * 24) * .9; P.Rh = -1.0 - sin(t * 24) * .9; P.Lk = 1.0 + cos(t * 24) * .7; P.Rk = 1.0 - cos(t * 24) * .7;
      P.LaX = -2.6 + sin(t * 20) * .5; P.RaX = -2.6 - sin(t * 20) * .5; P.LaZ = -.5 - sin(t * 17) * .4; P.RaZ = .5 + sin(t * 17) * .4;
      P.LfX = -.4 + sin(t * 25) * .4; P.RfX = -.4 - sin(t * 25) * .4; P.mo = rise ? .9 : 1; P.su = 1;
    }
  } else {
    F.doomSaid = false;
    if (m.mv && m.run) {
      if (F.wc > 0) {
        const a = wrap(-t * 26); P.Lh = a; P.Rh = wrap(a + PI); P.legDirect = true; P.Lk = P.Rk = .9; P.La = P.Ra = .6;
        P.wX = .9; P.cX = .25; P.hX = -.4; P.LaX = P.RaX = 1.45; P.LaZ = -.12; P.RaZ = .12; P.LfX = P.RfX = -.2; P.hover = .02; P.mo = .5; P.su = .6;
      } else {
        P.Lh = -1.55 * sin(p); P.Rh = 1.55 * sin(p);
        P.Lk = .25 + 1.9 * Math.pow(Math.max(0, cos(p)), 1.2); P.Rk = .25 + 1.9 * Math.pow(Math.max(0, -cos(p)), 1.2);
        P.La = -(P.Lh + P.Lk) * .5 + sin(2 * p) * .7; P.Ra = -(P.Rh + P.Rk) * .5 - sin(2 * p) * .7;
        const wa = wrap(p * 1.15);
        P.LaX = wa; P.RaX = wrap(wa + PI); P.armDirect = true; P.LaZ = -.45; P.RaZ = .45;
        P.LfX = -.7 + sin(t * 16) * .6; P.RfX = -.7 + sin(t * 16 + 1) * .6;
        P.wX = .55; P.cX = .3; P.hX = -.25 + sin(2 * p) * .3; P.hZ = sin(p) * .35;
        P.pz = sin(p) * .3; P.py = sin(p) * .35; P.bounce = Math.abs(sin(p)) * .13; P.mo = .8 + .2 * sin(t * 20); P.su = .5;
      }
    } else if (m.mv) {
      P.Lh = -.8 * sin(p); P.Rh = .8 * sin(p);
      P.Lk = .2 + 1.0 * Math.pow(Math.max(0, cos(p)), 1.2); P.Rk = .2 + 1.0 * Math.pow(Math.max(0, -cos(p)), 1.2);
      P.La = -(P.Lh + P.Lk) * .5; P.Ra = -(P.Rh + P.Rk) * .5;
      P.pz = sin(p) * .38; P.py = sin(p) * .3; P.wX = -.12; P.cX = -.1; P.wZ = -sin(p) * .15; P.bounce = Math.abs(cos(p)) * .04;
      P.RaX = .25; P.RaZ = .75; P.RfX = -2.0; P.LaX = .9 * sin(p); P.LaZ = -.12; P.LfX = -.5;
      P.hX = -.22; P.hZ = .22 + sin(p * .5) * .1; P.sm = .6;
    } else {
      P.wX = .12; P.hX = .08; P.pz = sin(t * 1.2) * .03; P.LaX = sin(t * 1.3) * .1; P.RaX = sin(t * 1.1 + 1) * .1;
      switch (F.gag) {
        case 'shrug': P.LaZ = -ge; P.RaZ = .09 + ge; P.LaX = P.RaX = -ge * .3; P.LfX = P.RfX = -ge * 1.5; P.hZ = ge * .35; P.pz = ge * .12; break;
        case 'watch': P.RaX = -ge * .6; P.RaZ = .09 + ge * .2; P.RfX = -ge * 2.3; P.hX = .08 + ge * .45; P.La = sin(t * 14) * .4 * ge; P.Lh = -.1 * ge; break;
        case 'headspin': { const u = clamp(g / F.gD, 0, 1); P.hY = u * u * (3 - 2 * u) * TAU; P.su = 1; P.mo = .5; break; }
        case 'stretch': P.LaX = P.RaX = -ge * 3.0; P.LaZ = -ge * .3; P.RaZ = .09 + ge * .3; P.wX = -ge * .3; P.cX = -ge * .3; P.hX = -ge * .4; P.mo = ge; break;
        case 'dance': { const a = t * 9; P.pz = sin(a) * .35 * ge; P.py = cos(a) * .4 * ge; P.bounce = Math.abs(sin(a)) * .08 * ge; P.RaX = -2.4 * ge; P.RaZ = .09 + .3 * ge; P.LaX = sin(a) * .6 * ge;
          P.Lh = sin(a) * .5 * ge; P.Rh = -sin(a) * .5 * ge; P.Lk = P.Rk = .1 + .5 * Math.abs(sin(a)) * ge; P.hZ = sin(a) * .3 * ge; P.sm = 1; break; }
        case 'eyeroll': P.hX = -.3 * ge; P.hZ = .2 * ge; P.LaX = P.RaX = -.25 * ge; P.LaZ = ge * .3 - .09 * (1 - ge); P.RaZ = -ge * .3 + .09 * (1 - ge); P.LfX = P.RfX = -2.1 * ge; P.sm = .4 * ge; break;
        case 'tada': P.LaX = P.RaX = -2.5 * ge; P.LaZ = -.7 * ge; P.RaZ = .7 * ge; P.hX = -.3 * ge; P.wX = -.15 * ge; P.sm = 1; P.su = 1; break;
      }
    }
  }
  P.sy = 1 + F.sq; P.sx = 1 - F.sq * .6; P.wob = F.wob * sin(t * 20);
  return P;
}

function setB(o, x, y, z) { if (!o || !o.__fh) return; const h = o.__fh; h.on = true; h.r[0] = x; h.r[1] = y; h.r[2] = z; }
function setDirect(o, x, y, z) {
  if (!o || !o.rotation) return;
  if (x != null) o.rotation.x = x;
  if (y != null) o.rotation.y = y;
  if (z != null) o.rotation.z = z;
}
function smooth(cur, k, a, b, c, direct) { cur[0] = direct ? a : lerp(cur[0], a, k); cur[1] = direct ? b : lerp(cur[1], b, k); cur[2] = direct ? c : lerp(cur[2], c, k); return cur; }
function applyPose(S, P, dt) {
  const R = S.rig, C = S.cur, k = Math.min(1, dt * 20);
  const kd = P.direct;
  const pel = R.pelvis, ph = pel.__fh;
  smooth(C.pel, k, P.px, P.py, P.pz + P.wob * .25, kd);
  setB(pel, C.pel[0], C.pel[1], C.pel[2]);
  ph.py = .06 + (S.hip - .06) * P.sy + P.bounce + P.hover; ph.s = [P.sx, P.sy, P.sx];
  setB(R.waist, ...smooth(C.waist, k, P.wX, P.wY, P.wZ));
  setB(R.chest, ...smooth(C.chest, k, P.cX, 0, P.cZ));
  if (R.head) {
    const spin = P.hY != null;
    if (spin) smooth(C.head, k, P.hX, P.hY, P.hZ, true);
    else { C.head[0] = lerp(C.head[0], P.hX, k); C.head[2] = lerp(C.head[2], P.hZ + P.wob * .5, k); }
    const h = R.head.__fh; h.on = true; h.r[0] = C.head[0]; h.r[1] = spin ? C.head[1] : null; h.r[2] = C.head[2];
    if (!spin && S.wasSpin) R.head.rotation.y = wrap(R.head.rotation.y + PI) - PI;
    S.wasSpin = spin;
    if (!spin) C.head[1] = R.head.rotation.y;
  }
  const ld = P.legDirect, ad = P.armDirect;
  setB(R.legL, ...smooth(C.legL, k, P.Lh, 0, .02, ld)); setB(R.shinL, ...smooth(C.shinL, k, P.Lk, 0, 0, ld)); setB(R.footL, ...smooth(C.footL, k, P.La, 0, 0, ld));
  setB(R.legR, ...smooth(C.legR, k, P.Rh, 0, -.02, ld)); setB(R.shinR, ...smooth(C.shinR, k, P.Rk, 0, 0, ld)); setB(R.footR, ...smooth(C.footR, k, P.Ra, 0, 0, ld));
  setB(R.armL, ...smooth(C.armL, k, P.LaX, 0, P.LaZ, ad)); setB(R.foreL, ...smooth(C.foreL, k, P.LfX, 0, 0));
  setB(R.armR, ...smooth(C.armR, k, P.RaX, 0, P.RaZ, ad)); setB(R.foreR, ...smooth(C.foreR, k, P.RfX, 0, 0));
}

function applyPoseEngine(map, pack, dt) {
  if (!map || !pack) return;
  const k = Math.min(1, dt * 18);
  const L = map._lerp || (map._lerp = {});
  const sm = (key, tx, ty, tz) => {
    if (!L[key]) L[key] = [tx || 0, ty || 0, tz || 0];
    const c = L[key];
    c[0] = lerp(c[0], tx || 0, k);
    c[1] = lerp(c[1], ty || 0, k);
    c[2] = lerp(c[2], tz || 0, k);
    return c;
  };
  const pel = map.pelvis;
  if (pel) {
    const c = sm('pel', pack.px, pack.py, pack.pz);
    setDirect(pel, c[0], c[1], c[2]);
    const hy = map.hipY != null ? map.hipY : 0.74;
    pel.position.y = hy * (pack.sy != null ? pack.sy : 1) + (pack.bounce || 0) + (pack.hover || 0);
    const sx = pack.sx != null ? pack.sx : 1, sy = pack.sy != null ? pack.sy : 1;
    pel.scale.set(sx, sy, sx);
  }
  if (map.waist) { const c = sm('wa', pack.wX, pack.wY, pack.wZ); setDirect(map.waist, c[0], c[1], c[2]); }
  if (map.chest) { const c = sm('ch', pack.cX, 0, pack.cZ); setDirect(map.chest, c[0], c[1], c[2]); }
  if (map.head) {
    const hy = pack.hY != null ? pack.hY : null;
    const c = sm('hd', pack.hX, hy != null ? hy : 0, pack.hZ);
    setDirect(map.head, c[0], hy != null ? c[1] : null, c[2]);
  }
  if (map.legL) { const c = sm('lL', pack.Lh, 0, .02); setDirect(map.legL, c[0], c[1], c[2]); }
  if (map.shinL) { const c = sm('sL', pack.Lk, 0, 0); setDirect(map.shinL, c[0], 0, 0); }
  if (map.footL) { const c = sm('fL', pack.La, 0, 0); setDirect(map.footL, c[0], 0, 0); }
  if (map.legR) { const c = sm('lR', pack.Rh, 0, -.02); setDirect(map.legR, c[0], c[1], c[2]); }
  if (map.shinR) { const c = sm('sR', pack.Rk, 0, 0); setDirect(map.shinR, c[0], 0, 0); }
  if (map.footR) { const c = sm('fR', pack.Ra, 0, 0); setDirect(map.footR, c[0], 0, 0); }
  if (map.armL) { const c = sm('aL', pack.LaX, 0, pack.LaZ); setDirect(map.armL, c[0], 0, c[2]); }
  if (map.foreL) { const c = sm('oL', pack.LfX, 0, 0); setDirect(map.foreL, c[0], 0, 0); }
  if (map.armR) { const c = sm('aR', pack.RaX, 0, pack.RaZ); setDirect(map.armR, c[0], 0, c[2]); }
  if (map.foreR) { const c = sm('oR', pack.RfX, 0, 0); setDirect(map.foreR, c[0], 0, 0); }
}

function packPose(P) {
  if (!P) return null;
  return {
    on: 1,
    px: q(P.px), py: q(P.py), pz: q(P.pz),
    bounce: q(P.bounce), hover: q(P.hover),
    wX: q(P.wX), wY: q(P.wY), wZ: q(P.wZ),
    cX: q(P.cX), cZ: q(P.cZ),
    hX: q(P.hX), hY: P.hY != null ? q(P.hY) : null, hZ: q(P.hZ),
    Lh: q(P.Lh), Lk: q(P.Lk), La: q(P.La),
    Rh: q(P.Rh), Rk: q(P.Rk), Ra: q(P.Ra),
    LaX: q(P.LaX), LaZ: q(P.LaZ), LfX: q(P.LfX),
    RaX: q(P.RaX), RaZ: q(P.RaZ), RfX: q(P.RfX),
    sx: q(P.sx), sy: q(P.sy),
    mo: q(P.mo), sm: q(P.sm), su: q(P.su)
  };
}

function releaseAll(S) {
  if (!S.rig) return;
  for (const k in S.rig) { const o = S.rig[k]; if (o && o.__fh) o.__fh.on = false; }
  for (const k in S.rig) { const o = S.rig[k]; if (o && o.rotation) { o.rotation.x = wrap(o.rotation.x + PI) - PI; o.rotation.y = wrap(o.rotation.y + PI) - PI; o.rotation.z = wrap(o.rotation.z + PI) - PI; } }
  const p = S.rig.pelvis; if (p) { p.scale.set(1, 1, 1); if (S.hip) p.position.y = S.hip; }
  faceKeys(S, S.game, 0, 0, 0);
}

function faceKeys(S, game, mo, sm, su) {
  if (!CFG.face || !game || !game.setKey) return;
  const want = { KeyT: mo > .45, KeyY: sm > .5, KeyU: su > .5 };
  for (const c in want) if (S.fk[c] !== want[c]) { S.fk[c] = want[c]; try { game.setKey(c, want[c]); } catch (_) {} }
}
function talk(S, kind) {
  if (!CFG.talk || !S.game || !S.game.say) return;
  if (S.f.talkCd > 0) return;
  const l = LINES[kind]; if (!l) return;
  S.f.talkCd = CFG.talkCooldown;
  try { S.game.say(pick(l), 2200); } catch (_) {}
}

function installNetHooks(S) {
  try {
    window.__HawaFunnyNetPack = function () {
      if (!S || !S.on || S.paused || !S.lastPack) return null;
      return S.lastPack;
    };
    window.__HawaFunnyNetApply = function (remote, pack, dt) {
      if (!remote || !remote.rig || !pack || !pack.on) return;
      if (!remote.__hfMap) remote.__hfMap = mapEngineRig(remote.rig);
      const map = remote.__hfMap;
      if (!map) return;
      applyPoseEngine(map, pack, dt || 0.016);
      
      try {
        if (remote.rig.st || remote.rig.fs) {
          const f = remote.rig.fs || (remote.rig.fs = {});
          if (pack.mo != null) f.mo = pack.mo;
          if (pack.sm != null) f.sm = pack.sm;
          if (pack.su != null) f.su = pack.su;
        }
      } catch (_) {}
    };
  } catch (_) {}
}

function onStart(self, game) {
  const S = self.c = {
    game, rig: null, hip: 0, base: 0, on: CFG.enabled, t: 0, ph: 0, lastX: 0, lastY: 0, lastZ: 0, init: false, hv: 0, vy: 0, toggled: false, paused: false, fk: {},
    lastPack: null, wasSpin: false,
    cur: { pel: [0, 0, 0], waist: [0, 0, 0], chest: [0, 0, 0], head: [0, 0, 0], legL: [0, 0, 0], legR: [0, 0, 0], shinL: [0, 0, 0], shinR: [0, 0, 0], footL: [0, 0, 0], footR: [0, 0, 0], armL: [0, 0, 0], armR: [0, 0, 0], foreL: [0, 0, 0], foreR: [0, 0, 0] },
    f: { sq: 0, sqV: 0, prevAir: false, pvy: 0, jk: 'pedal', jT: 0, fl: 0, gag: '', gT: 0, gD: 1, gNext: 2.5, wc: 0, wNext: 3, wob: 0, talkCd: 0, doomSaid: false }
  };
  installNetHooks(S);
  try {
    window.HawaFunny = {
      on() { S.on = true; try { game.say && game.say('الحركة الفاني: شغّالة 🤪', 1500); } catch (_) {} },
      off() { S.on = false; S.lastPack = null; releaseAll(S); try { game.say && game.say('الحركة الفاني: واقفة', 1500); } catch (_) {} },
      toggle() { S.on ? this.off() : this.on(); },
      say(k) { talk(S, k || 'doom'); },
      state() { return { on: S.on, paused: S.paused, gag: S.f.gag, jump: S.f.jk, bones: S.rig ? Object.keys(S.rig).filter(k => S.rig[k]).join(',') : 'لسه', net: !!(game.isNetworked && game.isNetworked()) }; }
    };
  } catch (_) {}
  try { game.setHud && game.setHud('الحركة الفاني متزامنة · G تشغيل/إيقاف'); } catch (_) {}
}

function onUpdate(self, game, dt) {
  const S = self.c; if (!S) return;
  dt = Math.min(dt, .05); if (dt <= 0) return;
  const pl = game.player, pp = pl && pl.position; if (!pp) return;
  S.game = game; S.t += dt; if (S.f.talkCd > 0) S.f.talkCd -= dt;

  const kd = !!game.key(CFG.toggleKey);
  if (kd && !S.toggled) { S.on ? window.HawaFunny.off() : window.HawaFunny.on(); }
  S.toggled = kd;

  if (!S.init) { S.lastX = pp.x; S.lastY = pp.y; S.lastZ = pp.z; S.init = true; }
  const dx = pp.x - S.lastX, dz = pp.z - S.lastZ, dy = pp.y - S.lastY;
  S.lastX = pp.x; S.lastY = pp.y; S.lastZ = pp.z;
  const jump = Math.hypot(dx, dy, dz) > 3;
  const hv = jump ? S.hv : Math.hypot(dx, dz) / dt, vy = jump ? 0 : dy / dt;
  S.hv = lerp(S.hv, hv, Math.min(1, dt * 12)); S.vy = lerp(S.vy, vy, Math.min(1, dt * 18));

  if (!S.rig) {
    S.rig = discover(game);
    if (!S.rig) return;
    S.hip = S.rig.pelvis.position.y; S.base = pl.mesh.scale.y || 1;
  }
  if (!S.on) { S.lastPack = null; return; }

  const seated = CFG.pauseWhenSeated && pl.mesh && pl.mesh.scale.y < S.base * .95;
  if (seated !== S.paused) { S.paused = seated; if (seated) { releaseAll(S); S.lastPack = null; } }
  if (S.paused) return;

  const grounded = pl.grounded !== undefined ? !!pl.grounded : Math.abs(S.vy) < 1.2;
  const mv = S.hv > .5, run = mv && (!!(game.key('ShiftLeft') || game.key('ShiftRight')) || S.hv > 7.2);
  if (mv && !grounded) {  } else if (mv) S.ph += dt * S.hv * 1.15;
  else S.ph = lerp(S.ph, Math.round(S.ph / PI) * PI, Math.min(1, dt * 6));

  const P = compute(S, { air: !grounded, mv, run, ph: S.ph, vy: S.vy, t: S.t }, dt);
  applyPose(S, P, dt);
  faceKeys(S, game, P.mo, P.sm, P.su);
  
  S.lastPack = packPose(P);
}

function onTouch(self, game, dt) {}
