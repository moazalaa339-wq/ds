

const CFG = {
  playerXSign: -1,       
  faceOffset: 0,         
  hotkeys: true,         
  combat: true,          
  showHud: true,
  
  mobileTouch: true
};

const TAU = Math.PI * 2;
const Z3 = [0, 0, 0];
const ease = t => t * t * (3 - 2 * t);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rnd = (a, b) => a + Math.random() * (b - a);
const chance = p => Math.random() < p;
const pick = a => a[(Math.random() * a.length) | 0];
const deg = d => d * Math.PI / 180;
const rad = r => r * 180 / Math.PI;

function playerPos(game) {
  return (game.player && game.player.position) ? game.player.position : null;
}

const BONE_ENGINE = {
  armR: 'rArm', armL: 'lArm',
  foreR: 'rForearm', foreL: 'lForearm',
  handR: 'rForearm', handL: 'lForearm', 
  legR: 'rLeg', legL: 'lLeg',
  shinR: 'rShin', shinL: 'lShin',
  footR: 'rFoot', footL: 'lFoot',
  torso: 'spine', chest: 'spine', spine: 'spine',
  head: 'head', neck: 'head'
};

const BONE_ALIAS = {
  
  rarm: 'armR', rightarm: 'armR', armr: 'armR', arm_right: 'armR', shoulder_r: 'armR',
  larm: 'armL', leftarm: 'armL', arml: 'armL', arm_left: 'armL', shoulder_l: 'armL',
  rforearm: 'foreR', rightforearm: 'foreR', forearmr: 'foreR', elbow_r: 'foreR',
  lforearm: 'foreL', leftforearm: 'foreL', forearml: 'foreL', elbow_l: 'foreL',
  rhand: 'handR', righthand: 'handR', handr: 'handR',
  lhand: 'handL', lefthand: 'handL', handl: 'handL',
  rleg: 'legR', rightleg: 'legR', legr: 'legR', thigh_r: 'legR', hip_r: 'legR',
  lleg: 'legL', leftleg: 'legL', legl: 'legL', thigh_l: 'legL', hip_l: 'legL',
  rshin: 'shinR', rightshin: 'shinR', shinr: 'shinR', knee_r: 'shinR', calf_r: 'shinR',
  lshin: 'shinL', leftshin: 'shinL', shinl: 'shinL', knee_l: 'shinL', calf_l: 'shinL',
  rfoot: 'footR', rightfoot: 'footR', footr: 'footR', ankle_r: 'footR',
  lfoot: 'footL', leftfoot: 'footL', footl: 'footL', ankle_l: 'footL',
  torso: 'torso', spine: 'torso', chest: 'torso', waist: 'torso', body: 'torso', pelvis: 'torso',
  head: 'head', neck: 'head',
  
  'ذراع': 'armR', 'دراع': 'armR', 'ذراع_يمين': 'armR', 'دراع_يمين': 'armR', 'كتف_يمين': 'armR',
  'ذراع_شمال': 'armL', 'دراع_شمال': 'armL', 'ذراع_يسار': 'armL', 'كتف_شمال': 'armL',
  'ساعد': 'foreR', 'ساعد_يمين': 'foreR', 'كوع_يمين': 'foreR',
  'ساعد_شمال': 'foreL', 'ساعد_يسار': 'foreL', 'كوع_شمال': 'foreL',
  'ايد': 'handR', 'يد': 'handR', 'ايد_يمين': 'handR', 'يد_يمين': 'handR',
  'ايد_شمال': 'handL', 'يد_شمال': 'handL', 'ايد_يسار': 'handL',
  'رجل': 'legR', 'رجل_يمين': 'legR', 'فخذ_يمين': 'legR',
  'رجل_شمال': 'legL', 'رجل_يسار': 'legL', 'فخذ_شمال': 'legL',
  'ساق': 'shinR', 'ساق_يمين': 'shinR', 'ركبة_يمين': 'shinR',
  'ساق_شمال': 'shinL', 'ساق_يسار': 'shinL', 'ركبة_شمال': 'shinL',
  'قدم': 'footR', 'قدم_يمين': 'footR', 'قدم_شمال': 'footL', 'قدم_يسار': 'footL',
  'جذع': 'torso', 'صدر': 'torso', 'بطن': 'torso', 'خصر': 'torso', 'جسم': 'torso',
  'راس': 'head', 'رأس': 'head', 'رقبة': 'head'
};

const BONE_KEYS = ['armR', 'armL', 'foreR', 'foreL', 'legR', 'legL', 'shinR', 'shinL', 'footR', 'footL', 'torso', 'head'];

function resolveBoneKey(name) {
  if (!name) return null;
  const raw = String(name).trim();
  if (BONE_ENGINE[raw]) return raw;
  const k = raw.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_\u0600-\u06ff]/g, '');
  if (BONE_ALIAS[k]) return BONE_ALIAS[k];
  if (BONE_ALIAS[raw]) return BONE_ALIAS[raw];
  
  const eng = raw.toLowerCase().replace(/[^a-z]/g, '');
  if (BONE_ALIAS[eng]) return BONE_ALIAS[eng];
  return null;
}

function axisSign(key, s) {
  return (key === 'torso' || key === 'head') ? -s : s;
}

let RIG_MAP = null; 

function findChildGroup(par, pred) {
  if (!par || !par.children) return null;
  for (const c of par.children) {
    if (c.isMesh) continue;
    if (pred(c)) return c;
  }
  return null;
}

function discoverRig(game) {
  const root = game.player && game.player.mesh;
  if (!root) return {};

  let pelvis = null;
  for (const c of root.children || []) {
    if (c.isMesh) continue;
    if (c.position && c.position.y > 0.25) { pelvis = c; break; }
  }
  if (!pelvis) pelvis = (root.children || []).find(c => !c.isMesh) || null;
  if (!pelvis) return {};

  const waist = findChildGroup(pelvis, g => Math.abs(g.position.x) < 0.06 && g.position.y > 0.02 && g.position.y < 0.25)
             || findChildGroup(pelvis, g => Math.abs(g.position.x) < 0.1 && !g.isMesh);
  const chest = waist ? (findChildGroup(waist, g => g.position.y > 0.04) || findChildGroup(waist, () => true)) : null;

  let armR = null, armL = null, head = null;
  if (chest) {
    for (const c of chest.children || []) {
      if (c.isMesh) continue;
      const x = c.position.x, y = c.position.y;
      if (y > 0.12 && Math.abs(x) < 0.1) head = c;
      if (Math.abs(x) > 0.12 && y > 0.04) {
        if (x > 0) armR = c; else armL = c;
      }
    }
  }
  if (head) {
    const deeper = findChildGroup(head, g => g.position.y >= 0);
    if (deeper) head = deeper;
  }

  function chainDown(node, n) {
    let cur = node;
    const out = [];
    for (let i = 0; i < n && cur; i++) {
      const ch = findChildGroup(cur, g => g.position.y < -0.05) || findChildGroup(cur, () => true);
      if (!ch) break;
      out.push(ch);
      cur = ch;
    }
    return out;
  }

  const armRChain = chainDown(armR, 2);
  const armLChain = chainDown(armL, 2);
  const foreR = armRChain[0] || null;
  const foreL = armLChain[0] || null;

  let legR = null, legL = null;
  for (const c of pelvis.children || []) {
    if (c.isMesh || c === waist) continue;
    if (Math.abs(c.position.x) > 0.04 && c.position.y < 0.15) {
      if (c.position.x > 0) legR = c; else legL = c;
    }
  }
  const legRChain = chainDown(legR, 3);
  const legLChain = chainDown(legL, 3);
  const shinR = legRChain[0] || null, footR = legRChain[1] || null;
  const shinL = legLChain[0] || null, footL = legLChain[1] || null;

  const map = {
    armR, armL, foreR, foreL,
    handR: foreR, handL: foreL,
    legR, legL, shinR, shinL, footR, footL,
    torso: waist || chest, chest: chest || waist, spine: waist || chest,
    head
  };

  
  for (const key of Object.keys(map)) {
    const o = map[key];
    if (!o || o.__hc) continue;
    o.__hc = { on: false, r: [0, 0, 0] };
    const orig = o.updateMatrixWorld;
    o.updateMatrixWorld = function (force) {
      if (o.__hc && o.__hc.on) o.rotation.set(o.__hc.r[0], o.__hc.r[1], o.__hc.r[2]);
      return orig.call(this, force);
    };
  }

  try {
    const ok = BONE_KEYS.filter(k => map[k]).join(',');
    const miss = BONE_KEYS.filter(k => !map[k]).join(',');
    console.log('[HawaCtrl] bones ok:', ok || '—', '| miss:', miss || '—');
  } catch (_) {}
  return map;
}

function applyBone(game, key, rx, ry, rz, locked) {
  if (!RIG_MAP) RIG_MAP = discoverRig(game);
  const o = RIG_MAP[key];
  if (o && o.__hc) {
    o.__hc.on = locked !== false;
    o.__hc.r[0] = rx; o.__hc.r[1] = ry; o.__hc.r[2] = rz;
  }
  const eng = BONE_ENGINE[key];
  if (eng && game.player && typeof game.player.setLimb === 'function') {
    try { game.player.setLimb(eng, rx, ry, rz); } catch (_) {}
  }
  if (eng && typeof game.setPlayerLimb === 'function') {
    try { game.setPlayerLimb(0, eng, rx, ry, rz, { lock: true }); } catch (_) {}
    try { game.setPlayerLimb(eng, rx, ry, rz); } catch (_) {}
  }
}

function releaseBone(key) {
  if (!RIG_MAP) return;
  const o = RIG_MAP[key];
  if (o && o.__hc) o.__hc.on = false;
}

function releaseAllBones() {
  if (!RIG_MAP) return;
  for (const k of Object.keys(RIG_MAP)) releaseBone(k);
}

const ANIMS = {
  
  jab: {
    dur: .45, hit: .42,
    keys: [
      [0, { armR: [-.5, 0, .1], foreR: [1.8, 0, 0], armL: [.9, 0, 0], foreL: [1.9, 0, 0], torso: [0, .35, 0] }],
      [.42, { armR: [1.55, 0, 0], foreR: [.05, 0, 0], armL: [.9, 0, 0], foreL: [1.9, 0, 0], torso: [0, -.45, 0], legR: [-.25, 0, 0], legL: [.2, 0, 0] }],
      [.7, { armR: [1.4, 0, 0], foreR: [.15, 0, 0], torso: [0, -.3, 0] }],
      [1, {}]
    ]
  },
  cross: {
    dur: .5, hit: .44,
    keys: [
      [0, { armL: [-.6, 0, -.1], foreL: [1.9, 0, 0], armR: [.9, 0, 0], foreR: [1.9, 0, 0], torso: [0, -.5, 0] }],
      [.44, { armL: [1.6, 0, 0], foreL: [.05, 0, 0], torso: [0, .7, 0], legR: [.25, 0, 0], legL: [-.3, 0, 0] }],
      [1, {}]
    ]
  },
  hook: {
    dur: .62, hit: .5,
    keys: [
      [0, { armR: [1.3, 0, -1.4], foreR: [1.7, 0, 0], torso: [0, .8, 0], armL: [.9, 0, 0], foreL: [1.9, 0, 0] }],
      [.5, { armR: [1.45, 0, .7], foreR: [1.2, 0, 0], torso: [0, -1, 0], legL: [.3, 0, 0] }],
      [.75, { armR: [1.3, 0, .5], foreR: [1, 0, 0], torso: [0, -.8, 0] }],
      [1, {}]
    ]
  },
  upper: {
    dur: .68, hit: .48,
    keys: [
      [0, { armR: [-.2, 0, 0], foreR: [1, 0, 0], torso: [.45, .3, 0], head: [.2, 0, 0], legR: [.3, 0, 0], legL: [-.3, 0, 0] }],
      [.48, { armR: [2.7, 0, 0], foreR: [.1, 0, 0], torso: [-.25, -.6, 0], head: [-.3, 0, 0] }],
      [.75, { armR: [2.9, 0, 0], torso: [-.3, -.5, 0] }],
      [1, {}]
    ]
  },
  kick: {
    dur: .7, hit: .48,
    keys: [
      [0, { legR: [-.6, 0, 0], torso: [.1, 0, 0], armL: [.6, 0, .8], armR: [.6, 0, -.8] }],
      [.48, { legR: [1.6, 0, 0], shinR: [.4, 0, 0], torso: [-.35, 0, 0], armL: [-.5, 0, .9], armR: [.4, 0, -.9] }],
      [.75, { legR: [1.4, 0, 0], torso: [-.3, 0, 0] }],
      [1, {}]
    ]
  },
  spin: {
    dur: .9, hit: .55,
    keys: [
      [0, { armR: [1, 0, -1.4], foreR: [.3, 0, 0], torso: [0, .4, 0] }],
      [.7, { armR: [1.2, 0, -1.5], torso: [0, -TAU, 0], legR: [.3, 0, 0] }],
      [1, { armR: [1, 0, -1.2], torso: [0, -TAU, 0] }]
    ]
  },
  heavy: {
    dur: 1.0, hit: .55,
    keys: [
      [0, { armR: [2.9, 0, -.2], armL: [2.9, 0, .2], foreR: [.4, 0, 0], foreL: [.4, 0, 0], torso: [-.4, 0, 0], head: [-.2, 0, 0] }],
      [.55, { armR: [.5, 0, 0], armL: [.5, 0, 0], torso: [.65, 0, 0], head: [.3, 0, 0], legR: [.3, 0, 0], legL: [-.2, 0, 0] }],
      [.8, { armR: [.6, 0, 0], armL: [.6, 0, 0], torso: [.5, 0, 0] }],
      [1, {}]
    ]
  },
  sideA: {
    dur: .6, hit: .46,
    keys: [
      [0, { torso: [0, .9, 0], armR: [1.2, 0, -.6], foreR: [1.7, 0, 0], armL: [.8, 0, .3], foreL: [1.6, 0, 0] }],
      [.46, { torso: [0, -1.1, .1], armR: [1.1, 0, .9], foreR: [1.9, 0, 0], legL: [.3, 0, 0], legR: [-.3, 0, 0] }],
      [1, {}]
    ]
  },
  sideB: {
    dur: .7, hit: .5,
    keys: [
      [0, { legR: [.4, 0, -.4], torso: [0, 0, -.2], armL: [.2, 0, 1], armR: [.2, 0, -1] }],
      [.5, { legR: [1.2, 0, -1], torso: [0, 0, .35], armL: [.2, 0, 1.2], armR: [.4, 0, -1.2] }],
      [1, {}]
    ]
  },
  airSlam: {
    dur: .7, hit: .5,
    keys: [
      [0, { armR: [3, 0, -.2], armL: [3, 0, .2], torso: [-.3, 0, 0], legR: [.6, 0, 0], legL: [.5, 0, 0] }],
      [.5, { armR: [.6, 0, 0], armL: [.6, 0, 0], torso: [.6, 0, 0] }],
      [1, { torso: [.3, 0, 0] }]
    ]
  },
  airKick: {
    dur: .6, hit: .45,
    keys: [
      [0, { legR: [.7, 0, 0], legL: [.4, 0, 0], torso: [-.1, 0, 0], armL: [.4, 0, 1], armR: [.4, 0, -1] }],
      [.45, { legR: [1.7, 0, 0], legL: [-.4, 0, 0], torso: [-.5, 0, 0] }],
      [1, { legR: [.9, 0, 0] }]
    ]
  },
  chargeUp: {
    dur: 1.4, hit: null,
    keys: [
      [0, {}],
      [.5, { armR: [-1, 0, -.3], foreR: [2.4, 0, 0], armL: [1.1, 0, .3], foreL: [1.8, 0, 0], torso: [.15, .9, 0], legR: [-.3, 0, -.3], legL: [.3, 0, .3] }],
      [1, { armR: [-1.2, 0, -.3], foreR: [2.6, 0, 0], torso: [.2, 1.1, 0] }]
    ]
  },
  finish: {
    dur: .95, hit: .38,
    keys: [
      [0, { armR: [-1.2, 0, -.3], foreR: [2.6, 0, 0], torso: [.4, 1.1, 0], legR: [.3, 0, 0], legL: [-.3, 0, 0] }],
      [.18, { torso: [.5, -1.6, 0], armR: [.2, 0, 0], foreR: [1, 0, 0] }],
      [.38, { armR: [2.9, 0, 0], foreR: [.05, 0, 0], torso: [-.35, -.5, 0], head: [-.3, 0, 0] }],
      [1, { armR: [2.6, 0, 0], torso: [-.2, -.3, 0] }]
    ]
  },
  
  hurtA: {
    dur: .45,
    keys: [
      [0, {}],
      [.2, { torso: [-.5, .2, 0], head: [-.6, 0, 0], armR: [-.6, 0, -.7], armL: [-.6, 0, .7], legR: [-.3, 0, 0], legL: [.2, 0, 0] }],
      [1, {}]
    ]
  },
  hurtB: {
    dur: .5,
    keys: [
      [0, {}],
      [.2, { torso: [-.2, .8, .3], head: [-.2, .6, 0], armR: [.4, 0, -1], armL: [-.5, 0, .6] }],
      [1, {}]
    ]
  },
  hurtBig: {
    dur: .95,
    keys: [
      [0, {}],
      [.22, { torso: [-.95, 0, 0], head: [-.85, 0, 0], armR: [-1, 0, -1], armL: [-1, 0, 1], legR: [-.5, 0, 0], legL: [.4, 0, 0] }],
      [.6, { torso: [-.6, 0, 0], head: [-.5, 0, 0] }],
      [1, {}]
    ]
  },
  block: {
    dur: .2, loop: true,
    keys: [
      [0, { armR: [1.2, 0, -.35], foreR: [2.3, 0, 0], armL: [1.2, 0, .35], foreL: [2.3, 0, 0], torso: [.15, 0, 0], head: [.1, 0, 0] }],
      [1, { armR: [1.2, 0, -.35], foreR: [2.3, 0, 0], armL: [1.2, 0, .35], foreL: [2.3, 0, 0], torso: [.15, 0, 0], head: [.1, 0, 0] }]
    ]
  },
  kneel: {
    dur: 1, loop: true,
    keys: [
      [0, { torso: [.7, 0, 0], head: [.6, 0, 0], armR: [.2, 0, -.2], armL: [.2, 0, .2], legR: [-.8, 0, 0], legL: [.4, 0, 0] }],
      [1, { torso: [.7, 0, 0], head: [.6, 0, 0], armR: [.2, 0, -.2], armL: [.2, 0, .2], legR: [-.8, 0, 0], legL: [.4, 0, 0] }]
    ]
  },
  
  wave: {
    dur: 1.2, loop: true,
    keys: [
      [0, { armR: [-2.2, 0, -.3], foreR: [.4, 0, 0], torso: [0, -.2, 0] }],
      [.25, { armR: [-2.4, 0, .5], foreR: [.2, 0, 0] }],
      [.5, { armR: [-2.2, 0, -.5], foreR: [.3, 0, 0] }],
      [.75, { armR: [-2.4, 0, .5], foreR: [.2, 0, 0] }],
      [1, { armR: [-2.2, 0, -.3], foreR: [.4, 0, 0] }]
    ]
  },
  clap: {
    dur: .7,
    keys: [
      [0, { armR: [1.0, 0, -.6], armL: [1.0, 0, .6], foreR: [1.2, 0, 0], foreL: [1.2, 0, 0] }],
      [.45, { armR: [1.3, 0, -.15], armL: [1.3, 0, .15], foreR: [1.6, 0, 0], foreL: [1.6, 0, 0], torso: [.1, 0, 0] }],
      [1, {}]
    ]
  },
  point: {
    dur: .8,
    keys: [
      [0, { armR: [.4, 0, 0], foreR: [1.5, 0, 0] }],
      [.4, { armR: [1.6, 0, 0], foreR: [.1, 0, 0], torso: [0, -.3, 0], head: [0, -.2, 0] }],
      [1, { armR: [1.5, 0, 0], foreR: [.15, 0, 0] }]
    ]
  },
  shrug: {
    dur: .9,
    keys: [
      [0, {}],
      [.4, { armR: [-.3, 0, -.9], armL: [-.3, 0, .9], foreR: [1.2, 0, 0], foreL: [1.2, 0, 0], head: [-.15, 0, 0], torso: [.1, 0, 0] }],
      [1, {}]
    ]
  },
  bow: {
    dur: 1.4,
    keys: [
      [0, {}],
      [.45, { torso: [1.1, 0, 0], head: [.5, 0, 0], armR: [.3, 0, -.2], armL: [.3, 0, .2] }],
      [.7, { torso: [1.15, 0, 0], head: [.55, 0, 0] }],
      [1, {}]
    ]
  },
  cheer: {
    dur: 1.1, loop: true,
    keys: [
      [0, { armR: [-2.6, 0, -.4], armL: [-2.6, 0, .4], foreR: [.2, 0, 0], foreL: [.2, 0, 0], torso: [-.15, 0, 0] }],
      [.5, { armR: [-2.9, 0, -.2], armL: [-2.9, 0, .2], torso: [-.25, 0, 0], head: [-.2, 0, 0] }],
      [1, { armR: [-2.6, 0, -.4], armL: [-2.6, 0, .4], torso: [-.15, 0, 0] }]
    ]
  },
  sit: {
    dur: .8, loop: true,
    keys: [
      [0, { legR: [-1.4, 0, .15], legL: [-1.4, 0, -.15], shinR: [1.5, 0, 0], shinL: [1.5, 0, 0], torso: [.15, 0, 0], armR: [.3, 0, -.25], armL: [.3, 0, .25] }],
      [1, { legR: [-1.4, 0, .15], legL: [-1.4, 0, -.15], shinR: [1.5, 0, 0], shinL: [1.5, 0, 0], torso: [.15, 0, 0] }]
    ]
  },
  limp: {
    dur: .6, loop: true,
    keys: [
      [0, { armR: [.3, 0, -.5], armL: [.3, 0, .5], torso: [-.3, 0, 0], head: [-.4, 0, 0], legR: [.3, 0, 0], legL: [-.2, 0, 0] }],
      [1, { armR: [.3, 0, -.5], armL: [.3, 0, .5], torso: [-.3, 0, 0], head: [-.4, 0, 0], legR: [.3, 0, 0], legL: [-.2, 0, 0] }]
    ]
  },
  rest: {
    dur: .35,
    keys: [[0, {}], [1, {}]]
  }
};

const COMBOS = [
  ['jab', 'cross', 'jab', 'hook'],
  ['cross', 'hook', 'kick', 'upper'],
  ['hook', 'kick', 'spin', 'upper'],
  ['kick', 'spin', 'heavy', 'upper']
];

const HOTKEY_ANIMS = ['jab', 'cross', 'hook', 'upper', 'kick', 'wave', 'clap', 'cheer', 'bow'];

function evalAnim(an, u) {
  const ks = an.keys;
  u = clamp(u, 0, 1);
  let i = 0;
  while (i < ks.length - 2 && u > ks[i + 1][0]) i++;
  const a = ks[i], b = ks[Math.min(i + 1, ks.length - 1)];
  const span = Math.max(1e-4, b[0] - a[0]);
  const f = ease(clamp((u - a[0]) / span, 0, 1));
  const out = {};
  const bones = new Set([...Object.keys(a[1] || {}), ...Object.keys(b[1] || {})]);
  for (const l of bones) {
    const pa = (a[1] && a[1][l]) || Z3;
    const pb = (b[1] && b[1][l]) || Z3;
    out[l] = [
      pa[0] + (pb[0] - pa[0]) * f,
      pa[1] + (pb[1] - pa[1]) * f,
      pa[2] + (pb[2] - pa[2]) * f
    ];
  }
  return out;
}

function blendPose(pose, target, dt, rate) {
  const k = Math.min(1, dt * rate);
  let mx = 0;
  const keys = new Set([...Object.keys(pose), ...Object.keys(target)]);
  for (const l of keys) {
    const t = target[l] || Z3;
    const c = pose[l] || (pose[l] = [0, 0, 0]);
    for (let i = 0; i < 3; i++) {
      c[i] += (t[i] - c[i]) * k;
      mx = Math.max(mx, Math.abs(c[i] - t[i]));
    }
  }
  return mx;
}

function wrapPose(pose) {
  for (const l of Object.keys(pose)) {
    const c = pose[l]; if (!c) continue;
    for (let i = 0; i < 3; i++) {
      if (Math.abs(c[i]) > Math.PI) c[i] -= Math.round(c[i] / TAU) * TAU;
    }
  }
}

function findObject(game, name) {
  if (!name) return null;
  
  if (typeof game.find === 'function') {
    const o = game.find(name);
    if (o) return o;
  }
  
  const scene = game.scene;
  if (!scene) return null;
  let found = null;
  const want = String(name).toLowerCase();
  scene.traverse(obj => {
    if (found) return;
    if (obj.name && obj.name.toLowerCase() === want) found = obj;
  });
  if (found) return { mesh: found, position: found.position, rotation: found.rotation, scale: found.scale, name: found.name };
  
  scene.traverse(obj => {
    if (found) return;
    if (obj.name && obj.name.toLowerCase().includes(want)) found = obj;
  });
  if (found) return { mesh: found, position: found.position, rotation: found.rotation, scale: found.scale, name: found.name };
  return null;
}

function listSceneObjects(game) {
  const out = [];
  if (typeof game.find === 'function') {
    
  }
  const scene = game.scene;
  if (!scene) return out;
  scene.traverse(obj => {
    if (obj.name && obj.name.length && !obj.isCamera && !obj.isLight) {
      out.push({
        name: obj.name,
        type: obj.type,
        x: +obj.position.x.toFixed(2),
        y: +obj.position.y.toFixed(2),
        z: +obj.position.z.toFixed(2)
      });
    }
  });
  return out;
}

function buildUI(S) {
  document.querySelectorAll('#hawa-cmb-ui,[data-hawa-combat-ui],[data-hawa-ctrl-ui]').forEach(el => {
    try { el.remove(); } catch (_) {}
  });
  if (!CFG.showHud) { S.ui = null; return; }

  const w = document.createElement('div');
  w.id = 'hawa-cmb-ui';
  w.setAttribute('data-script-ui', '1');
  w.setAttribute('data-hawa-ctrl-ui', '1');
  w.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:9999;font-family:system-ui,Segoe UI,Tahoma,sans-serif;color:#fff;display:none';
  w.innerHTML =
    '<div id="hc-top" style="position:absolute;left:0;right:0;top:0;height:0;background:#000;transition:height .6s"></div>' +
    '<div id="hc-bot" style="position:absolute;left:0;right:0;bottom:0;height:0;background:#000;transition:height .6s"></div>' +
    '<div id="hc-flash" style="position:absolute;inset:0;background:#fff;opacity:0"></div>' +
    '<div id="hc-red" style="position:absolute;inset:0;box-shadow:inset 0 0 140px 40px #c0120c;opacity:0"></div>' +
    '<div id="hc-eb" style="position:absolute;top:18px;left:50%;transform:translateX(-50%);width:min(460px,70vw);display:none">' +
      '<div style="text-align:center;font-weight:700;letter-spacing:1px;text-shadow:0 2px 6px #000;margin-bottom:4px">عفريت الجمر</div>' +
      '<div style="height:16px;background:#1b0c0c;border:2px solid #000;border-radius:9px;overflow:hidden;position:relative">' +
        '<div id="hc-ghost" style="position:absolute;inset:0;width:100%;background:#f1c40f"></div>' +
        '<div id="hc-fill" style="position:absolute;inset:0;width:100%;background:linear-gradient(#ff5a3c,#b3150d)"></div></div></div>' +
    '<div id="hc-pb" style="position:absolute;left:18px;bottom:18px;width:220px">' +
      '<div style="height:10px;background:#0b1a10;border:2px solid #000;border-radius:7px;overflow:hidden">' +
        '<div id="hc-pf" style="height:100%;width:100%;background:#34d399"></div></div></div>' +
    '<div id="hc-toast" style="position:absolute;top:34%;left:50%;transform:translate(-50%,-50%);font-size:36px;font-weight:900;text-shadow:0 3px 10px #000;opacity:0;transition:opacity .25s,transform .25s"></div>' +
    '<div id="hc-hint" style="position:absolute;right:14px;bottom:14px;font-size:12px;opacity:.75;text-shadow:0 1px 4px #000;text-align:right;line-height:1.5"></div>';
  document.body.appendChild(w);
  S.ui = {
    w,
    top: w.querySelector('#hc-top'), bot: w.querySelector('#hc-bot'),
    flash: w.querySelector('#hc-flash'), red: w.querySelector('#hc-red'),
    eb: w.querySelector('#hc-eb'), fill: w.querySelector('#hc-fill'),
    ghost: w.querySelector('#hc-ghost'), pf: w.querySelector('#hc-pf'),
    toast: w.querySelector('#hc-toast'), hint: w.querySelector('#hc-hint')
  };
  S.ui.hint.innerHTML = 'ضرب: كليك شمال · حماية: يمين · E: شرير<br>1–9 أنيميشن · HawaCtrl في الكونسول';
}

function showUI(S, on) {
  if (!S.ui || !S.ui.w) return;
  S.ui.w.style.display = on ? 'block' : 'none';
}

function toast(S, txt, col) {
  if (!S.ui) return;
  const t = S.ui.toast;
  t.textContent = txt; t.style.color = col || '#fff';
  t.style.opacity = 1; t.style.transform = 'translate(-50%,-50%) scale(1.12)';
  clearTimeout(S.toastT);
  S.toastT = setTimeout(() => {
    t.style.opacity = 0; t.style.transform = 'translate(-50%,-50%) scale(1)';
  }, 800);
}

function flash(S, a, ms) {
  if (!S.ui) return;
  const f = S.ui.flash;
  f.style.transition = 'none'; f.style.opacity = a;
  requestAnimationFrame(() => {
    f.style.transition = 'opacity ' + (ms || 300) + 'ms';
    f.style.opacity = 0;
  });
}

function burst(S, game, x, y, z, col, n, spd) {
  const T = game.THREE;
  for (let i = 0; i < n; i++) {
    const m = new T.Mesh(S.sg, new T.MeshBasicMaterial({ color: col, transparent: true }));
    m.position.set(x, y, z); game.scene.add(m);
    S.parts.push({ m, vx: rnd(-1, 1) * spd, vy: rnd(.3, 1.2) * spd, vz: rnd(-1, 1) * spd, life: rnd(.35, .7) });
  }
}
function ring(S, game, x, y, z, col) {
  const T = game.THREE;
  const m = new T.Mesh(
    new T.RingGeometry(.5, .66, 48),
    new T.MeshBasicMaterial({ color: col, transparent: true, side: T.DoubleSide })
  );
  m.rotation.x = -Math.PI / 2; m.position.set(x, y + .05, z);
  game.scene.add(m); S.rings.push({ m, t: 0 });
}
function fxStep(S, game, dt) {
  for (let i = S.parts.length - 1; i >= 0; i--) {
    const p = S.parts[i];
    p.life -= dt; p.vy -= 12 * dt;
    p.m.position.x += p.vx * dt; p.m.position.y += p.vy * dt; p.m.position.z += p.vz * dt;
    p.m.material.opacity = Math.max(0, p.life * 2);
    if (p.life <= 0) { game.scene.remove(p.m); p.m.material.dispose(); S.parts.splice(i, 1); }
  }
  for (let i = S.rings.length - 1; i >= 0; i--) {
    const r = S.rings[i]; r.t += dt; const k = r.t / .7;
    r.m.scale.setScalar(1 + k * 9); r.m.material.opacity = Math.max(0, 1 - k);
    if (k >= 1) {
      game.scene.remove(r.m); r.m.geometry.dispose(); r.m.material.dispose(); S.rings.splice(i, 1);
    }
  }
  const cam = game.camera;
  if (cam && S.lastShake) {
    cam.position.sub(S.lastShake);
    if (S.shake > 0.001) {
      S.lastShake.set(rnd(-1, 1) * S.shake, rnd(-1, 1) * S.shake, rnd(-1, 1) * S.shake);
      cam.position.add(S.lastShake);
      S.shake *= Math.exp(-9 * dt);
    } else S.lastShake.set(0, 0, 0);
  }
  if (S.ui) {
    const rd = parseFloat(S.ui.red.style.opacity) || 0;
    if (rd > 0) S.ui.red.style.opacity = Math.max(0, rd - dt * 2.2);
  }
}

function box(T, w, h, d, col, y, glow) {
  const m = new T.Mesh(
    new T.BoxGeometry(w, h, d),
    new T.MeshStandardMaterial({
      color: col, roughness: .55, metalness: .45,
      emissive: glow || 0x000000, emissiveIntensity: glow ? 1.5 : 0, transparent: true
    })
  );
  m.position.y = y || 0; return m;
}
function cone(T, r, h, col, glow) {
  return new T.Mesh(
    new T.ConeGeometry(r, h, 6),
    new T.MeshStandardMaterial({
      color: col, roughness: .5,
      emissive: glow || 0x000000, emissiveIntensity: glow ? 1.2 : 0, transparent: true
    })
  );
}
function buildEnemy(game) {
  const T = game.THREE, ARM = 0x241d2b, PLATE = 0x5a1717, EMB = 0xff3b1e, BONE = 0xd9cdb0;
  const root = new T.Group(), parts = {};
  const torso = new T.Group(); torso.position.y = 1.1; root.add(torso); parts.torso = torso;
  torso.add(box(T, 1.15, 1.25, .7, ARM, .62));
  torso.add(box(T, .8, .7, .1, PLATE, .8)).position.z = .38;
  const core = new T.Mesh(
    new T.SphereGeometry(.17, 12, 10),
    new T.MeshStandardMaterial({ color: EMB, emissive: EMB, emissiveIntensity: 2.2, transparent: true })
  );
  core.position.set(0, .8, .46); torso.add(core);
  const head = new T.Group(); head.position.y = 1.3; torso.add(head); parts.head = head;
  head.add(box(T, .56, .6, .56, ARM, .3));
  const eye = box(T, .46, .09, .05, EMB, .36, EMB); eye.position.z = .29; head.add(eye);
  for (const s of [-1, 1]) {
    const h = cone(T, .09, .62, BONE); h.position.set(s * .24, .72, 0); h.rotation.z = -s * .35; head.add(h);
  }
  const arm = side => {
    const p = new T.Group(); p.position.set(side * .82, 1.05, 0); torso.add(p);
    p.add(box(T, .36, .82, .36, ARM, -.41));
    const sp = cone(T, .14, .5, BONE); sp.position.set(side * .22, .1, 0); sp.rotation.z = -side * 1.1; p.add(sp);
    const f = new T.Group(); f.position.y = -.82; p.add(f);
    f.add(box(T, .31, .75, .31, PLATE, -.375));
    f.add(box(T, .44, .44, .44, ARM, -.85, EMB));
    return { p, f };
  };
  const aR = arm(1), aL = arm(-1);
  parts.armR = aR.p; parts.foreR = aR.f; parts.armL = aL.p; parts.foreL = aL.f;
  const leg = side => {
    const p = new T.Group(); p.position.set(side * .3, 1.1, 0); root.add(p);
    p.add(box(T, .44, 1.1, .44, ARM, -.55));
    p.add(box(T, .5, .2, .7, PLATE, -1.05)).position.z = .1;
    return p;
  };
  parts.legR = leg(1); parts.legL = leg(-1);
  return { root, parts };
}

const EATT = {
  jab: { an: 'jab', dur: .6, hit: .42, dmg: 5, reach: 2.5 },
  hook: { an: 'hook', dur: .85, hit: .5, dmg: 8, reach: 2.6 },
  kick: { an: 'kick', dur: .8, hit: .48, dmg: 9, reach: 2.9 },
  upper: { an: 'upper', dur: .9, hit: .5, dmg: 11, reach: 2.4, heavy: true },
  smash: { an: 'heavy', dur: 1.3, hit: .58, dmg: 15, reach: 3.0, heavy: true, armor: true }
};
const E_GUARD = { armR: [.5, 0, -.1], foreR: [1.5, 0, 0], armL: [.5, 0, .1], foreL: [1.5, 0, 0], torso: [.12, 0, 0] };

let STATE = null; 
let GAME_REF = null;

function faceTo(game, ang) {
  const p = game.player; if (!p) return;
  const a = ang + CFG.faceOffset;
  try { if (p.mesh && p.mesh.rotation) p.mesh.rotation.y = a; } catch (_) {}
}

function startPlayerAnim(S, name, opt) {
  opt = opt || {};
  const an = ANIMS[name];
  if (!an) { console.warn('[HawaCtrl] anim not found:', name); return false; }
  S.anim = an;
  S.an = name;
  S.at = 0;
  S.hitDone = false;
  S.sp = opt.speed || 1;
  S.dm = opt.damage || 1;
  S.hurt = !!opt.hurt;
  S.animHold = !!opt.hold; 
  if (opt.toast !== false && S.ui) toast(S, name, '#a5b4fc');
  return true;
}

function applyPoseToPlayer(game, S, pose, active) {
  if (!active) { releaseAllBones(); return; }
  for (const l of Object.keys(pose)) {
    const c = pose[l];
    if (!c) continue;
    const sx = axisSign(l, CFG.playerXSign);
    applyBone(game, l, c[0] * sx, c[1], c[2], true);
  }
}

const HawaCtrl = {
  
  play(name, opt) {
    if (!STATE || !GAME_REF) return false;
    return startPlayerAnim(STATE, name, opt);
  },
  stop() {
    if (!STATE) return;
    STATE.anim = null; STATE.an = null; STATE.hurt = false;
    releaseAllBones();
  },
  
  set(boneName, rot, opt) {
    if (!GAME_REF) return false;
    const key = resolveBoneKey(boneName);
    if (!key) { console.warn('[HawaCtrl] bone?', boneName); return false; }
    opt = opt || {};
    let x = rot.x != null ? rot.x : (rot[0] != null ? rot[0] : 0);
    let y = rot.y != null ? rot.y : (rot[1] != null ? rot[1] : 0);
    let z = rot.z != null ? rot.z : (rot[2] != null ? rot[2] : 0);
    if (opt.deg) { x = deg(x); y = deg(y); z = deg(z); }
    if (!STATE) return false;
    STATE.manual = STATE.manual || {};
    STATE.manual[key] = [x, y, z];
    STATE.manualOn = true;
    applyBone(GAME_REF, key, x * axisSign(key, CFG.playerXSign), y, z, true);
    return true;
  },
  
  release(boneName) {
    if (!boneName) {
      if (STATE) { STATE.manual = {}; STATE.manualOn = false; }
      releaseAllBones();
      return;
    }
    const key = resolveBoneKey(boneName);
    if (!key) return;
    if (STATE && STATE.manual) delete STATE.manual[key];
    releaseBone(key);
  },
  
  move(name, pos, opt) {
    const o = findObject(GAME_REF, name);
    if (!o || !o.position) { console.warn('[HawaCtrl] object?', name); return false; }
    opt = opt || {};
    if (pos.x != null) o.position.x = pos.x;
    if (pos.y != null) o.position.y = pos.y;
    if (pos.z != null) o.position.z = pos.z;
    if (opt.dx) o.position.x += opt.dx;
    if (opt.dy) o.position.y += opt.dy;
    if (opt.dz) o.position.z += opt.dz;
    return true;
  },
  
  rotate(name, rot, opt) {
    const o = findObject(GAME_REF, name);
    if (!o || !o.rotation) return false;
    opt = opt || {};
    let x = rot.x || 0, y = rot.y || 0, z = rot.z || 0;
    if (opt.deg) { x = deg(x); y = deg(y); z = deg(z); }
    if (rot.x != null) o.rotation.x = x;
    if (rot.y != null) o.rotation.y = y;
    if (rot.z != null) o.rotation.z = z;
    return true;
  },
  scale(name, s) {
    const o = findObject(GAME_REF, name);
    if (!o || !o.scale) return false;
    if (typeof s === 'number') o.scale.setScalar(s);
    else o.scale.set(s.x != null ? s.x : 1, s.y != null ? s.y : 1, s.z != null ? s.z : 1);
    return true;
  },
  show(name, v) {
    const o = findObject(GAME_REF, name);
    if (!o) return false;
    if (typeof o.show === 'function' && v !== false) o.show();
    else if (typeof o.hide === 'function' && v === false) o.hide();
    else if (o.mesh) o.mesh.visible = v !== false;
    return true;
  },
  hide(name) { return this.show(name, false); },
  color(name, hex) {
    const o = findObject(GAME_REF, name);
    if (!o) return false;
    const mesh = o.mesh || o;
    const c = typeof hex === 'number' ? hex : parseInt(String(hex).replace('#', ''), 16);
    mesh.traverse && mesh.traverse(ch => {
      if (ch.isMesh && ch.material && ch.material.color) ch.material.color.setHex(c);
    });
    if (mesh.isMesh && mesh.material && mesh.material.color) mesh.material.color.setHex(c);
    return true;
  },
  
  teleport(x, y, z) {
    const p = playerPos(GAME_REF);
    if (!p) return false;
    if (x != null) p.x = x; if (y != null) p.y = y; if (z != null) p.z = z;
    return true;
  },
  face(yawRad) {
    if (!GAME_REF) return false;
    faceTo(GAME_REF, yawRad);
    return true;
  },
  setSpeed(mul) {
    try { GAME_REF.player.setSpeed(mul); return true; } catch (_) { return false; }
  },
  say(msg) {
    try { GAME_REF.say && GAME_REF.say(msg); } catch (_) {}
    if (STATE) toast(STATE, msg, '#e2e8f0');
  },
  
  defineAnim(name, def) {
    if (!name || !def || !def.keys) return false;
    ANIMS[name] = {
      dur: def.dur || 1,
      hit: def.hit != null ? def.hit : null,
      loop: !!def.loop,
      keys: def.keys
    };
    return true;
  },
  listAnims() { return Object.keys(ANIMS).sort(); },
  listBones() {
    return {
      keys: BONE_KEYS.slice(),
      aliases: Object.keys(BONE_ALIAS),
      found: RIG_MAP ? BONE_KEYS.filter(k => RIG_MAP[k]) : []
    };
  },
  listObjects() { return listSceneObjects(GAME_REF); },
  getPose() { return STATE && STATE.pose ? JSON.parse(JSON.stringify(STATE.pose)) : {}; },
  
  cmd(text) {
    const t = String(text || '').trim();
    if (!t) return false;
    
    let m = /^play\s+(\S+)/i.exec(t) || /^شغ[ل]*\s+(\S+)/.exec(t);
    if (m) return this.play(m[1]);
    m = /^set\s+(\S+)\s+(-?[\d.]+)\s*(-?[\d.]*)\s*(-?[\d.]*)/i.exec(t);
    if (m) return this.set(m[1], { x: +m[2], y: +(m[3] || 0), z: +(m[4] || 0) });
    m = /^move\s+(\S+)\s+(-?[\d.]+)\s*(-?[\d.]*)\s*(-?[\d.]*)/i.exec(t);
    if (m) return this.move(m[1], { x: +m[2], y: m[3] !== '' ? +m[3] : undefined, z: m[4] !== '' ? +m[4] : undefined });
    if (/^stop|وقف|إيقاف/i.test(t)) { this.stop(); return true; }
    if (/^list|قائمة/i.test(t)) {
      console.log('anims', this.listAnims());
      console.log('bones', this.listBones());
      return true;
    }
    
    if (ANIMS[t]) return this.play(t);
    console.warn('[HawaCtrl] cmd?', t);
    return false;
  },
  help() {
    const msg = [
      'HawaCtrl.play("jab"|"wave"|"kick"|...)',
      'HawaCtrl.set("ذراع_يمين"| "rArm", {x,y,z})',
      'HawaCtrl.move("اسم", {x,y,z})',
      'HawaCtrl.rotate / scale / hide / show / color',
      'HawaCtrl.defineAnim("اسم", {dur, keys:[[t,{bone:[x,y,z]}],...]} )',
      'HawaCtrl.listAnims() listBones() listObjects()',
      'HawaCtrl.cmd("play wave")'
    ].join('\n');
    console.log(msg);
    return msg;
  }
};

try { window.HawaCtrl = HawaCtrl; } catch (_) {}

function damageEnemy(self, game, dmg, heavy, crit) {
  const S = self.c, e = S.en, pp = playerPos(game);
  if (!e) return;
  if (e.guarding) {
    dmg *= .25;
    burst(S, game, e.x, e.root.position.y + 1.4, e.z, 0x9ad0ff, 8, 4);
    toast(S, 'محجوب', '#9ad0ff');
  }
  e.hp -= dmg;
  if (e.hp <= 0 && !S.cut) {
    e.hp = 0; barUpdate(S); startCut(self, game); return;
  }
  barUpdate(S);
  S.landed++; game.addScore(Math.round(dmg));
  S.freeze = heavy ? .09 : .05;
  S.shake = Math.max(S.shake, heavy ? .22 : .09);
  const dx = e.x - pp.x, dz = e.z - pp.z, L = Math.hypot(dx, dz) || 1;
  e.vx = dx / L * (heavy ? 7 : 3.2);
  e.vz = dz / L * (heavy ? 7 : 3.2);
  burst(S, game, e.x - dx / L * .5, e.root.position.y + 1.3, e.z - dz / L * .5,
    crit ? 0xffe066 : 0xff7a3c, crit ? 18 : 9, crit ? 6 : 4);
  if (crit) toast(S, 'ضربة حرجة!', '#ffe066');
  const armor = e.cur && e.cur.armor && e.at / e.cur.dur < e.cur.hit;
  if (!armor && !e.guarding) {
    e.state = 'stagger'; e.cur = null; e.t = 0;
    e.hurtAn = heavy ? ANIMS.hurtBig : pick([ANIMS.hurtA, ANIMS.hurtB]);
    e.hurtT = 0;
  }
}

function barUpdate(S) {
  const e = S.en; if (!e || !S.ui) return;
  const p = Math.max(0, e.hp / e.max) * 100;
  S.ui.fill.style.width = p + '%';
  S.ui.ghost.style.width = Math.max(p, parseFloat(S.ui.ghost.style.width) - .6) + '%';
}

function hitPlayer(self, game, att) {
  const S = self.c, e = S.en, pp = playerPos(game);
  const dx = pp.x - e.x, dz = pp.z - e.z, L = Math.hypot(dx, dz) || 1;
  if (S.block) {
    if (S.blockT < .28) {
      toast(S, 'صدّ مثالي!', '#7dd3fc');
      burst(S, game, pp.x, pp.y + 1.3, pp.z, 0x7dd3fc, 16, 5);
      ring(S, game, e.x, S.gY, e.z, 0x7dd3fc);
      e.state = 'stagger'; e.cur = null; e.t = 0;
      e.hurtAn = ANIMS.hurtBig; e.hurtT = 0;
      e.vx = -dx / L * 4; e.vz = -dz / L * 4; S.freeze = .1;
    } else {
      burst(S, game, pp.x, pp.y + 1.3, pp.z, 0xbbbbbb, 7, 3);
      S.kb.x = dx / L * 2.5; S.kb.z = dz / L * 2.5;
    }
    S.shake = Math.max(S.shake, .1);
    return;
  }
  S.freeze = .06;
  S.shake = Math.max(S.shake, att.heavy ? .3 : .14);
  if (S.ui) S.ui.red.style.opacity = att.heavy ? .85 : .5;
  burst(S, game, pp.x, pp.y + 1.2, pp.z, 0xff3030, att.heavy ? 14 : 7, 4);
  S.kb.x = dx / L * (att.heavy ? 9 : 4);
  S.kb.z = dz / L * (att.heavy ? 9 : 4);
  S.pHp = Math.max(.12, S.pHp - att.dmg / 120);
  if (S.ui) S.ui.pf.style.width = (S.pHp * 100) + '%';
  startPlayerAnim(S, att.heavy ? 'hurtBig' : pick(['hurtA', 'hurtB']), { hurt: true, toast: false });
  S.comboT = 0; S.combo = 0;
}

function startAttack(self, game) {
  const S = self.c, pp = playerPos(game), e = S.en;
  const tier = Math.min(3, Math.floor(S.landed / 4));
  const sp = 1 + tier * .15;
  let dm = 1 + tier * .35, name;
  if (S.air) { name = pick(['airSlam', 'airKick']); dm *= 1.2; }
  else if (game.key('KeyD') && !game.key('KeyA')) { name = pick(['sideA', 'sideB']); dm *= 1.15; }
  else {
    const list = COMBOS[tier];
    name = chance(.25) ? pick(list) : list[S.combo % list.length];
    S.combo++;
  }
  if (S.tier !== tier) {
    S.tier = tier;
    if (tier > 0) toast(S, 'مستوى ضرب ' + (tier + 1), '#ff9f43');
  }
  startPlayerAnim(S, name, { speed: sp, damage: dm, toast: false });
  S.comboT = 1.1;
  if (e && e.state !== 'dead') {
    const d = Math.hypot(e.x - pp.x, e.z - pp.z);
    if (d < 7) faceTo(game, Math.atan2(e.x - pp.x, e.z - pp.z));
  }
}

function startCut(self, game) {
  const S = self.c, e = S.en, pp = playerPos(game), T = game.THREE;
  const ax = e.x - pp.x, az = e.z - pp.z, L = Math.hypot(ax, az) || 1;
  e.state = 'fin'; e.cur = null; e.vx = e.vz = 0;
  S.cut = {
    t: 0, ax: ax / L, az: az / L, px0: pp.x, pz0: pp.z, ex: e.x, ez: e.z, gy: S.gY, fl: {},
    camOff: new T.Vector3().copy(game.camera.position).sub(new T.Vector3(pp.x, pp.y, pp.z)),
    fov: game.camera.fov
  };
  S.anim = null; S.hurt = false; S.block = false; S.slow = 1; S.kb.x = S.kb.z = 0;
  if (S.ui) { S.ui.top.style.height = '11vh'; S.ui.bot.style.height = '11vh'; S.ui.eb.style.display = 'none'; }
  e.A.pose = {}; e.hurtAn = ANIMS.kneel; e.hurtT = 0;
  faceTo(game, Math.atan2(ax, az));
}

function cutStep(self, game, dt) {
  const S = self.c, c = S.cut, e = S.en, pp = playerPos(game), cam = game.camera, T = game.THREE;
  if (!c || !e) { S.cut = null; return; }
  c.t += dt;
  const t = c.t, gy = c.gy, ax = c.ax, az = c.az, nx = -az, nz = ax;
  try {
    game.forcePlayerInput(0, {
      up: false, down: false, left: false, right: false,
      jump: false, run: false, interact: false, action: false
    });
  } catch (_) {}
  const sdt = dt * S.slow;
  const px = (x, z) => { pp.x = x; pp.z = z; if (pp.y < gy) pp.y = gy; };
  const sx = c.ex - ax * 3.2, sz = c.ez - az * 3.2;
  const dx2 = c.ex - ax * 1.7, dz2 = c.ez - az * 1.7;
  const setC = (x, y, z, lx, ly, lz) => { cam.position.set(x, y, z); cam.lookAt(lx, ly, lz); };
  const setFov = f => { if (cam.fov !== f) { cam.fov = f; cam.updateProjectionMatrix && cam.updateProjectionMatrix(); } };
  const mx = (c.px0 + c.ex) / 2, mz = (c.pz0 + c.ez) / 2;
  faceTo(game, Math.atan2(ax, az));

  if (t < .6) {
    const k = ease(t / .6);
    px(c.px0 + (sx - c.px0) * k, c.pz0 + (sz - c.pz0) * k);
  }
  if (t < 1.4) {
    const k = ease(t / 1.4); setFov(55);
    setC(mx + nx * (7.5 - 3 * k), gy + .8 + .4 * k, mz + nz * (7.5 - 3 * k), mx, gy + 1.3, mz);
  } else if (t < 2.8) {
    if (!c.fl.ch) { c.fl.ch = 1; startPlayerAnim(S, 'chargeUp', { toast: false }); }
    const k = (t - 1.4) / 1.4; setFov(48 - 6 * k);
    setC(sx + nx * (2.6 - .5 * k) - ax * .5, gy + 1 + .3 * k, sz + nz * (2.6 - .5 * k) - az * .5, sx, gy + 1.3, sz);
    burst(S, game, sx + ax * .4, gy + 1.5, sz + az * .4, 0xffa94d, 2, 2.5);
    S.shake = .015 + .03 * k;
  } else if (t < 3.1) {
    const k = ease((t - 2.8) / .3);
    px(sx + (dx2 - sx) * k, sz + (dz2 - sz) * k); setFov(62);
    setC(pp.x + nx * 3.2 - ax * 2, gy + 1.1, pp.z + nz * 3.2 - az * 2, pp.x, gy + 1.2, pp.z);
  }
  if (t >= 3.1 && !c.fl.fin) { c.fl.fin = 1; px(dx2, dz2); startPlayerAnim(S, 'finish', { toast: false }); }
  if (t >= 3.1) {
    if (t >= 3.42 && !c.fl.hit) {
      c.fl.hit = 1; flash(S, .95, 450); S.freeze = .2; S.slow = .18; S.shake = .5;
      e.vx = ax * 9; e.vz = az * 9; e.vy = 10; e.fly = true; e.spin = 6;
      burst(S, game, c.ex, gy + 1.4, c.ez, 0xffd36b, 40, 8);
      burst(S, game, c.ex, gy + 1.4, c.ez, 0xff4d2e, 30, 6);
      ring(S, game, c.ex, gy, c.ez, 0xffd36b);
      c.ix = c.ex + ax * .2; c.iz = c.ez + az * .2;
    }
    if (c.fl.hit && t < 5.2) {
      const k = t - 3.42; setFov(42); const ang = k * .75, rr = 4.2;
      setC(
        c.ix + (nx * Math.cos(ang) - ax * Math.sin(ang)) * rr,
        gy + .6 + k * .5,
        c.iz + (nz * Math.cos(ang) - az * Math.sin(ang)) * rr,
        c.ix, gy + 1.3, c.iz
      );
      if (t > 4.4 && S.slow < 1) S.slow = Math.min(1, S.slow + dt * .8);
    } else if (!c.fl.hit) {
      setC(pp.x + nx * 3.2 - ax * 2, gy + 1.1, pp.z + nz * 3.2 - az * 2, pp.x + ax, gy + 1.2, pp.z + az);
    }
  }
  if (t >= 5.2 && t < 6.3) {
    S.slow = 1; setFov(50);
    setC(mx + nx * 7, gy + 3.2, mz + nz * 7, e.x, gy + .4, e.z);
    if (!c.fl.ko) { c.fl.ko = 1; toast(S, 'K.O.', '#ff5a3c'); }
    const k = (t - 5.3) / .9;
    if (k > 0) {
      const s = Math.max(.001, 1 - ease(Math.min(1, k)));
      e.root.scale.setScalar(s);
      burst(S, game, e.x, gy + .6, e.z, 0xff6a3c, 1, 2);
    }
  }
  if (t >= 6.3) {
    if (!c.fl.rt) {
      c.fl.rt = 1; c.rs = new T.Vector3().copy(cam.position);
      game.scene.remove(e.root); S.en = null;
      if (S.ui) { S.ui.top.style.height = '0'; S.ui.bot.style.height = '0'; }
      setFov(c.fov);
    }
    const k = ease(Math.min(1, (t - 6.3) / .8));
    const tg = new T.Vector3(pp.x, pp.y, pp.z).add(c.camOff);
    cam.position.lerpVectors(c.rs, tg, k);
    cam.lookAt(pp.x, pp.y + 1.2, pp.z);
    if (k >= 1) {
      S.cut = null; S.slow = 1;
      try { game.forcePlayerInput(0, null); } catch (_) {}
      S.landed = 0; S.tier = 0; S.pHp = 1;
      if (S.ui) S.ui.pf.style.width = '100%';
    }
  }
  if (S.en && e.fly) {
    e.vy -= 22 * sdt;
    e.x += e.vx * sdt; e.z += e.vz * sdt;
    e.root.position.y += e.vy * sdt;
    e.root.rotation.x -= e.spin * sdt;
    if (e.root.position.y <= gy + .35) {
      e.root.position.y = gy + .35;
      if (e.vy < -4) {
        e.vy = -e.vy * .3; e.vx *= .5; e.vz *= .5; S.shake = .3;
        burst(S, game, e.x, gy + .2, e.z, 0xcccccc, 12, 4);
      } else { e.fly = false; e.vx = e.vz = 0; }
    }
    e.root.position.x = e.x; e.root.position.z = e.z;
  }
  
  playerAnimStep(S, game, sdt);
  fxStep(S, game, dt);
}

function enemyApplyPose(e, pose) {
  for (const l of Object.keys(pose)) {
    const c = pose[l], g = e.parts[l];
    if (g && c) g.rotation.set(c[0] * axisSign(l, -1), c[1], c[2]);
  }
}

function enemyStep(self, game, sdt) {
  const S = self.c, e = S.en; if (!e) return;
  const pp = playerPos(game); if (!pp) return;
  const dx = pp.x - e.x, dz = pp.z - e.z, d = Math.hypot(dx, dz) || 1;
  e.t += sdt; e.guarding = false;
  let ty = Math.atan2(dx, dz), diff = ty - e.ry;
  while (diff > Math.PI) diff -= TAU; while (diff < -Math.PI) diff += TAU;
  if (e.state !== 'atk' || !e.cur || e.at / e.cur.dur < e.cur.hit * .6)
    e.ry += diff * Math.min(1, sdt * 8);
  e.root.rotation.y = e.ry;
  e.vx *= Math.exp(-7 * sdt); e.vz *= Math.exp(-7 * sdt);
  e.x += e.vx * sdt; e.z += e.vz * sdt;
  if (d < 1.3) { e.x -= dx / d * (1.3 - d); e.z -= dz / d * (1.3 - d); }
  e.root.position.x = e.x; e.root.position.z = e.z;
  const rage = 1 + (1 - e.hp / e.max) * .5;
  let target = E_GUARD;

  if (e.state === 'spawn') {
    const k = Math.min(1, e.t / .9);
    e.root.position.y = S.gY - (1 - ease(k)) * 2.8;
    e.root.scale.setScalar(.6 + .4 * ease(k));
    if (k >= 1) { e.state = 'idle'; e.t = 0; e.cd = .8; }
  } else {
    e.root.position.y += (S.gY - e.root.position.y) * Math.min(1, sdt * 6);
    if (e.state === 'idle') {
      const near = 2.0;
      if (d > near) { e.x += dx / d * 3.4 * rage * sdt; e.z += dz / d * 3.4 * rage * sdt; }
      else if (chance(.004)) e.strafe = (e.strafe || 1) * -1;
      if (d <= near + .6) {
        e.x += -dz / d * (e.strafe || 1) * 1.1 * sdt;
        e.z += dx / d * (e.strafe || 1) * 1.1 * sdt;
      }
      e.cd -= sdt;
      if (e.cd <= 0 && d < 3.0) {
        let key;
        if (e.chain && e.chain.length) key = e.chain.shift();
        else {
          key = pick(['jab', 'jab', 'hook', 'hook', 'kick', 'upper', 'smash']);
          if (chance(.3)) e.chain = ['hook', chance(.5) ? 'smash' : 'kick'];
        }
        e.cur = EATT[key]; e.state = 'atk'; e.at = 0; e.hitDone = false; e.sp = rage;
      }
      if (S.anim && S.at < .15 && chance(.12)) e.guarding = true;
      if (e.guarding) target = evalAnim(ANIMS.block, 0);
    } else if (e.state === 'atk' && e.cur) {
      e.at += sdt * e.sp;
      const u = e.at / e.cur.dur;
      target = evalAnim(ANIMS[e.cur.an] || ANIMS.jab, u);
      if (!e.hitDone && u >= e.cur.hit) {
        e.hitDone = true;
        const dd = Math.hypot(pp.x - e.x, pp.z - e.z);
        if (dd < e.cur.reach + .3) hitPlayer(self, game, e.cur);
        e.vx += dx / d * 3; e.vz += dz / d * 3;
      }
      if (u >= 1) {
        e.state = 'idle';
        e.cd = e.chain && e.chain.length ? .08 : rnd(.35, 1.1) / rage;
        e.cur = null;
      }
    } else if (e.state === 'stagger' && e.hurtAn) {
      e.hurtT += sdt;
      const u = e.hurtT / e.hurtAn.dur;
      target = evalAnim(e.hurtAn, u);
      if (u >= 1) { e.state = 'idle'; e.cd = rnd(.2, .7); }
    }
  }
  
  e.A = e.A || { pose: {} };
  blendPose(e.A.pose, target, sdt, 18);
  enemyApplyPose(e, e.A.pose);
}

function playerAnimStep(S, game, sdt) {
  let target = {};
  let rate = 14;
  let active = false;

  if (S.anim) {
    S.at += sdt * S.sp;
    let u = S.at / S.anim.dur;
    if (S.anim.loop) u = u % 1;
    target = evalAnim(S.anim, Math.min(1, u));
    rate = S.hurt ? 20 : 28;
    active = true;
    if (!S.anim.loop && u >= 1) {
      wrapPose(S.pose);
      S.anim = null; S.an = null; S.hurt = false;
      if (!S.animHold) active = false;
    }
  } else if (S.block && !S.cut) {
    target = evalAnim(ANIMS.block, 0);
    rate = 16; active = true;
  }

  
  if (S.manualOn && S.manual) {
    for (const k of Object.keys(S.manual)) target[k] = S.manual[k];
    active = true;
  }

  blendPose(S.pose, target, sdt, rate);
  applyPoseToPlayer(game, S, S.pose, active || S.Aon);
  S.Aon = active;
  if (!active) releaseAllBones();
}

function isMobile(game) {
  try {
    if (game.touch && typeof game.touch.isMobile === 'function' && game.touch.isMobile()) return true;
  } catch (_) {}
  try {
    if (typeof matchMedia === 'function' && matchMedia('(pointer:coarse)').matches) return true;
  } catch (_) {}
  return !!(typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0 && Math.min(innerWidth, innerHeight) <= 900);
}

function setupMobileCombat(game, S) {
  S.mobile = isMobile(game);
  S.touchOn = false;
  if (!CFG.mobileTouch || !CFG.combat) return;
  if (!game.touch || typeof game.touch.show !== 'function') return;
  
  if (!S.mobile) return;
  try {
    game.touch.show([
      { id: 'hc_punch', label: 'ضرب', pos: 'br' },
      { id: 'hc_block', label: 'حماية', pos: 'mr' },
      { id: 'hc_enemy', label: 'شرير', pos: 'tr' },
      { id: 'hc_wave', label: 'سلام', pos: 'tl' }
    ]);
    S.touchOn = true;
    if (S.ui && S.ui.hint) {
      S.ui.hint.innerHTML = 'موبايل: ضرب · حماية · شرير · سلام<br>HawaCtrl من الكونسول على الكومبيوتر';
    }
  } catch (e) {
    try { console.warn('[HawaCtrl] touch UI', e); } catch (_) {}
  }
}

function readCombatInput(game, S) {
  
  
  let punch = false, block = S.block, enemyTap = false, waveTap = false;

  if (S.touchOn && game.touch) {
    if (game.touch.wasPressed && game.touch.wasPressed('hc_punch')) punch = true;
    else if (game.touch.isDown && game.touch.isDown('hc_punch') && !S.touchPunchHeld) {
      punch = true; S.touchPunchHeld = true;
    }
    if (game.touch.isDown && !game.touch.isDown('hc_punch')) S.touchPunchHeld = false;

    if (game.touch.isDown && game.touch.isDown('hc_block')) {
      if (!S.block) { S.block = true; S.blockT = 0; }
      block = true;
    } else if (S.touchOn && S.block && !(game.touch.isDown && game.touch.isDown('hc_block'))) {
      
      if (!S.mouseBlock) S.block = false;
      block = S.block;
    }

    if (game.touch.wasPressed && game.touch.wasPressed('hc_enemy')) enemyTap = true;
    if (game.touch.wasPressed && game.touch.wasPressed('hc_wave')) waveTap = true;
  }

  if (S.buffer > 0) punch = true;
  return { punch, block: S.block, enemyTap, waveTap };
}

function onStart(self, game) {
  RIG_MAP = null;
  if (window.__hawaCtrlClean) { try { window.__hawaCtrlClean(); } catch (_) {} }

  const T = game.THREE;
  const pp = playerPos(game);
  const y0 = pp ? pp.y : 0;

  const S = self.c = {
    pose: {}, Aon: false,
    anim: null, an: null, at: 0, sp: 1, dm: 1, hitDone: true, animHold: false,
    manual: {}, manualOn: false,
    combo: 0, comboT: 0, landed: 0, tier: 0, buffer: 0,
    hurt: false, block: false, blockT: 0,
    gY: y0, lastY: y0, air: false,
    kb: { x: 0, z: 0 }, freeze: 0, slow: 1, shake: 0,
    lastShake: new T.Vector3(),
    en: null, cut: null,
    parts: [], rings: [],
    sg: new T.BoxGeometry(.09, .09, .09),
    pHp: 1, wasE: false,
    hotPrev: {}
  };
  STATE = S;
  GAME_REF = game;
  buildUI(S);

  try { RIG_MAP = discoverRig(game); } catch (_) {}

  S.mouseBlock = false;
  S.touchPunchHeld = false;
  const md = ev => {
    if (!self.c || !CFG.combat) return;
    if (ev.button === 0) self.c.buffer = .35;
    if (ev.button === 2) { self.c.block = true; self.c.blockT = 0; self.c.mouseBlock = true; }
  };
  const mu = ev => {
    if (!self.c) return;
    if (ev.button === 2) { self.c.block = false; self.c.mouseBlock = false; }
  };
  const cm = ev => {
    if (self.c && self.c.ui && self.c.ui.w && self.c.ui.w.style.display !== 'none') ev.preventDefault();
  };

  window.addEventListener('mousedown', md);
  window.addEventListener('mouseup', mu);
  window.addEventListener('contextmenu', cm);

  setupMobileCombat(game, S);

  window.__hawaCtrlClean = () => {
    window.removeEventListener('mousedown', md);
    window.removeEventListener('mouseup', mu);
    window.removeEventListener('contextmenu', cm);
    try { if (game.touch && game.touch.hide) game.touch.hide(); } catch (_) {}
    releaseAllBones();
    document.querySelectorAll('#hawa-cmb-ui,[data-hawa-ctrl-ui]').forEach(el => { try { el.remove(); } catch (_) {} });
    if (S.en && S.en.root) try { game.scene.remove(S.en.root); } catch (_) {}
    S.parts.forEach(p => { try { game.scene.remove(p.m); } catch (_) {} });
    S.rings.forEach(r => { try { game.scene.remove(r.m); } catch (_) {} });
    S.en = null; STATE = null;
  };

  try {
    game.setHud && game.setHud('HawaCtrl جاهز · ضرب/حماية/E · 1–9 أنيميشن');
  } catch (_) {}
  try { console.log('[HawaCtrl] ready — HawaCtrl.help()'); } catch (_) {}
}

function onUpdate(self, game, dt) {
  const S = self.c;
  const pp = playerPos(game);
  if (!S || !pp) return;
  GAME_REF = game;
  dt = Math.min(dt, .05);
  showUI(S, true);

  if (!RIG_MAP || !RIG_MAP.armR) {
    try { RIG_MAP = discoverRig(game); } catch (_) {}
  }

  let sdt = dt * S.slow;
  if (S.freeze > 0) { S.freeze -= dt; sdt = 0; }
  if (S.cut) { cutStep(self, game, dt); return; }

  
  const vy = (pp.y - S.lastY) / Math.max(dt, 1e-3);
  S.lastY = pp.y;
  if (Math.abs(vy) < .4 && !S.air) S.gY = pp.y;
  else if (Math.abs(vy) < .15) S.gY = pp.y;
  S.air = pp.y - S.gY > .4;

  pp.x += S.kb.x * sdt; pp.z += S.kb.z * sdt;
  const kd = Math.exp(-8 * sdt); S.kb.x *= kd; S.kb.z *= kd;
  S.pHp = Math.min(1, S.pHp + sdt * .02);
  if (S.ui) S.ui.pf.style.width = (S.pHp * 100) + '%';

  
  if (CFG.hotkeys) {
    for (let i = 0; i < HOTKEY_ANIMS.length; i++) {
      const code = 'Digit' + (i + 1);
      const down = game.key(code);
      if (down && !S.hotPrev[code]) startPlayerAnim(S, HOTKEY_ANIMS[i], { toast: true });
      S.hotPrev[code] = down;
    }
  }

  
  if (CFG.combat) {
    
    if (CFG.mobileTouch && isMobile(game) && !S.touchOn) setupMobileCombat(game, S);

    const inp = readCombatInput(game, S);
    const eKey = game.key('KeyE');
    const enemyReq = (eKey && !S.wasE) || inp.enemyTap;
    S.wasE = eKey;

    if (enemyReq) {
      if (S.en) {
        try { game.scene.remove(S.en.root); } catch (_) {}
        S.en = null;
        if (S.ui) S.ui.eb.style.display = 'none';
        toast(S, 'اختفى الشرير', '#94a3b8');
      } else {
        const cam = game.camera, T = game.THREE;
        const fw = new T.Vector3();
        cam.getWorldDirection(fw); fw.y = 0;
        if (fw.lengthSq() < 1e-4) fw.set(0, 0, 1);
        fw.normalize();
        const ex = pp.x + fw.x * 5, ez = pp.z + fw.z * 5;
        const m = buildEnemy(game);
        m.root.position.set(ex, S.gY - 2.8, ez);
        game.scene.add(m.root);
        S.en = {
          root: m.root, parts: m.parts, A: { pose: {} },
          x: ex, z: ez, ry: Math.atan2(-fw.x, -fw.z),
          hp: 100, max: 100, state: 'spawn', t: 0, cd: 1,
          vx: 0, vz: 0, strafe: 1, chain: []
        };
        burst(S, game, ex, S.gY + .2, ez, 0xff5a2c, 30, 6);
        ring(S, game, ex, S.gY, ez, 0xff5a2c);
        S.shake = .2;
        if (S.ui) {
          S.ui.eb.style.display = 'block';
          S.ui.fill.style.width = '100%';
          S.ui.ghost.style.width = '100%';
        }
        toast(S, 'ظهر الشرير!', '#ff5a3c');
      }
    }

    if (inp.waveTap) startPlayerAnim(S, 'wave', { toast: true });

    if (S.block) S.blockT += sdt;
    if (S.buffer > 0) S.buffer -= dt;
    if (S.comboT > 0) { S.comboT -= dt; if (S.comboT <= 0) S.combo = 0; }

    const free = !S.anim || (!S.hurt && S.at / S.anim.dur > .68);
    if (inp.punch && free && !S.block && !S.hurt) {
      S.buffer = 0; startAttack(self, game);
    }

    if (S.anim && !S.hurt && !S.hitDone && S.anim.hit != null && S.at / S.anim.dur >= S.anim.hit) {
      S.hitDone = true;
      const e = S.en;
      if (e && e.state !== 'fin' && e.state !== 'spawn') {
        const d = Math.hypot(e.x - pp.x, e.z - pp.z);
        const reach = (S.an === 'kick' || S.an === 'airKick' || S.an === 'sideB') ? 3.1 : 2.8;
        if (d < reach) {
          const crit = chance(.12);
          const heavy = ['heavy', 'upper', 'spin', 'airSlam'].indexOf(S.an) >= 0 || crit;
          damageEnemy(self, game, 6 * S.dm * (crit ? 2 : 1) * rnd(.9, 1.15), heavy, crit);
        }
      }
    }

    if (S.en && !S.cut) {
      enemyStep(self, game, sdt);
      if (S.en) barUpdate(S);
    }
  }

  playerAnimStep(S, game, sdt);
  fxStep(S, game, dt);
}

function onTouch(self, game, dt) {}
