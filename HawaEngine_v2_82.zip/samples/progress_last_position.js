Game.defineParams([
  { key: "welcome", label: "رسالة العودة", type: "text", value: "اهلا وسهلا بعد عوده" },
  { key: "firstHello", label: "رسالة أول مرة", type: "text", value: "مرحباً — بداية جديدة" }
]);

function scenario() {
  return "يرجع اللاعب لآخر مكان محفوظ ويعرض رسالة ترحيب.";
}

function onStart(self, game) {
  const P = Game.params || {};
  const pos = Game.progress.get("pos", null);
  if (pos && typeof pos.x === "number") {
    try {
      if (game.player && game.player.position) {
        game.player.position.x = +pos.x;
        game.player.position.y = +pos.y;
        game.player.position.z = +pos.z;
      }
      if (game.player && game.player.velocity && game.player.velocity.set) {
        game.player.velocity.set(0, 0, 0);
      }
    } catch (e) {}
    const yaw = Game.progress.get("yaw", null);
    if (yaw != null && game.player) {
      try { game.player.yaw = +yaw; } catch (e) {}
    }
    const msg = P.welcome || "اهلا وسهلا بعد عوده";
    if (typeof Game.subtitle === "function") Game.subtitle(msg, 4500);
    else if (typeof Game.say === "function") Game.say(msg, 4500);
  } else {
    const msg = P.firstHello || "مرحباً — بداية جديدة";
    if (typeof Game.subtitle === "function") Game.subtitle(msg, 3500);
    else if (typeof Game.say === "function") Game.say(msg, 3500);
  }
}
