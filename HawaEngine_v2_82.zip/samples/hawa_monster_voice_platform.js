// ===== البارمترات (تظهر في لوحة البارامترات) =====
Game.defineParams([
  { key: "platName", label: "اسم المنصة", type: "text", value: "منصة متحركة 8" },
  { key: "boostOn", label: "قوة الصوت على المنصة (1 - 8)", type: "number", value: 8, min: 1, max: 8, step: 0.5 },
  { key: "boostOff", label: "قوة الصوت العادية", type: "number", value: 1, min: 0, max: 8, step: 0.5 },
  { key: "standTolY", label: "أقصى فرق ارتفاع عن سطح المنصة (م)", type: "number", value: 0.6, min: 0.1, max: 2, step: 0.1 },
  { key: "extraX", label: "هامش حوالين المنصة X (م)", type: "number", value: 0.4, min: 0, max: 3, step: 0.1 },
  { key: "extraZ", label: "هامش حوالين المنصة Z (م)", type: "number", value: 0.4, min: 0, max: 3, step: 0.1 },
  { key: "monsterOn", label: "تفعيل صوت الوحش", type: "boolean", value: true },
  { key: "lowGain", label: "تضخيم القاع (ديسيبل)", type: "number", value: 14, min: 0, max: 24, step: 1 },
  { key: "drive", label: "الخشونة (تشويه الصوت)", type: "number", value: 4, min: 1, max: 12, step: 0.5 },
  { key: "ringHz", label: "تردد الزمجرة (هرتز)", type: "number", value: 28, min: 5, max: 80, step: 1 },
  { key: "ringDepth", label: "عمق الزمجرة", type: "number", value: 0.5, min: 0, max: 1, step: 0.05 },
  { key: "cutoff", label: "قص الترددات العالية (هرتز)", type: "number", value: 1400, min: 400, max: 4000, step: 50 },
  { key: "echo", label: "صدى الكهف (ثانية)", type: "number", value: 0.22, min: 0.05, max: 0.8, step: 0.01 },
  { key: "feedback", label: "قوة تكرار الصدى", type: "number", value: 0.35, min: 0, max: 0.8, step: 0.05 },
  { key: "mix", label: "نسبة الوحش (wet)", type: "number", value: 0.9, min: 0, max: 1, step: 0.05 }
]);

// ===== الكود =====
var onPlat = false;

function P(key, def) {
  var v = Game.params ? Game.params[key] : undefined;
  return v === undefined || v === null ? def : v;
}

function isStanding(plat) {
  if (!Game.voice.isOn()) return false;
  var c = Game.getCoords();
  var pos = plat.position, sc = plat.scale || {};
  var sx = sc.x || 4, sy = sc.y || 0.5, sz = sc.z || 4;
  var top = pos.y + sy / 2;
  var inside = Math.abs(c.x - pos.x) < sx / 2 + P("extraX", 0.4) &&
               Math.abs(c.z - pos.z) < sz / 2 + P("extraZ", 0.4);
  var onTop = Math.abs(c.y - top) <= P("standTolY", 0.6);
  return inside && onTop;
}

function monsterCfg(on) {
  return {
    on: on && P("monsterOn", true),
    lowGain: P("lowGain", 14), drive: P("drive", 4), ringHz: P("ringHz", 28),
    ringDepth: P("ringDepth", 0.5), cutoff: P("cutoff", 1400),
    echo: P("echo", 0.22), feedback: P("feedback", 0.35), mix: P("mix", 0.9)
  };
}

Game.onUpdate(function (dt) {
  var plat = Game.findByName(P("platName", "منصة متحركة 8"));
  if (!plat) return;
  var now = isStanding(plat);
  if (now === onPlat) return;
  onPlat = now;
  Game.voice.setBoost(now ? P("boostOn", 8) : P("boostOff", 1));
  Game.voice.setFx(monsterCfg(now));
  if (now) Game.subtitle("👹 صوتك بقى وحش!");
  else Game.subtitle("");
});
