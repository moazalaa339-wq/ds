(function (Game, root) {
  "use strict";
  if (!Game || !root) return;
  var THREE = Game.THREE || (typeof window !== "undefined" ? window.THREE : null);
  if (!THREE) return;
  if (typeof Game.onUpdate !== "function") return;

  var OBJECT_NAME = "توك_توك_واقعي";
  try { root.userData.instanceName = OBJECT_NAME; } catch (e) {}
  root.userData.forceMeshCollision = true;
  root.userData.customDrive = true;
  try { if (typeof root.userData.__tukCleanup === "function") root.userData.__tukCleanup(); } catch (e) {}

  
  
  
  if (typeof Game.defineParams === "function") {
    Game.defineParams([
      { key: "bodyColor", label: "لون الهيكل (الطلاء)", type: "color", value: "#e6b400" },
      { key: "roofColor", label: "لون سقف الكانفاس", type: "color", value: "#1a1b1e" },
      { key: "accentColor", label: "لون الشرائط والتفاصيل", type: "color", value: "#b3261e" },
      { key: "seatColor", label: "لون الكراسي (جلد صناعي)", type: "color", value: "#2a1d17" },
      { key: "bannerText", label: "كتابة أعلى الزجاج الأمامي", type: "text", value: "ما شاء الله" },
      { key: "plateText", label: "رقم اللوحة", type: "text", value: "توك توك ١٢٣٤" },

      { key: "mass", label: "الوزن مع السواق (كجم)", type: "number", value: 520, min: 300, max: 900, step: 10 },
      { key: "enginePower", label: "عزم الموتور الأقصى (نيوتن.متر)", type: "number", value: 26, min: 10, max: 60, step: 1 },
      { key: "maxSpeed", label: "السرعة القصوى (م/ث)", type: "number", value: 16, min: 5, max: 40, step: 0.5 },
      { key: "reverseMaxSpeed", label: "سرعة الرجوع القصوى (م/ث)", type: "number", value: 4, min: 1, max: 12, step: 0.5 },
      { key: "brakePower", label: "قوة الفرامل (م/ث²)", type: "number", value: 7.5, min: 3, max: 20, step: 0.5 },
      { key: "handbrakePower", label: "قوة فرامل اليد (م/ث²)", type: "number", value: 9, min: 3, max: 25, step: 0.5 },
      { key: "gripLimit", label: "تماسك الكاوتش الجانبي (م/ث²)", type: "number", value: 7.2, min: 3, max: 14, step: 0.1 },
      { key: "steerMaxDeg", label: "أقصى زاوية للعجلة الأمامية (درجة)", type: "number", value: 32, min: 10, max: 50, step: 1 },
      { key: "steerResponse", label: "سرعة استجابة المقود (1/ث)", type: "number", value: 6, min: 1, max: 20, step: 0.5 },
      { key: "bodyRoll", label: "ميل الهيكل في المنعطف (0-2)", type: "number", value: 1, min: 0, max: 2, step: 0.05 },
      { key: "roughRoad", label: "خشونة الطريق (0-2)", type: "number", value: 1, min: 0, max: 2, step: 0.1 },
      { key: "collision", label: "التصادم مع الحوائط", type: "boolean", value: true },

      { key: "camDistance", label: "مسافة الكاميرا (م)", type: "number", value: 6.2, min: 2.5, max: 16, step: 0.5 },
      { key: "camHeightDeg", label: "ارتفاع الكاميرا الافتراضي (درجة)", type: "number", value: 15, min: -2, max: 80, step: 1 },
      { key: "camFov", label: "زاوية الرؤية (درجة)", type: "number", value: 60, min: 35, max: 100, step: 1 },
      { key: "speedFovBoost", label: "زيادة الزاوية عند السرعة (درجة)", type: "number", value: 6, min: 0, max: 25, step: 1 },
      { key: "camSensitivity", label: "حساسية الماوس (راديان/بكسل)", type: "number", value: 0.0045, min: 0.001, max: 0.015, step: 0.0005 },
      { key: "camKeySpeed", label: "سرعة تدوير الكاميرا بالأسهم (راديان/ث)", type: "number", value: 1.8, min: 0.5, max: 5, step: 0.1 },
      { key: "camFollow", label: "سرعة تتبع الكاميرا للاتجاه (1/ث)", type: "number", value: 4.5, min: 1, max: 15, step: 0.5 },
      { key: "camRecenterDelay", label: "مهلة رجوع الكاميرا للخلف (ث)", type: "number", value: 2.5, min: 0.5, max: 10, step: 0.5 },
      { key: "camLerp", label: "نعومة الكاميرا (0-1)", type: "number", value: 0.4, min: 0.05, max: 1, step: 0.05 },
      { key: "roofFade", label: "تشفيف السقف لما الكاميرا تعلى", type: "boolean", value: true },

      { key: "interactRadius", label: "مسافة الركوب (م)", type: "number", value: 3.4, min: 1.5, max: 8, step: 0.1 },
      { key: "headlights", label: "كشاف أمامي", type: "boolean", value: true },
      { key: "soundOn", label: "صوت الموتور والكلاكس", type: "boolean", value: true },
      { key: "soundVolume", label: "مستوى الصوت (0-1)", type: "number", value: 0.55, min: 0, max: 1, step: 0.05 },
      { key: "showHint", label: "إظهار تعليمات التحكم عند الركوب", type: "boolean", value: true },

      { key: "riderLift", label: "ضبط ارتفاع الراكب (م)", type: "number", value: 0, min: -0.3, max: 0.3, step: 0.01 },
      { key: "flipArmSide", label: "عكس ميل الذراعين جانبياً", type: "boolean", value: false },
      { key: "flipKnee", label: "عكس ثني الركبة", type: "boolean", value: false },
      { key: "riderYawOffsetDeg", label: "تعديل اتجاه الراكب (درجة)", type: "number", value: 0, min: -180, max: 180, step: 15 }
    ]);
  }

  function PR(key) { var p = Game.params; return p ? p[key] : undefined; }
  function PN(key, def) {
    var v = PR(key);
    if (v === undefined || v === null || v === "") return def;
    v = Number(v);
    return isFinite(v) ? v : def;
  }
  function PB(key, def) {
    var v = PR(key);
    if (v === undefined || v === null) return def;
    if (typeof v === "string") return v === "true" || v === "1";
    return !!v;
  }
  function PS(key, def) {
    var v = PR(key);
    return (v === undefined || v === null || v === "") ? def : String(v);
  }
  function call(name) {
    var f = Game[name];
    if (typeof f !== "function") return undefined;
    try { return f.apply(Game, Array.prototype.slice.call(arguments, 1)); } catch (e) { return undefined; }
  }
  function down(code) { return !!call("isKeyDown", code); }

  
  
  
  var PI = Math.PI, TAU = Math.PI * 2;
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function damp(cur, target, rate, dt) { return cur + (target - cur) * (1 - Math.exp(-rate * dt)); }
  function wrap(a) { while (a > PI) a -= TAU; while (a < -PI) a += TAU; return a; }
  function smooth(e0, e1, x) { var t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); }
  function sgn(x) { return x < 0 ? -1 : (x > 0 ? 1 : 0); }
  
  function vnoise(t) {
    var i = Math.floor(t), f = t - i, a = Math.sin(i * 127.1) * 43758.5453, b = Math.sin((i + 1) * 127.1) * 43758.5453;
    a -= Math.floor(a); b -= Math.floor(b);
    f = f * f * (3 - 2 * f);
    return (a + (b - a) * f) * 2 - 1;
  }

  
  
  
  
  var DIM = {
    wheelBase: 2.0,
    rearR: 0.30, rearW: 0.13, rearX: 0.64,
    frontR: 0.29, frontW: 0.12, frontZ: -2.0
  };
  var BAR = { x: 0, y: 1.22, z: -0.82 };
  var GRIP = { x: 0.37, y: 0, z: 0.06 };
  var SEAT = { x: 0, y: 0, z: -0.30 };
  var RIDER = {
    shoulderX: 0.20, shoulderY: 1.50,
    upperArm: 0.31, foreArm: 0.29,
    thighRx: -1.45, shinRx: 1.50, kneeSpread: 0.10
  };
  
  var SEAT_TOP = 0.885;   
  function fitRider() {
    var d = call("getPlayerDims", 0);
    if (!d || !d.sit) return;
    SEAT.y = SEAT_TOP - d.sit.originDrop;            
    RIDER.shoulderY = d.ride.shoulderHeight;          
    RIDER.shoulderX = d.ride.shoulderWidth / 2;
    RIDER.upperArm = d.ride.upperArm; RIDER.foreArm = d.ride.foreArm;
  }
  var MOUNT_TIME = 0.8, DISMOUNT_TIME = 0.7, BAR_RATIO = 0.58;

  
  var GEARS = [0, 38, 23, 15, 11];     
  var RPM_IDLE = 1350, RPM_MAX = 6200, RPM_UP = 5300, RPM_DOWN = 2300;

  
  
  
  var S = {
    mode: "idle", t: 0, modeT: 0, lastToggle: -99, cleaned: false, errLogged: false,
    v: 0, yaw: root.rotation.y, steerIn: 0, steerVis: 0, steerEff: 0, yawRate: 0, accel: 0, lat: 0,
    pitch: 0, roll: 0, wSpinR: 0, wSpinF: 0, barAngle: 0, throttleVis: 0,
    brakeOn: false, reverseOn: false, throttleOn: false,
    camAzOff: 0, camPitch: PN("camHeightDeg", 15) * PI / 180, camDistUser: 1, camYaw: root.rotation.y, lastCamInput: -99, camShake: 0,
    paramT: 1, hintT: -1, driver: "", yawFix: 0, yawFixTries: 0, yawFixT: 0,
    mountFrom: new THREE.Vector3(), exitPos: new THREE.Vector3(), blend: 0,
    fPrev: false, hPrev: false, collT: 0, wallT: -99, lastPos: new THREE.Vector3(), lastYawMeasured: root.rotation.y, syncT: 0,
    smokeT: 0, matFrame: -1, frameNo: 0, coast: false,
    rpm: 0, gear: 1, thr: 0, engine: "off", engT: 0, shiftT: 0, load: 0, slip: 0, hb: false,
    rollV: 0, pitchV: 0, heave: 0, heaveV: 0, liftL: 0, liftR: 0, slipAng: 0, horn: false, roadT: Math.random() * 100,
    fork: 0
  };
  var spawnPos = root.position.clone();
  var spawnYaw = root.rotation.y;
  var DRV_KEY = "tuk_driver_" + (root.uuid || "x");
  S.lastPos.copy(root.position);

  
  
  
  function stdMat(color, rough, metal, extra) {
    var o = { color: color, roughness: rough, metalness: metal };
    if (extra) { for (var k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) o[k] = extra[k]; } }
    return new THREE.MeshStandardMaterial(o);
  }
  function canvasTex(w, h, draw, repeat) {
    if (typeof document === "undefined") return null;
    try {
      var c = document.createElement("canvas");
      c.width = w; c.height = h;
      var ctx = c.getContext("2d");
      if (!ctx) return null;
      draw(ctx, w, h);
      var t = new THREE.CanvasTexture(c);
      if (THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 4;
      if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
      return { tex: t, canvas: c, draw: draw };
    } catch (e) { return null; }
  }
  function redrawTex(o) {
    if (!o) return;
    try {
      var ctx = o.canvas.getContext("2d");
      ctx.clearRect(0, 0, o.canvas.width, o.canvas.height);
      o.draw(ctx, o.canvas.width, o.canvas.height);
      o.tex.needsUpdate = true;
    } catch (e) {}
  }
  function texMat(o, fallback, extra) {
    var p = { color: o ? 0xffffff : fallback, roughness: 0.6, metalness: 0.05 };
    if (o) p.map = o.tex;
    if (extra) { for (var k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) p[k] = extra[k]; } }
    return new THREE.MeshStandardMaterial(p);
  }
  
  function speckle(ctx, w, h, n, a0, a1, s) {
    for (var i = 0; i < n; i++) {
      var v = 128 + (Math.random() - 0.5) * 2 * s;
      ctx.fillStyle = "rgba(" + (v | 0) + "," + (v | 0) + "," + (v | 0) + "," + (a0 + Math.random() * (a1 - a0)) + ")";
      ctx.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 1.5, 1 + Math.random() * 1.5);
    }
  }
  var TX = {};
  TX.peel = canvasTex(128, 128, function (ctx, w, h) { ctx.fillStyle = "#808080"; ctx.fillRect(0, 0, w, h); speckle(ctx, w, h, 2600, 0.5, 1, 40); }, [6, 6]);
  TX.weave = canvasTex(64, 64, function (ctx, w, h) {
    ctx.fillStyle = "#8a8a8a"; ctx.fillRect(0, 0, w, h);
    for (var y = 0; y < h; y += 4) for (var x = 0; x < w; x += 4) {
      ctx.fillStyle = ((x + y) / 4) % 2 ? "#b4b4b4" : "#5c5c5c"; ctx.fillRect(x, y, 4, 4);
    }
  }, [30, 30]);
  TX.tread = canvasTex(256, 128, function (ctx, w, h) {
    ctx.fillStyle = "#909090"; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#202020";
    var n = 28, i;
    for (i = 0; i < n; i++) {
      var x = i * w / n;
      ctx.fillRect(x, h * 0.26, w / n * 0.38, h * 0.20);
      ctx.fillRect(x + w / n * 0.5, h * 0.54, w / n * 0.38, h * 0.20);
    }
    ctx.fillRect(0, h * 0.495, w, h * 0.012);
    speckle(ctx, w, h, 1500, 0.3, 0.8, 50);
  });
  TX.rib = canvasTex(64, 64, function (ctx, w, h) {
    ctx.fillStyle = "#6a6a6a"; ctx.fillRect(0, 0, w, h);
    for (var i = 0; i < 8; i++) { ctx.fillStyle = "#cfcfcf"; ctx.fillRect(0, i * 8, w, 4); }
  }, [3, 4]);
  TX.vinyl = canvasTex(256, 256, function (ctx, w, h) {
    ctx.fillStyle = "#d8d8d8"; ctx.fillRect(0, 0, w, h);
    speckle(ctx, w, h, 5000, 0.2, 0.5, 60);
    ctx.strokeStyle = "#7a7a7a"; ctx.lineWidth = 2;
    for (var i = -h; i < w + h; i += 32) {
      ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i + h, h); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(i, h); ctx.lineTo(i + h, 0); ctx.stroke();
    }
  }, [2, 2]);
  TX.plate = canvasTex(256, 128, function (ctx, w, h) {
    ctx.fillStyle = "#f2f2ec"; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#15305a"; ctx.lineWidth = 8; ctx.strokeRect(6, 6, w - 12, h - 12);
    ctx.fillStyle = "#15305a"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 30px sans-serif"; ctx.fillText("مصر", w / 2, h * 0.24);
    ctx.font = "bold 54px sans-serif"; ctx.fillText(PS("plateText", "توك توك ١٢٣٤"), w / 2, h * 0.66, w - 28);
  });
  TX.banner = canvasTex(512, 64, function (ctx, w, h) {
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(20,20,22,0.92)"; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#c9a24a"; ctx.fillRect(0, 3, w, 2); ctx.fillRect(0, h - 5, w, 2);
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 38px sans-serif"; ctx.fillStyle = "#e8d08a";
    ctx.fillText(PS("bannerText", "ما شاء الله"), w / 2, h / 2 + 2, w - 40);
  });
  TX.dial = canvasTex(256, 256, function (ctx, w, h) {
    var cx = w / 2, cy = h / 2, r = w * 0.46, i, k, a, x1, y1, x2, y2;
    ctx.fillStyle = "#0b0d10"; ctx.beginPath(); ctx.arc(cx, cy, r + 8, 0, TAU); ctx.fill();
    ctx.fillStyle = "#14191f"; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = "#e8e8e8"; ctx.fillStyle = "#e8e8e8"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 22px sans-serif";
    for (i = 0; i <= 8; i++) {
      k = i / 8; a = 2.094 - 4.189 * k;
      x1 = cx - Math.sin(a) * r * 0.86; y1 = cy - Math.cos(a) * r * 0.86;
      x2 = cx - Math.sin(a) * r * 0.98; y2 = cy - Math.cos(a) * r * 0.98;
      ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      ctx.fillText(String(i * 10), cx - Math.sin(a) * r * 0.68, cy - Math.cos(a) * r * 0.68);
    }
    ctx.fillStyle = "#ffb000"; ctx.font = "bold 18px sans-serif"; ctx.fillText("km/h", cx, cy + r * 0.45);
  });

  var M = {
    body: new THREE.MeshPhysicalMaterial({ color: 0xe6b400, roughness: 0.32, metalness: 0.25, clearcoat: 1, clearcoatRoughness: 0.08, side: THREE.DoubleSide, bumpMap: TX.peel ? TX.peel.tex : null, bumpScale: 0.12 }),
    roof: stdMat(0x1a1b1e, 0.95, 0.0, { transparent: true, opacity: 1, side: THREE.DoubleSide, bumpMap: TX.weave ? TX.weave.tex : null, bumpScale: 0.6 }),
    accent: stdMat(0xb3261e, 0.45, 0.1),
    chrome: stdMat(0xdfe5ec, 0.18, 0.95, { envMapIntensity: 1.2 }),
    steel: stdMat(0xb9bec4, 0.45, 0.85),
    darkMetal: stdMat(0x24282c, 0.5, 0.7),
    plastic: stdMat(0x111214, 0.6, 0.05),
    rubber: stdMat(0x131313, 0.95, 0.05),
    tire: stdMat(0x141414, 0.92, 0.02, { bumpMap: TX.tread ? TX.tread.tex : null, bumpScale: 1.6 }),
    mat: stdMat(0x1b1b1b, 0.98, 0.0, { bumpMap: TX.rib ? TX.rib.tex : null, bumpScale: 1.2 }),
    seat: stdMat(0x2a1d17, 0.55, 0.05, { map: TX.vinyl ? TX.vinyl.tex : null, bumpMap: TX.vinyl ? TX.vinyl.tex : null, bumpScale: 0.8 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xbfe6f0, roughness: 0.03, metalness: 0.0, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false }),
    mirror: stdMat(0xd7e6f2, 0.04, 1.0),
    head: stdMat(0xfdfdf4, 0.1, 0.1, { emissive: 0xfff2c4, emissiveIntensity: 0.3 }),
    tail: stdMat(0x7a0a0a, 0.3, 0.2, { emissive: 0xff1010, emissiveIntensity: 0.3 }),
    rev: stdMat(0xe6e6e6, 0.3, 0.2, { emissive: 0xffffff, emissiveIntensity: 0.05 }),
    sigL: stdMat(0x8a5a00, 0.3, 0.2, { emissive: 0xffa800, emissiveIntensity: 0.05 }),
    sigR: stdMat(0x8a5a00, 0.3, 0.2, { emissive: 0xffa800, emissiveIntensity: 0.05 }),
    smoke: stdMat(0x9aa0a6, 1.0, 0.0, { transparent: true, opacity: 0.25, depthWrite: false })
  };

  
  
  
  var _up = new THREE.Vector3(0, 1, 0);
  function add(parent, geo, mat, x, y, z, shadow) {
    var m = new THREE.Mesh(geo, mat);
    m.position.set(x || 0, y || 0, z || 0);
    if (shadow) m.castShadow = true;
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  function rod(parent, p1, p2, r, mat, seg) {
    var a = new THREE.Vector3(p1[0], p1[1], p1[2]);
    var b = new THREE.Vector3(p2[0], p2[1], p2[2]);
    var dir = b.clone().sub(a);
    var len = dir.length();
    if (len < 1e-5) return null;
    var m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg || 10, 1), mat);
    m.position.copy(a).add(b).multiplyScalar(0.5);
    m.quaternion.setFromUnitVectors(_up, dir.normalize());
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  
  function tube(parent, pts, r, mat, seg) {
    var v = pts.map(function (p) { return new THREE.Vector3(p[0], p[1], p[2]); });
    var curve = new THREE.CatmullRomCurve3(v, false, "catmullrom", 0.3);
    var m = new THREE.Mesh(new THREE.TubeGeometry(curve, seg || 24, r, 8, false), mat);
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  
  function coilSpring(parent, x, y0, z, h, rad, wire, turns, mat, tiltX) {
    var pts = [], n = Math.floor(turns * 14), i, a;
    for (i = 0; i <= n; i++) { a = i / 14 * TAU; pts.push([x + Math.cos(a) * rad, y0 + h * i / n, z + Math.sin(a) * rad]); }
    return tube(parent, pts, wire, mat, n * 2);
  }
  function rboxGeo(w, h, d, r) {
    var b = Math.max(0.002, Math.min(r || 0.02, w * 0.4, h * 0.4, d * 0.4));
    var iw = Math.max(0.001, w - 2 * b), ih = Math.max(0.001, h - 2 * b), id = Math.max(0.001, d - 2 * b);
    var s = new THREE.Shape();
    s.moveTo(-iw / 2, -ih / 2); s.lineTo(iw / 2, -ih / 2); s.lineTo(iw / 2, ih / 2); s.lineTo(-iw / 2, ih / 2); s.lineTo(-iw / 2, -ih / 2);
    var g = new THREE.ExtrudeGeometry(s, { depth: id, bevelEnabled: true, bevelThickness: b, bevelSize: b, bevelSegments: 3, steps: 1 });
    g.translate(0, 0, -id / 2);
    return g;
  }
  
  function sect(z, hw, yb, yt, n, N, bias) {
    var pts = [], yc = (yb + yt) / 2, hh = (yt - yb) / 2, i, a, c, s;
    for (i = 0; i < N; i++) {
      a = i / N * TAU; c = Math.cos(a); s = Math.sin(a);
      pts.push([hw * sgn(c) * Math.pow(Math.abs(c), 2 / n), yc + hh * sgn(s) * Math.pow(Math.abs(s), 2 / n) + (bias || 0) * (c * c), z]);
    }
    return pts;
  }
  
  function loft(secs, caps) {
    var J = secs.length, N = secs[0].length, pos = [], uv = [], idx = [], i, j, k, base;
    for (j = 0; j < J; j++) for (i = 0; i < N; i++) { pos.push(secs[j][i][0], secs[j][i][1], secs[j][i][2]); uv.push(i / N, j / (J - 1)); }
    for (j = 0; j < J - 1; j++) for (i = 0; i < N; i++) {
      var a = j * N + i, b = j * N + (i + 1) % N, c = (j + 1) * N + i, d = (j + 1) * N + (i + 1) % N;
      idx.push(a, c, b, b, c, d);
    }
    function cap(sec, rev) {
      var cx = 0, cy = 0, cz = 0, s0 = pos.length / 3;
      for (k = 0; k < N; k++) { cx += sec[k][0]; cy += sec[k][1]; cz += sec[k][2]; pos.push(sec[k][0], sec[k][1], sec[k][2]); uv.push(0, 0); }
      cx /= N; cy /= N; cz /= N;
      var cc = pos.length / 3; pos.push(cx, cy, cz); uv.push(0, 0);
      for (k = 0; k < N; k++) { if (rev) idx.push(cc, s0 + (k + 1) % N, s0 + k); else idx.push(cc, s0 + k, s0 + (k + 1) % N); }
    }
    if (caps !== false) { cap(secs[0], false); cap(secs[J - 1], true); }
    var g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    
    var mx = 0, my = 0, mz = 0, nrm = g.attributes.normal, p = g.attributes.position, cnt = p.count, dot = 0;
    for (k = 0; k < cnt; k++) { mx += p.getX(k); my += p.getY(k); mz += p.getZ(k); }
    mx /= cnt; my /= cnt; mz /= cnt;
    for (k = 0; k < N * J; k++) dot += nrm.getX(k) * (p.getX(k) - mx) + nrm.getY(k) * (p.getY(k) - my) + nrm.getZ(k) * (p.getZ(k) - mz);
    if (dot < 0) {
      for (k = 0; k < idx.length; k += 3) { var t = idx[k + 1]; idx[k + 1] = idx[k + 2]; idx[k + 2] = t; }
      g.setIndex(idx); g.computeVertexNormals();
    }
    return g;
  }
  function fenderGeo(r, w, thetaStart, thetaLen) {
    var g = new THREE.CylinderGeometry(r, r, w, 28, 1, true, thetaStart, thetaLen);
    g.rotateZ(PI / 2);
    return g;
  }

  
  var geoLug = new THREE.CylinderGeometry(0.012, 0.012, 0.016, 6).rotateZ(PI / 2);
  function buildWheel(R, W, name, isRear) {
    var g = new THREE.Group(); g.name = name;
    var hw = W / 2, rimR = R * 0.60, i, a, side, V = THREE.Vector2;
    var prof = [], steps = 14, t, ang;
    
    prof.push(new V(rimR, -hw * 0.80), new V(rimR + 0.012, -hw * 0.95), new V(R - 0.07, -hw * 1.02));
    for (i = 0; i <= steps; i++) {
      t = i / steps; ang = -PI / 2 + t * PI;
      prof.push(new V(R - 0.05 + Math.cos(ang) * 0.05 * (0.55 + 0.45 * Math.abs(Math.cos(ang))), Math.sin(ang) * hw * 0.98));
    }
    prof.push(new V(R - 0.07, hw * 1.02), new V(rimR + 0.012, hw * 0.95), new V(rimR, hw * 0.80));
    var tg = new THREE.LatheGeometry(prof, 48);
    tg.rotateZ(PI / 2);
    add(g, tg, M.tire, 0, 0, 0, true);
    
    var barrel = new THREE.CylinderGeometry(rimR, rimR, W * 0.80, 32, 1, true).rotateZ(PI / 2);
    add(g, barrel, M.steel, 0, 0, 0);
    
    for (side = -1; side <= 1; side += 2) {
      var sh = new THREE.Shape(); sh.absarc(0, 0, rimR * 0.97, 0, TAU, false);
      for (i = 0; i < 5; i++) {
        a = i * TAU / 5 + 0.3;
        var hp = new THREE.Path(), cx = Math.cos(a) * rimR * 0.58, cy = Math.sin(a) * rimR * 0.58;
        hp.absellipse(cx, cy, rimR * 0.17, rimR * 0.10, 0, TAU, true, a);
        sh.holes.push(hp);
      }
      var dg = new THREE.ExtrudeGeometry(sh, { depth: 0.012, bevelEnabled: false, curveSegments: 20 });
      dg.rotateY(PI / 2);
      add(g, dg, M.steel, side * hw * 0.28 - 0.006, 0, 0);
      add(g, new THREE.CylinderGeometry(rimR * 0.22, rimR * 0.30, 0.03, 20).rotateZ(PI / 2), M.chrome, side * hw * 0.40, 0, 0);
      for (i = 0; i < 4; i++) { a = i * TAU / 4 + 0.78; add(g, geoLug, M.darkMetal, side * hw * 0.50, Math.cos(a) * rimR * 0.17, Math.sin(a) * rimR * 0.17); }
    }
    add(g, new THREE.CylinderGeometry(rimR * 0.78, rimR * 0.78, W * 0.62, 28).rotateZ(PI / 2), M.darkMetal, 0, 0, 0);
    return g;
  }

  
  
  
  var chassis = new THREE.Group(); chassis.name = "tuk_chassis"; root.add(chassis);
  var forkGroup = new THREE.Group(); forkGroup.name = "tuk_fork"; forkGroup.position.set(0, 0, DIM.frontZ); chassis.add(forkGroup);
  var barGroup = new THREE.Group(); barGroup.name = "tuk_handlebar"; barGroup.position.set(BAR.x, BAR.y, BAR.z); chassis.add(barGroup);
  var solidMeshes = [];
  function solid(m) { m.userData.noCollision = false; m.userData.solid = true; m.userData.forceMeshCollision = true; solidMeshes.push(m); return m; }
  var sx, i, k;

  
  var wheelF = buildWheel(DIM.frontR, DIM.frontW, "wheel_front", false);
  wheelF.position.set(0, DIM.frontR, 0); forkGroup.add(wheelF);
  var wheelRL = buildWheel(DIM.rearR, DIM.rearW, "wheel_rear_left", true);
  wheelRL.position.set(-DIM.rearX, DIM.rearR, 0); chassis.add(wheelRL);
  var wheelRR = buildWheel(DIM.rearR, DIM.rearW, "wheel_rear_right", true);
  wheelRR.position.set(DIM.rearX, DIM.rearR, 0); chassis.add(wheelRR);

  
  solid(add(chassis, rboxGeo(1.10, 0.05, 1.95, 0.02), M.darkMetal, 0, 0.37, -0.52, true));
  var floorMat = add(chassis, new THREE.PlaneGeometry(0.98, 1.1), M.mat, 0, 0.398, -0.95);
  floorMat.rotation.x = -PI / 2;
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.44, 0.31, -1.78], [sx * 0.44, 0.31, 1.0], 0.036, M.darkMetal, 10);
    rod(chassis, [sx * DIM.rearX, DIM.rearR, 0.02], [sx * 0.44, 0.34, 0.02], 0.026, M.darkMetal, 8);
  }
  var crossZ = [-1.40, -0.65, 0.05, 0.75];
  for (i = 0; i < crossZ.length; i++) rod(chassis, [-0.44, 0.31, crossZ[i]], [0.44, 0.31, crossZ[i]], 0.026, M.darkMetal, 8);
  rod(chassis, [-DIM.rearX, DIM.rearR, 0], [DIM.rearX, DIM.rearR, 0], 0.032, M.darkMetal, 10);        
  add(chassis, new THREE.CylinderGeometry(0.075, 0.075, 0.24, 18).rotateZ(PI / 2), M.darkMetal, 0, DIM.rearR, 0);  
  
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.52, 0.34, 0.12], [sx * 0.52, 0.64, 0.12], 0.018, M.chrome, 8);
    coilSpring(chassis, sx * 0.52, 0.36, 0.12, 0.26, 0.04, 0.0065, 6.5, M.accent);
    add(chassis, new THREE.CylinderGeometry(0.03, 0.03, 0.12, 12), M.darkMetal, sx * 0.52, 0.66, 0.12);
  }

  
  var zs = [-1.96, -1.92, -1.84, -1.72, -1.58, -1.42, -1.27, -1.14, -1.06];
  var hws = [0.07, 0.17, 0.29, 0.40, 0.49, 0.55, 0.60, 0.63, 0.63];
  var yts = [0.80, 0.96, 1.07, 1.13, 1.16, 1.17, 1.18, 1.18, 1.18];
  var ybs = [0.76, 0.70, 0.64, 0.58, 0.52, 0.48, 0.44, 0.42, 0.42];
  var noseSecs = [];
  for (i = 0; i < zs.length; i++) noseSecs.push(sect(zs[i], hws[i], ybs[i], yts[i], 3.1, 28, 0));
  var nose = solid(add(chassis, loft(noseSecs), M.body, 0, 0, 0, true));
  
  tube(chassis, [[0, 1.01, -1.93], [0, 1.15, -1.78], [0, 1.20, -1.55], [0, 1.205, -1.25]], 0.012, M.chrome, 18);
  
  add(chassis, fenderGeo(DIM.frontR + 0.07, 0.19, 0.10, PI + 0.55), M.body, 0, DIM.frontR, DIM.frontZ, true);
  for (sx = -1; sx <= 1; sx += 2) add(chassis, new THREE.TorusGeometry(DIM.frontR + 0.07, 0.007, 6, 28, PI + 0.45).rotateY(-PI / 2), M.chrome, sx * 0.095, DIM.frontR, DIM.frontZ);
  
  rod(forkGroup, [-0.075, DIM.frontR, 0], [-0.075, 0.90, 0.10], 0.022, M.chrome, 12);
  add(forkGroup, new THREE.CylinderGeometry(0.034, 0.034, 0.30, 14), M.plastic, -0.075, 0.66, 0.075);
  coilSpring(forkGroup, -0.075, 0.74, 0.085, 0.14, 0.035, 0.005, 5, M.steel);
  add(forkGroup, new THREE.CylinderGeometry(0.02, 0.02, 0.18, 10).rotateZ(PI / 2), M.chrome, -0.02, DIM.frontR, 0);
  add(forkGroup, new THREE.CylinderGeometry(0.14, 0.14, 0.05, 20).rotateZ(PI / 2), M.darkMetal, -0.075, DIM.frontR, 0.0);  
  rod(forkGroup, [0, 0.90, 0.10], [0, 1.16, 0.18], 0.03, M.darkMetal, 10);

  
  var hlHousing = add(chassis, new THREE.CylinderGeometry(0.145, 0.125, 0.12, 28).rotateX(PI / 2), M.chrome, 0, 0.93, -1.935);
  add(chassis, new THREE.TorusGeometry(0.142, 0.012, 10, 32), M.chrome, 0, 0.93, -1.996);
  var hlLens = add(chassis, new THREE.SphereGeometry(0.128, 28, 14, 0, TAU, 0, PI / 2).rotateX(-PI / 2).scale(1, 1, 0.55), M.head, 0, 0.93, -1.99);
  var hlGlass = add(chassis, new THREE.SphereGeometry(0.136, 28, 14, 0, TAU, 0, PI / 2).rotateX(-PI / 2).scale(1, 1, 0.55), M.glass, 0, 0.93, -1.995);
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, new THREE.SphereGeometry(0.036, 14, 10).scale(1, 0.8, 1.2), sx < 0 ? M.sigL : M.sigR, sx * 0.30, 0.98, -1.78);
    add(chassis, new THREE.TorusGeometry(0.038, 0.007, 6, 16), M.chrome, sx * 0.30, 0.98, -1.795);
  }
  
  add(chassis, rboxGeo(0.20, 0.03, 0.03, 0.01), M.chrome, 0, 0.78, -1.955);
  add(chassis, new THREE.CylinderGeometry(0.03, 0.03, 0.006, 20).rotateX(PI / 2), M.accent, 0, 1.12, -1.80);

  
  add(chassis, rboxGeo(0.56, 0.05, 0.32, 0.015), M.plastic, 0, 1.205, -1.02);
  add(chassis, rboxGeo(0.26, 0.10, 0.13, 0.025), M.plastic, 0, 1.265, -1.06);
  var dialMat = texMat(TX.dial, 0x14191f, { roughness: 0.4 });
  var dial = add(chassis, new THREE.CircleGeometry(0.085, 32), dialMat, 0, 1.285, -0.995);
  dial.rotation.x = -0.45;
  add(chassis, new THREE.CylinderGeometry(0.09, 0.09, 0.006, 32).rotateX(PI / 2 - 0.45), M.glass, 0, 1.287, -0.99);
  var needleGroup = new THREE.Group();
  needleGroup.position.set(0, 1.287, -0.992); needleGroup.rotation.x = -0.45;
  chassis.add(needleGroup);
  add(needleGroup, new THREE.BoxGeometry(0.006, 0.07, 0.003), M.accent, 0, 0.032, 0.002);
  add(needleGroup, new THREE.CylinderGeometry(0.009, 0.009, 0.006, 12).rotateX(PI / 2), M.chrome, 0, 0, 0.003);
  var warnA = add(chassis, new THREE.SphereGeometry(0.011, 10, 8), M.sigR, 0.14, 1.245, -0.985);
  var warnB = add(chassis, new THREE.SphereGeometry(0.011, 10, 8), M.rev, -0.14, 1.245, -0.985);
  add(chassis, new THREE.CylinderGeometry(0.014, 0.014, 0.03, 10).rotateX(PI / 2), M.chrome, 0.20, 1.215, -0.93);     
  rod(chassis, [0, 1.16, -1.06], [0, 1.15, -0.90], 0.04, M.darkMetal, 12);

  
  add(barGroup, new THREE.CylinderGeometry(0.03, 0.03, 0.10, 12), M.chrome, 0, -0.045, 0);
  rod(barGroup, [-0.20, 0, 0], [0.20, 0, 0], 0.016, M.chrome, 10);
  rod(barGroup, [-0.20, 0, 0], [-GRIP.x, 0, GRIP.z], 0.016, M.chrome, 10);
  rod(barGroup, [0.20, 0, 0], [GRIP.x, 0, GRIP.z], 0.016, M.chrome, 10);
  var gripL = new THREE.Group(); gripL.position.set(-GRIP.x, 0, GRIP.z); barGroup.add(gripL);
  var gripR = new THREE.Group(); gripR.position.set(GRIP.x, 0, GRIP.z); barGroup.add(gripR);
  add(gripL, new THREE.CylinderGeometry(0.0235, 0.0235, 0.14, 16).rotateZ(PI / 2), M.rubber, 0, 0, 0);
  add(gripR, new THREE.CylinderGeometry(0.0255, 0.0255, 0.14, 16).rotateZ(PI / 2), M.rubber, 0, 0, 0);
  add(gripR, new THREE.CylinderGeometry(0.03, 0.03, 0.01, 16).rotateZ(PI / 2), M.chrome, -0.075, 0, 0);
  add(gripL, new THREE.CylinderGeometry(0.03, 0.03, 0.01, 16).rotateZ(PI / 2), M.chrome, 0.075, 0, 0);
  rod(barGroup, [-0.30, 0.012, 0.03], [-0.315, 0.02, -0.13], 0.007, M.chrome, 6);       
  rod(barGroup, [0.30, 0.012, 0.03], [0.315, 0.02, -0.13], 0.007, M.chrome, 6);         
  add(barGroup, rboxGeo(0.06, 0.04, 0.05, 0.01), M.plastic, 0.22, 0.03, 0.0);

  
  var wsTilt = Math.atan2(0.17, 0.88);
  var wsGeo = new THREE.PlaneGeometry(1.20, 0.90, 16, 1);
  (function () { var p = wsGeo.attributes.position, q; for (q = 0; q < p.count; q++) { var u = p.getX(q) / 0.60; p.setZ(q, -0.045 * (1 - u * u) + 0.0); } wsGeo.computeVertexNormals(); })();
  var windshield = add(chassis, wsGeo, M.glass, 0, 1.62, -1.065);
  windshield.rotation.x = wsTilt;
  var wBL = [-0.62, 1.18, -1.13], wBR = [0.62, 1.18, -1.13], wTL = [-0.62, 2.04, -0.99], wTR = [0.62, 2.04, -0.99];
  rod(chassis, wBL, wTL, 0.022, M.plastic, 10); rod(chassis, wBR, wTR, 0.022, M.plastic, 10);
  rod(chassis, wBL, wBR, 0.018, M.plastic, 10);
  tube(chassis, [wTL, [0, 2.07, -1.0], wTR], 0.014, M.plastic, 10);
  var bannerMat = texMat(TX.banner, 0x141416, { transparent: true, opacity: 0.95, side: THREE.DoubleSide });
  var banner = add(chassis, new THREE.PlaneGeometry(1.0, 0.10), bannerMat, 0, 1.985, -1.0);
  banner.rotation.x = wsTilt;
  var wiperPivot = new THREE.Group(); wiperPivot.position.set(0.05, 1.21, -1.135); wiperPivot.rotation.x = wsTilt; chassis.add(wiperPivot);
  rod(wiperPivot, [0, 0, 0], [0.45, 0.20, 0], 0.005, M.darkMetal, 6);
  rod(wiperPivot, [0.08, 0.035, 0.002], [0.42, 0.19, 0.002], 0.004, M.rubber, 4);
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.64, 1.42, -1.12], [sx * 0.80, 1.40, -1.20], 0.011, M.chrome, 8);
    var mh = add(chassis, rboxGeo(0.10, 0.14, 0.035, 0.015), M.plastic, sx * 0.82, 1.40, -1.21);
    mh.rotation.y = sx * 0.30;
    var mg = add(chassis, new THREE.PlaneGeometry(0.086, 0.122), M.mirror, sx * 0.82 - sx * 0.006, 1.40, -1.193);
    mg.rotation.y = sx * 0.30 + PI;
  }

  
  var rz = [-1.22, -1.15, -1.0, -0.5, 0.2, 0.8, 1.02, 1.10];
  var rhw = [0.62, 0.72, 0.76, 0.77, 0.77, 0.76, 0.72, 0.66];
  var ry0 = [2.02, 2.06, 2.08, 2.08, 2.07, 2.04, 1.98, 1.92];
  var rcr = [0.06, 0.10, 0.13, 0.16, 0.16, 0.14, 0.10, 0.06];
  var roofSecs = [], NR = 14, th = 0.035;
  for (i = 0; i < rz.length; i++) {
    var loop = [], q2;
    for (q2 = 0; q2 <= NR; q2++) { var ph = -PI / 2 + q2 / NR * PI; var xx = rhw[i] * Math.sin(ph); loop.push([xx, ry0[i] + rcr[i] * (1 - Math.pow(xx / rhw[i], 2)) , rz[i]]); }
    for (q2 = NR; q2 >= 0; q2--) { var ph2 = -PI / 2 + q2 / NR * PI; var x2 = rhw[i] * Math.sin(ph2); loop.push([x2, ry0[i] + rcr[i] * (1 - Math.pow(x2 / rhw[i], 2)) - th, rz[i]]); }
    roofSecs.push(loop);
  }
  var roofMesh = add(chassis, loft(roofSecs), M.roof, 0, 0, 0, true);
  
  for (k = 0; k < 4; k++) {
    var zb = -0.9 + k * 0.62, pts = [], q3;
    for (q3 = 0; q3 <= 10; q3++) { var u2 = -1 + q3 / 5, xv = 0.74 * u2; pts.push([xv, 2.052 + 0.14 * (1 - u2 * u2), zb]); }
    tube(chassis, pts, 0.009, M.chrome, 16);
  }
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.75, 2.045, -1.12], [sx * 0.76, 2.045, 1.0], 0.013, M.chrome, 8);
    
    rod(chassis, [sx * 0.64, 1.18, -1.13], [sx * 0.72, 2.04, -1.06], 0.024, M.chrome, 10);
    rod(chassis, [sx * 0.66, 0.88, 0.82], [sx * 0.74, 2.03, 0.90], 0.024, M.chrome, 10);
    rod(chassis, [sx * 0.69, 1.30, 0.66], [sx * 0.69, 1.30, -0.02], 0.014, M.chrome, 8);    
    rod(chassis, [sx * 0.69, 1.30, -0.02], [sx * 0.69, 1.04, -0.02], 0.014, M.chrome, 8);
    
    rod(chassis, [sx * 0.78, 1.97, -0.98], [sx * 0.78, 1.97, 0.90], 0.042, M.roof, 14);
    for (k = 0; k < 3; k++) add(chassis, rboxGeo(0.018, 0.10, 0.04, 0.006), M.rubber, sx * 0.78, 1.965, -0.62 + k * 0.62);
  }

  
  var drvBase = solid(add(chassis, rboxGeo(0.60, 0.34, 0.52, 0.04), M.darkMetal, 0, 0.58, -0.30, true));
  add(chassis, rboxGeo(0.56, 0.10, 0.48, 0.045), M.seat, 0, 0.835, -0.30);
  add(chassis, rboxGeo(0.98, 0.42, 0.09, 0.05), M.seat, 0, 1.10, -0.04);
  add(chassis, rboxGeo(1.10, 0.10, 0.56, 0.05), M.seat, 0, 0.855, 0.30);
  add(chassis, rboxGeo(1.10, 0.46, 0.10, 0.05), M.seat, 0, 1.10, 0.66);
  
  add(chassis, rboxGeo(0.12, 0.02, 0.07, 0.008), M.rubber, 0.30, 0.425, -0.93);
  rod(chassis, [0.30, 0.43, -0.93], [0.30, 0.55, -1.02], 0.009, M.chrome, 6);
  rod(chassis, [-0.30, 0.43, -0.93], [-0.30, 0.55, -1.02], 0.009, M.chrome, 6);

  
  var rbz = [-0.10, 0.05, 0.40, 0.75, 0.93, 1.00, 1.03];
  var rbw = [0.60, 0.62, 0.62, 0.61, 0.58, 0.54, 0.50];
  var rbt = [0.80, 0.82, 0.82, 0.81, 0.78, 0.74, 0.70];
  var rbb = [0.40, 0.38, 0.36, 0.36, 0.38, 0.40, 0.42];
  var rearSecs = [];
  for (i = 0; i < rbz.length; i++) rearSecs.push(sect(rbz[i], rbw[i], rbb[i], rbt[i], 3.4, 28, 0));
  var rearBlock = solid(add(chassis, loft(rearSecs), M.body, 0, 0, 0, true));
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, fenderGeo(DIM.rearR + 0.065, DIM.rearW + 0.09, 0.05, PI - 0.15), M.body, sx * DIM.rearX, DIM.rearR, 0.0, true);
    add(chassis, new THREE.TorusGeometry(DIM.rearR + 0.065, 0.007, 6, 28, PI - 0.2).rotateY(-PI / 2), M.chrome, sx * (DIM.rearX + (DIM.rearW + 0.09) / 2), DIM.rearR, 0.0);
    
    for (k = 0; k < 6; k++) add(chassis, new THREE.BoxGeometry(0.012, 0.022, 0.20), M.plastic, sx * 0.628, 0.50 + k * 0.042, 0.52);
    
    add(chassis, new THREE.BoxGeometry(0.010, 0.045, 0.80), M.accent, sx * 0.628, 0.735, 0.46);
    
    add(chassis, rboxGeo(0.12, 0.035, 1.0, 0.012), M.darkMetal, sx * 0.58, 0.41, -0.55);
    
    add(chassis, rboxGeo(0.16, 0.20, 0.010, 0.004), M.rubber, sx * DIM.rearX, 0.19, 0.36);
  }

  
  var plateMat = texMat(TX.plate, 0xf2f2ec, { roughness: 0.5 });
  add(chassis, rboxGeo(0.50, 0.25, 0.014, 0.006), M.darkMetal, 0, 0.56, 1.03);
  add(chassis, new THREE.PlaneGeometry(0.46, 0.21), plateMat, 0, 0.56, 1.040);
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, rboxGeo(0.14, 0.10, 0.03, 0.012), M.chrome, sx * 0.44, 0.72, 1.00);
    add(chassis, rboxGeo(0.12, 0.085, 0.03, 0.012), M.tail, sx * 0.44, 0.72, 1.02);
    add(chassis, new THREE.SphereGeometry(0.026, 10, 8).scale(1, 1, 0.5), sx < 0 ? M.sigL : M.sigR, sx * 0.44, 0.63, 1.03);
    add(chassis, new THREE.CircleGeometry(0.026, 14), M.rev, sx * 0.26, 0.72, 1.034);
    rod(chassis, [sx * 0.60, 0.42, 1.02], [sx * 0.66, 0.42, 0.84], 0.026, M.chrome, 10);
  }
  rod(chassis, [-0.60, 0.42, 1.03], [0.60, 0.42, 1.03], 0.026, M.chrome, 12);
  
  var exhaustPos = new THREE.Vector3(0.44, 0.30, 1.13);
  tube(chassis, [[0.30, 0.34, 0.30], [0.42, 0.30, 0.60], [0.44, 0.29, 0.88]], 0.022, M.darkMetal, 18);
  add(chassis, new THREE.CylinderGeometry(0.058, 0.058, 0.36, 18).rotateX(PI / 2), M.steel, 0.44, 0.285, 0.95);
  add(chassis, new THREE.CylinderGeometry(0.062, 0.062, 0.16, 18, 1, true).rotateX(PI / 2), M.darkMetal, 0.44, 0.285, 0.84);
  add(chassis, new THREE.CylinderGeometry(0.028, 0.026, 0.14, 14).rotateX(PI / 2), M.chrome, 0.44, 0.285, 1.10);
  add(chassis, new THREE.TorusGeometry(0.027, 0.005, 6, 14), M.darkMetal, 0.44, 0.285, 1.175);

  
  var headSpot = null;
  try {
    headSpot = new THREE.SpotLight(0xfff0c8, 0, 40, 0.5, 0.55, 1.6);
    headSpot.position.set(0, 0.93, -2.0);
    headSpot.castShadow = false;
    chassis.add(headSpot);
    headSpot.target.position.set(0, 0.4, -16);
    chassis.add(headSpot.target);
  } catch (e) { headSpot = null; }

  
  var SMOKE_N = 8;
  var smokeGeo = new THREE.SphereGeometry(0.07, 8, 6);
  var puffs = [];
  for (i = 0; i < SMOKE_N; i++) {
    var pm = new THREE.Mesh(smokeGeo, M.smoke.clone());
    pm.visible = false; pm.userData.noCollision = true;
    root.add(pm);
    puffs.push({ mesh: pm, pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0, max: 1 });
  }
  var wallList = [];

  
  
  
  var lastParamKey = "";
  function setCol(mat, str) { try { mat.color.set(str); } catch (e) {} }
  function refreshParams(dt, force) {
    S.paramT += dt;
    if (!force && S.paramT < 0.4) return;
    S.paramT = 0;
    var key = [PS("bodyColor", "#e6b400"), PS("roofColor", "#1a1b1e"), PS("accentColor", "#b3261e"), PS("seatColor", "#2a1d17"), PS("bannerText", ""), PS("plateText", "")].join("|");
    if (key === lastParamKey) return;
    lastParamKey = key;
    setCol(M.body, PS("bodyColor", "#e6b400"));
    setCol(M.roof, PS("roofColor", "#1a1b1e"));
    setCol(M.accent, PS("accentColor", "#b3261e"));
    setCol(M.seat, PS("seatColor", "#2a1d17"));
    redrawTex(TX.plate); redrawTex(TX.banner);
  }

  
  
  
  var mouse = { down: false, dx: 0, dy: 0, wheel: 0, lastX: null, lastY: null };
  function onMouseDown() { mouse.down = true; mouse.lastX = null; }
  function onMouseUp() { mouse.down = false; mouse.lastX = null; }
  function onMouseMove(e) {
    if (S.mode === "idle") return;
    var locked = (typeof document !== "undefined") && !!document.pointerLockElement;
    if (!locked && !mouse.down) { mouse.lastX = null; return; }
    var mx = e.movementX, my = e.movementY;
    if (mx === undefined || my === undefined) {
      if (mouse.lastX !== null) { mx = e.clientX - mouse.lastX; my = e.clientY - mouse.lastY; } else { mx = 0; my = 0; }
      mouse.lastX = e.clientX; mouse.lastY = e.clientY;
    }
    mouse.dx += mx; mouse.dy += my;
  }
  function onWheel(e) { if (S.mode !== "idle") mouse.wheel += (e.deltaY || 0); }
  if (typeof window !== "undefined" && window.addEventListener) {
    window.addEventListener("mousedown", onMouseDown, true);
    window.addEventListener("mouseup", onMouseUp, true);
    window.addEventListener("mousemove", onMouseMove, true);
    window.addEventListener("wheel", onWheel, { passive: true, capture: true });
  }

  
  
  
  var _tmpA = new THREE.Vector3(), _tmpB = new THREE.Vector3(), _seatW = new THREE.Vector3(), _camT = new THREE.Vector3(), _ray = null;
  var LN = null;

  function ensureMatrices() {
    if (S.matFrame === S.frameNo) return;
    S.matFrame = S.frameNo;
    root.updateMatrixWorld(true);
  }
  function playerWorldPos(out) {
    var lp = call("getLocalPlayer");
    if (!lp) return null;
    var m = lp.mesh;
    if (m && typeof m.getWorldPosition === "function") { m.getWorldPosition(out); return out; }
    if (lp.position) { out.set(lp.position.x || 0, lp.position.y || 0, lp.position.z || 0); return out; }
    return null;
  }
  function placePlayer(x, y, z) {
    if (typeof Game.setPlayerPosition === "function") { call("setPlayerPosition", 0, x, y, z, { hold: true }); return; }
    var lp = call("getLocalPlayer");
    if (lp && lp.mesh) lp.mesh.position.set(x, y, z);
  }
  function setPlayerYawSafe(yaw) {
    if (typeof Game.setPlayerYaw === "function") { call("setPlayerYaw", 0, yaw); return; }
    var lp = call("getLocalPlayer");
    if (lp && lp.mesh) lp.mesh.rotation.y = yaw;
  }
  function seatWorld(out) {
    ensureMatrices();
    _tmpA.set(SEAT.x, SEAT.y + PN("riderLift", 0), SEAT.z);
    out.copy(_tmpA);
    chassis.localToWorld(out);
    return out;
  }
  function riderYaw() {
    return S.yaw + S.yawFix + PN("riderYawOffsetDeg", 0) * PI / 180;
  }
  
  function calibrateYaw() {
    if (S.yawFixTries >= 4 || S.t - S.yawFixT < 0.12) return;
    var f = call("getPlayerForward", 0);
    if (!f) return;
    var fx = (f.x !== undefined) ? f.x : f[0], fz = (f.z !== undefined) ? f.z : (f.y !== undefined && f.length === undefined ? f.y : f[1]);
    if (!isFinite(fx) || !isFinite(fz) || (Math.abs(fx) + Math.abs(fz)) < 1e-4) return;
    S.yawFixT = S.t;
    var wantX = -Math.sin(S.yaw), wantZ = -Math.cos(S.yaw);
    var diff = wrap(Math.atan2(wantX, wantZ) - Math.atan2(fx, fz));
    if (Math.abs(diff) > 0.06) { S.yawFix = wrap(S.yawFix + diff); S.yawFixTries++; }
    else S.yawFixTries = 99;
  }
  function resolveLimbNames() {
    function pick(c) {
      for (var j = 0; j < c.length; j++) { if (call("getBone", 0, c[j])) return c[j]; }
      return c[0];
    }
    LN = {
      rArm: "rightArm", lArm: "leftArm", rLeg: "rightLeg", lLeg: "leftLeg",
      rFore: pick(["rightForearm", "rightLowerArm", "rightElbow"]),
      lFore: pick(["leftForearm", "leftLowerArm", "leftElbow"]),
      rShin: pick(["rightShin", "rightLowerLeg", "rightCalf", "rightKnee"]),
      lShin: pick(["leftShin", "leftLowerLeg", "leftCalf", "leftKnee"]),
      outR: -1
    };
    var b = call("getBone", 0, "rightArm");
    if (b && b.position && Math.abs(b.position.x) > 0.02) LN.outR = sgn(b.position.x);
  }
  function limb(name, rx, ry, rz) { call("setPlayerLimb", 0, name, rx, ry, rz, { lock: true }); }
  function limbFree(name) { call("setPlayerLimb", 0, name, 0, 0, 0, { lock: false }); }

  
  function gripLocal(side, out) {
    var gx = side * GRIP.x, c = Math.cos(S.barAngle), s = Math.sin(S.barAngle);
    out.set(BAR.x + gx * c + GRIP.z * s, BAR.y + GRIP.y, BAR.z - gx * s + GRIP.z * c);
    return out;
  }
  
  var _armOut = [0, 0, 0];
  function solveArm(side, outSign) {
    gripLocal(side, _tmpB);
    var shx = SEAT.x + side * RIDER.shoulderX, shy = SEAT.y + RIDER.shoulderY, shz = SEAT.z;
    var f = -(_tmpB.z - shz), u = _tmpB.y - shy, lOut = (_tmpB.x - shx) * side;
    var r = Math.sqrt(f * f + lOut * lOut);
    var gamma = Math.atan2(lOut, f);
    var L1 = RIDER.upperArm, L2 = RIDER.foreArm;
    var D = Math.sqrt(r * r + u * u);
    var Dmax = (L1 + L2) * 0.985, Dmin = Math.abs(L1 - L2) + 0.03;
    var Dc = clamp(D, Dmin, Dmax);
    var cosA = clamp((L1 * L1 + Dc * Dc - L2 * L2) / (2 * L1 * Dc), -1, 1);
    var A = Math.acos(cosA);
    var cosE = clamp((L1 * L1 + L2 * L2 - Dc * Dc) / (2 * L1 * L2), -1, 1);
    var E = Math.acos(cosE);
    var thetaT = Math.atan2(r, -u);
    var au = thetaT - A;
    var aFwd = Math.sin(au) * Math.cos(gamma), aOut = Math.sin(au) * Math.sin(gamma), aDown = Math.cos(au);
    _armOut[0] = -Math.atan2(aFwd, aDown);
    _armOut[1] = Math.asin(clamp(outSign * aOut, -1, 1));
    _armOut[2] = -(PI - E);
    return _armOut;
  }
  
  function applyRiderPose(blend) {
    if (!LN) resolveLimbNames();
    var flip = PB("flipArmSide", false) ? -1 : 1;
    var outR = LN.outR * flip, outL = -LN.outR * flip;
    var kn = PB("flipKnee", false) ? -1 : 1;
    var a = solveArm(1, outR);
    limb(LN.rArm, a[0] * blend, 0, a[1] * blend);
    limb(LN.rFore, a[2] * blend, 0, 0);
    a = solveArm(-1, outL);
    limb(LN.lArm, a[0] * blend, 0, a[1] * blend);
    limb(LN.lFore, a[2] * blend, 0, 0);
    limb(LN.rLeg, RIDER.thighRx * blend, 0, outR * RIDER.kneeSpread * blend);
    limb(LN.lLeg, RIDER.thighRx * blend, 0, outL * RIDER.kneeSpread * blend);
    limb(LN.rShin, RIDER.shinRx * kn * blend, 0, 0);
    limb(LN.lShin, RIDER.shinRx * kn * blend, 0, 0);
  }
  function releaseRiderPose() {
    if (!LN) return;
    limbFree(LN.rArm); limbFree(LN.lArm); limbFree(LN.rFore); limbFree(LN.lFore);
    limbFree(LN.rLeg); limbFree(LN.lLeg); limbFree(LN.rShin); limbFree(LN.lShin);
  }

  
  
  
  function isOwn(o) { while (o) { if (o === root) return true; o = o.parent; } return false; }
  function wallFlag(o) {
    var n = 0;
    while (o && n < 4) {
      var u = o.userData;
      if (u) {
        if (u.walkable || u.isFloor) return false;
        if (u.isWall || u.blocksPlayer) return true;
      }
      o = o.parent; n++;
    }
    return false;
  }
  function rebuildWalls() {
    wallList.length = 0;
    S.wallT = S.t;
    var sc = Game.scene;
    if (!sc || typeof sc.traverse !== "function") return;
    try {
      sc.traverse(function (o) { if (o.isMesh && o.visible !== false && !isOwn(o) && wallFlag(o)) wallList.push(o); });
    } catch (e) {}
  }
  var RAY_FRONT = [[0, 0.7, -2.4], [-0.6, 0.7, -1.3], [0.6, 0.7, -1.3]];
  var RAY_REAR = [[0, 0.7, 1.15], [-0.6, 0.7, 0.95], [0.6, 0.7, 0.95]];
  function obstacleDistance(dirSign, reach) {
    if (!wallList.length) return Infinity;
    if (!_ray) _ray = new THREE.Raycaster();
    var set = dirSign < 0 ? RAY_FRONT : RAY_REAR, best = Infinity, j;
    var dx = -Math.sin(S.yaw) * (dirSign < 0 ? 1 : -1), dz = -Math.cos(S.yaw) * (dirSign < 0 ? 1 : -1);
    _tmpA.set(dx, 0, dz);
    for (j = 0; j < set.length; j++) {
      _tmpB.set(set[j][0], set[j][1], set[j][2]);
      root.localToWorld(_tmpB);
      _ray.set(_tmpB, _tmpA);
      _ray.near = 0; _ray.far = reach;
      var hits = _ray.intersectObjects(wallList, false);
      if (hits.length && hits[0].distance < best) best = hits[0].distance;
    }
    return best;
  }

  
  
  
  var AU = { ctx: null, master: null, src: [], osc: null, lp: null, res: null, gEng: null, gMech: null, gTire: null, gWind: null, bpMech: null, bpTire: null, gHorn: null, vol: 0.5, jit: 0 };
  function audioStart() {
    if (AU.ctx || !PB("soundOn", true)) return;
    try {
      var AC = (typeof window !== "undefined") ? (window.AudioContext || window.webkitAudioContext) : null;
      if (!AC) return;
      var ctx = new AC(), i, h;
      var master = ctx.createGain(); master.gain.value = 0.0001;
      var comp = ctx.createDynamicsCompressor(); comp.threshold.value = -20; comp.ratio.value = 5; comp.attack.value = 0.005; comp.release.value = 0.15;
      master.connect(comp); comp.connect(ctx.destination);
      
      var NH = 56, re = new Float32Array(NH + 1), im = new Float32Array(NH + 1);
      for (h = 1; h <= NH; h++) { re[h] = 1 / Math.pow(h, 0.62); im[h] = 0.25 * Math.sin(h * 1.3) / Math.pow(h, 0.9); }
      var osc = ctx.createOscillator(); osc.setPeriodicWave(ctx.createPeriodicWave(re, im)); osc.frequency.value = 11;
      var lp = ctx.createBiquadFilter(); lp.type = "lowpass"; lp.Q.value = 0.8; lp.frequency.value = 500;
      var res = ctx.createBiquadFilter(); res.type = "peaking"; res.frequency.value = 170; res.Q.value = 2.5; res.gain.value = 8;
      var gEng = ctx.createGain(); gEng.gain.value = 0;
      osc.connect(lp); lp.connect(res); res.connect(gEng); gEng.connect(master);
      
      var nb = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), nd = nb.getChannelData(0);
      for (i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
      function noise() { var s = ctx.createBufferSource(); s.buffer = nb; s.loop = true; s.loopStart = Math.random(); return s; }
      var nMech = noise(), bpMech = ctx.createBiquadFilter(); bpMech.type = "bandpass"; bpMech.frequency.value = 2200; bpMech.Q.value = 1.1;
      var gMech = ctx.createGain(); gMech.gain.value = 0; nMech.connect(bpMech); bpMech.connect(gMech); gMech.connect(master);
      var nTire = noise(), bpTire = ctx.createBiquadFilter(); bpTire.type = "bandpass"; bpTire.frequency.value = 520; bpTire.Q.value = 0.6;
      var gTire = ctx.createGain(); gTire.gain.value = 0; nTire.connect(bpTire); bpTire.connect(gTire); gTire.connect(master);
      var nWind = noise(), lpW = ctx.createBiquadFilter(); lpW.type = "lowpass"; lpW.frequency.value = 1800;
      var gWind = ctx.createGain(); gWind.gain.value = 0; nWind.connect(lpW); lpW.connect(gWind); gWind.connect(master);
      
      var hA = ctx.createOscillator(); hA.type = "square"; hA.frequency.value = 405;
      var hB = ctx.createOscillator(); hB.type = "square"; hB.frequency.value = 507;
      var hl = ctx.createBiquadFilter(); hl.type = "lowpass"; hl.frequency.value = 2400;
      var gHorn = ctx.createGain(); gHorn.gain.value = 0.0001;
      hA.connect(hl); hB.connect(hl); hl.connect(gHorn); gHorn.connect(master);
      osc.start(); nMech.start(); nTire.start(); nWind.start(); hA.start(); hB.start();
      if (ctx.state === "suspended" && typeof ctx.resume === "function") ctx.resume();
      AU.ctx = ctx; AU.master = master; AU.osc = osc; AU.lp = lp; AU.res = res; AU.gEng = gEng; AU.gMech = gMech; AU.bpMech = bpMech;
      AU.gTire = gTire; AU.bpTire = bpTire; AU.gWind = gWind; AU.gHorn = gHorn; AU.src = [osc, nMech, nTire, nWind, hA, hB];
    } catch (e) { AU.ctx = null; }
  }
  function audioUpdate(dt) {
    if (!AU.ctx) return;
    try {
      var vol = clamp(PN("soundVolume", 0.55), 0, 1), t = AU.ctx.currentTime;
      var active = (S.mode === "riding" || S.mode === "mounting" || S.mode === "dismounting");
      var run = S.engine !== "off" && S.rpm > 50;
      var rpmF = clamp(S.rpm / RPM_MAX, 0, 1), av = Math.abs(S.v);
      var idleJit = (1 - rpmF) * (0.045 + 0.03 * Math.random());
      AU.jit = damp(AU.jit, (Math.random() - 0.5) * 2, 12, dt);
      var f = Math.max(2, S.rpm / 120) * (1 + AU.jit * idleJit);
      AU.osc.frequency.setTargetAtTime(f, t, 0.025);
      AU.lp.frequency.setTargetAtTime(320 + S.rpm * 0.20 + S.thr * 900, t, 0.06);
      AU.res.frequency.setTargetAtTime(120 + rpmF * 150, t, 0.1);
      var eng = run ? vol * (0.30 + 0.45 * S.thr + 0.35 * rpmF) : 0;
      AU.gEng.gain.setTargetAtTime(eng * (S.engine === "cranking" ? 0.7 : 1), t, 0.05);
      AU.bpMech.frequency.setTargetAtTime(1500 + rpmF * 2600, t, 0.1);
      AU.gMech.gain.setTargetAtTime(run ? vol * (0.015 + 0.05 * rpmF + (S.engine === "cranking" ? 0.05 : 0)) : 0, t, 0.08);
      var skid = (S.hb && av > 2) ? 1 : clamp(S.slip - 0.9, 0, 1);
      AU.bpTire.frequency.setTargetAtTime(520 + av * 14 + skid * 1300, t, 0.1);
      AU.gTire.gain.setTargetAtTime(vol * (0.075 * smooth(0.5, 12, av) + 0.12 * skid), t, 0.1);
      AU.gWind.gain.setTargetAtTime(vol * 0.06 * Math.pow(av / 16, 2), t, 0.15);
      AU.gHorn.gain.setTargetAtTime(S.horn ? vol * 0.10 : 0.0001, t, S.horn ? 0.015 : 0.04);
      AU.master.gain.setTargetAtTime(active || S.coast ? 1 : 0.0001, t, 0.2);
    } catch (e) {}
  }
  function hornSet(on) { S.horn = !!on; }
  function audioHorn() { hornSet(true); }
  function audioStop(immediate) {
    if (!AU.ctx) return;
    var ctx = AU.ctx, srcs = AU.src;
    try { AU.master.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.08); } catch (e) {}
    AU.ctx = null; S.horn = false;
    var closer = function () { for (var j = 0; j < srcs.length; j++) { try { srcs[j].stop(); } catch (e) {} } try { ctx.close(); } catch (e2) {} };
    if (immediate || typeof setTimeout !== "function") closer(); else setTimeout(closer, 450);
  }

  
  
  
  var G0 = 9.81;
  function engineTorque(rpm) {                 
    var x = (rpm - 3800) / 4200;
    return clamp(1 - 0.75 * x * x, 0.25, 1);
  }
  function engineStep(dt, thr, av, wheelRpm) {
    var ratio = S.gear < 0 ? 30 : GEARS[Math.max(1, S.gear)];
    if (S.engine === "off") { S.engine = "cranking"; S.engT = 0; }
    S.engT += dt;
    if (S.engine === "cranking") {
      
      S.rpm = damp(S.rpm, 230 + 60 * Math.sin(S.t * 38), 14, dt);
      if (S.engT > 0.55) { S.engine = "run"; S.rpm = 1900; }
      return 1;
    }
    var launch = 1 - smooth(0.2, 5, av);
    var rpmT = Math.max(wheelRpm * ratio, RPM_IDLE + S.thr * 2900 * launch + S.thr * 700 * (1 - launch) * (wheelRpm * ratio < 3000 ? 1 : 0));
    var rate = rpmT > S.rpm ? 7 : 4;
    S.rpm = damp(S.rpm, rpmT, rate, dt);
    var lim = 1;
    if (S.rpm > RPM_MAX) { S.rpm = RPM_MAX - 150; lim = 0.15; }   
    return lim;
  }
  function physicsStep(dt, thr, brk, left, right, hb) {
    var maxV = PN("maxSpeed", 16), revMax = PN("reverseMaxSpeed", 4);
    var mass = PN("mass", 520), Tmax = PN("enginePower", 26);
    var brakeP = PN("brakePower", 7.5), hbP = PN("handbrakePower", 9), gripLim = PN("gripLimit", 7.2);
    var v = S.v, av = Math.abs(v), rW = DIM.rearR, i;
    S.throttleOn = thr; S.brakeOn = false; S.reverseOn = false; S.hb = !!hb;
    var engaged = (S.mode === "riding" || S.mode === "mounting");
    S.thr = damp(S.thr, (thr && engaged) ? 1 : 0, thr ? 7 : 10, dt);
    var wheelRpm = av / rW * 60 / TAU;

    
    var reverseWish = brk && !thr && v < 0.4;
    if (reverseWish && av < 0.6) S.gear = -1;
    else if (S.gear < 0 && (v > 0.4 || (thr && av < 0.6))) S.gear = 1;
    if (S.gear > 0) {
      S.shiftT = Math.max(0, S.shiftT - dt);
      var rpmG = wheelRpm * GEARS[S.gear];
      if (S.shiftT <= 0) {
        if (rpmG > RPM_UP && S.gear < 4 && thr) { S.gear++; S.shiftT = 0.38; }
        else if (rpmG < RPM_DOWN && S.gear > 1) { S.gear--; S.shiftT = 0.30; }
      }
    }
    var lim = engaged ? engineStep(dt, thr, av, wheelRpm) : 1;
    if (!engaged && S.engine !== "off") { S.rpm = damp(S.rpm, RPM_IDLE, 3, dt); }
    var ratio = S.gear < 0 ? 30 : GEARS[Math.max(1, S.gear)];
    var cut = S.shiftT > 0.25 ? 0 : 1;

    
    var F = 0;
    if (engaged && S.engine === "run") {
      var Tq = Tmax * engineTorque(S.rpm);
      var fwd = S.gear > 0 && thr;
      var rev = S.gear < 0 && brk;
      if (fwd || rev) {
        var gov = rev ? (1 - smooth(0.75, 1, av / revMax)) : (1 - smooth(0.82, 1, av / maxV));
        var Fe = Tq * ratio * 0.85 / rW * gov * cut * lim * (fwd ? S.thr : 1);
        var Ftr = 0.80 * G0 * mass * 0.62;                
        Fe = Math.min(Fe, Ftr);
        F += rev ? -Fe : Fe;
        if (rev) S.reverseOn = true;
      }
    }
    
    var sv = sgn(v);
    var Fres = (0.018 * mass * G0) * smooth(0, 0.4, av) + 0.69 * v * av;
    var engBrake = (engaged && S.gear > 0 && !thr) ? ratio * 11 * clamp(S.rpm / RPM_MAX, 0.2, 1) * smooth(0, 1, av) : 0;
    if (!engaged) engBrake = 0;
    F -= sv * (Fres + engBrake);
    
    if (brk && v > 0.3) { F -= brakeP * mass; S.brakeOn = true; }
    if (hb && av > 0.05) { F -= sv * hbP * mass; S.brakeOn = true; }
    if (!thr && !brk && !hb && av < 0.12 && Math.abs(F) < 800) {  }
    var a = F / mass;
    var nv = v + a * dt;
    
    var driving = (thr && S.gear > 0 && engaged) || (brk && S.gear < 0 && engaged);
    if (!driving && sgn(nv) !== sv && v !== 0) nv = 0;
    if (!driving && Math.abs(nv) < 0.03) nv = 0;
    nv = clamp(nv, -revMax, maxV * 1.02);
    S.accel = damp(S.accel, (nv - v) / Math.max(dt, 1e-4), 18, dt);
    S.v = nv; v = nv; av = Math.abs(v);

    
    var steerMaxRad = PN("steerMaxDeg", 32) * PI / 180;
    var sIn = (left ? 1 : 0) - (right ? 1 : 0);
    var resp = PN("steerResponse", 6);
    S.steerIn = damp(S.steerIn, sIn, sIn === 0 ? resp * 1.5 : resp, dt);
    var spdK = smooth(2, 15, av);
    S.steerVis = S.steerIn * steerMaxRad * (1 - 0.70 * spdK);
    var yr = av > 0.03 ? (v / DIM.wheelBase) * Math.tan(S.steerVis) : 0;
    var lim2 = (hb && av > 3) ? gripLim * 0.55 : gripLim;
    var latA = yr * v;
    S.slip = Math.abs(latA) / lim2;
    if (S.slip > 1) { yr = sgn(yr) * lim2 / Math.max(av, 0.1); S.v *= (1 - 0.25 * Math.min(1, S.slip - 1) * dt * 3); }   
    if (hb && av > 4) yr *= 1.3;                                                        
    S.steerEff = S.steerVis;
    S.yawRate = damp(S.yawRate, yr, 12, dt);
    S.lat = S.yawRate * S.v;
    S.yaw += S.yawRate * dt;

    
    var eh = root.userData.engineHit;
    if (eh) {
      root.userData.engineHit = null;
      var dn = (-Math.sin(S.yaw) * eh.nx - Math.cos(S.yaw) * eh.nz) * sgn(S.v);
      if (dn < -0.15 && Math.abs(S.v) > 0.5) { if (Math.abs(S.v) > 5) S.camShake = Math.min(1, Math.abs(S.v) / 12); S.v *= (1 + dn * 0.6); }
    }
    
    if (PB("collision", true) && Math.abs(S.v) > 0.3) {
      if (S.t - S.wallT > 3) rebuildWalls();
      S.collT += dt;
      if (S.collT > 0.04) {
        S.collT = 0;
        var reach = Math.abs(S.v) * 0.12 + 0.35;
        var dist = obstacleDistance(sgn(S.v) > 0 ? -1 : 1, reach);
        if (dist < Math.abs(S.v) * 0.08 + 0.18) {
          S.camShake = Math.min(1, Math.abs(S.v) / 12);
          S.heaveV -= Math.min(0.25, Math.abs(S.v) * 0.02);
          S.pitchV += sgn(S.v) * Math.min(1.2, Math.abs(S.v) * 0.08);
          S.v = -S.v * 0.2;
        }
      }
    }
    var step = S.v * dt;
    root.position.x += -Math.sin(S.yaw) * step;
    root.position.z += -Math.cos(S.yaw) * step;
    root.rotation.y = S.yaw;
  }

  
  function updateChassisVisuals(dt, bobAmp) {
    var rollK = PN("bodyRoll", 1), rough = PN("roughRoad", 1);
    var av = Math.abs(S.v), vk = clamp(av / Math.max(1, PN("maxSpeed", 16)), 0, 1);
    var running = (S.engine === "run") && (S.mode !== "idle" || S.coast);
    
    var rollT = clamp(-S.lat * 0.0105 * rollK, -0.16, 0.16);
    S.rollV += (110 * (rollT - S.roll) - 12 * S.rollV) * dt; S.roll += S.rollV * dt;
    
    var pitchT = clamp(S.accel * 0.0062, -0.07, 0.055);
    S.pitchV += (90 * (pitchT - S.pitch) - 10 * S.pitchV) * dt; S.pitch += S.pitchV * dt;
    
    S.roadT += av * dt;
    var bump = (vnoise(S.roadT * 1.6) * 0.65 + vnoise(S.roadT * 4.3 + 9) * 0.35) * 0.014 * rough * smooth(0.3, 9, av);
    var vib = running ? Math.sin(S.t * TAU * (S.rpm / 120)) * (0.0010 + 0.0014 * clamp(S.rpm / RPM_MAX, 0, 1)) : 0;
    S.heaveV += (160 * (bump + vib - S.heave) - 15 * S.heaveV) * dt; S.heave += S.heaveV * dt;
    chassis.rotation.x = S.pitch + S.heaveV * 0.03 * rough;
    chassis.rotation.z = S.roll;
    chassis.position.y = S.heave * bobAmp;
    
    var lt = smooth(5.2, 8.2, S.lat) * 0.075, rt2 = smooth(5.2, 8.2, -S.lat) * 0.075;
    S.liftL = damp(S.liftL, lt, 12, dt); S.liftR = damp(S.liftR, rt2, 12, dt);
    wheelRL.position.y = DIM.rearR + S.liftL; wheelRR.position.y = DIM.rearR + S.liftR;
    
    var locked = S.hb && av > 0.3;
    if (!locked) S.wSpinR -= S.v / DIM.rearR * dt;
    S.wSpinF -= S.v / DIM.frontR * dt;
    wheelRL.rotation.x = S.wSpinR; wheelRR.rotation.x = S.wSpinR; wheelF.rotation.x = S.wSpinF;
    
    forkGroup.rotation.y = S.steerVis;
    S.barAngle = S.steerVis * BAR_RATIO;
    barGroup.rotation.y = S.barAngle;
    S.throttleVis = damp(S.throttleVis, S.thr, 14, dt);
    gripR.rotation.x = -S.throttleVis * 0.55;
    
    var kmh = av * 3.6;
    needleGroup.rotation.z = lerp(2.094, -2.094, clamp(kmh / 80, 0, 1)) + (running ? Math.sin(S.t * 40) * 0.01 : 0);
  }
  
  function measuredVisuals(dt) {
    var dx = root.position.x - S.lastPos.x, dz = root.position.z - S.lastPos.z;
    var fx = -Math.sin(root.rotation.y), fz = -Math.cos(root.rotation.y);
    var v = (dx * fx + dz * fz) / dt;
    var yr = wrap(root.rotation.y - S.lastYawMeasured) / dt;
    S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y;
    v = clamp(v, -40, 40);
    S.accel = damp(S.accel, (v - S.v) / dt, 10, dt);
    S.v = damp(S.v, v, 12, dt);
    S.yaw = root.rotation.y;
    S.yawRate = yr;
    S.lat = yr * S.v;
    var steer = (Math.abs(S.v) > 0.5) ? Math.atan(yr * DIM.wheelBase / S.v) : 0;
    S.steerVis = damp(S.steerVis, clamp(steer, -0.65, 0.65), 8, dt);
    S.throttleOn = false; S.brakeOn = false; S.reverseOn = false; S.thr = 0; S.hb = false;
    
    S.rpm = Math.abs(S.v) > 0.3 ? Math.min(RPM_UP, RPM_IDLE + Math.abs(S.v) * 260) : 0;
    S.engine = S.rpm > 0 ? "run" : "off";
    updateChassisVisuals(dt, 0);
  }

  
  
  
  function releaseCamera() {
    if (typeof Game.clearCamera === "function") call("clearCamera", 0);
    else call("setCamera", 0, null);
  }
  function cameraFrame(dt) {
    var sens = PN("camSensitivity", 0.0045), keyRate = PN("camKeySpeed", 1.8);
    var any = false;
    if (down("ArrowLeft")) { S.camAzOff += keyRate * dt; any = true; }
    if (down("ArrowRight")) { S.camAzOff -= keyRate * dt; any = true; }
    if (down("ArrowUp")) { S.camPitch += keyRate * 0.6 * dt; any = true; }
    if (down("ArrowDown")) { S.camPitch -= keyRate * 0.6 * dt; any = true; }
    if (mouse.dx !== 0 || mouse.dy !== 0) {
      S.camAzOff -= mouse.dx * sens; S.camPitch += mouse.dy * sens;
      mouse.dx = 0; mouse.dy = 0; any = true;
    }
    if (mouse.wheel !== 0) {
      S.camDistUser = clamp(S.camDistUser * Math.exp(mouse.wheel * 0.0012), 0.4, 2.6);
      mouse.wheel = 0; any = true;
    }
    if (any) S.lastCamInput = S.t;
    S.camPitch = clamp(S.camPitch, -0.05, 1.35);
    S.camAzOff = wrap(S.camAzOff);
    var defPitch = PN("camHeightDeg", 16) * PI / 180;
    
    if (S.t - S.lastCamInput > PN("camRecenterDelay", 2.5) && Math.abs(S.v) > 1.0) {
      S.camAzOff = damp(S.camAzOff, 0, 1.6, dt);
      S.camPitch = damp(S.camPitch, defPitch, 1.2, dt);
    }
    S.camYaw = S.camYaw + wrap(S.yaw - S.camYaw) * (1 - Math.exp(-PN("camFollow", 4.5) * dt));
    var az = S.camYaw + S.camAzOff;
    var maxV = Math.max(1, PN("maxSpeed", 18));
    var vk = clamp(Math.abs(S.v) / maxV, 0, 1);
    var dist = PN("camDistance", 6.5) * S.camDistUser * (1 + 0.08 * vk);
    ensureMatrices();
    _camT.set(0, 1.35, -0.45);
    chassis.localToWorld(_camT);
    var cp = Math.cos(S.camPitch);
    var cx = _camT.x + Math.sin(az) * cp * dist;
    var cy = _camT.y + Math.sin(S.camPitch) * dist;
    var cz = _camT.z + Math.cos(az) * cp * dist;
    cy = Math.max(cy, spawnPos.y + 0.45);
    if (S.camShake > 0.01) {
      cx += (Math.random() - 0.5) * 0.25 * S.camShake; cy += (Math.random() - 0.5) * 0.2 * S.camShake;
      S.camShake = damp(S.camShake, 0, 7, dt);
    }
    var fov = PN("camFov", 62) + PN("speedFovBoost", 8) * vk;
    call("setCamera", 0, { x: cx, y: cy, z: cz, lookX: _camT.x, lookY: _camT.y + 0.15, lookZ: _camT.z, fov: fov, lerp: clamp(PN("camLerp", 0.4), 0.05, 1) });
    
    if (PB("roofFade", true)) {
      var op = lerp(1, 0.22, smooth(0.10, 0.38, S.camPitch));
      M.roof.opacity = damp(M.roof.opacity, op, 8, dt);
      M.roof.depthWrite = M.roof.opacity > 0.97;
    } else { M.roof.opacity = 1; M.roof.depthWrite = true; }
  }

  
  
  
  function setBodyCollision(on) {
    for (var j = 0; j < solidMeshes.length; j++) {
      solidMeshes[j].userData.noCollision = !on;
      solidMeshes[j].userData.solid = !!on;
    }
  }
  function myName() { return String(call("getMyName") || "me"); }
  function startMount() {
    var cur = call("getShared", DRV_KEY, "");
    if (cur && cur !== myName()) return;
    if (!playerWorldPos(S.mountFrom)) return;
    S.lastToggle = S.t;
    S.mode = "mounting"; S.modeT = 0; S.v = 0; S.yaw = root.rotation.y; S.camYaw = S.yaw + 0.0;
    S.camAzOff = 0; S.camPitch = PN("camHeightDeg", 16) * PI / 180; S.camDistUser = 1; S.lastCamInput = -99;
    S.yawFixTries = (S.yawFixTries >= 99) ? 99 : 0;
    call("lockPlayer", 0, true);
fitRider();
        call("lockPlayerAnim", 0, true);
    call("setShared", DRV_KEY, myName());
    setBodyCollision(false);
    audioStart();
    rebuildWalls();
    S.fPrev = down("KeyF");
  }
  function startDismount() {
    S.lastToggle = S.t;
    S.mode = "dismounting"; S.modeT = 0;
    ensureMatrices();
    _tmpA.set(-1.30, 0, 0.10);
    root.localToWorld(_tmpA);
    S.exitPos.set(_tmpA.x, root.position.y, _tmpA.z);
  }
  function finishDismount() {
    S.mode = "idle"; S.modeT = 0;
    releaseRiderPose();
    var lp = call("getLocalPlayer");
    var ex = S.exitPos.x, ey = S.exitPos.y, ez = S.exitPos.z;
    if (typeof Game.teleportPlayer === "function") call("teleportPlayer", 0, ex, ey, ez, { hold: 300, yaw: S.yaw });
    else {
      call("holdPlayerPosition", 0, false);
      if (lp && lp.mesh) lp.mesh.position.set(ex, ey, ez);
    }
    call("holdPlayerPosition", 0, false);
    call("unlockPlayerAnim", 0);
    call("lockPlayer", 0, false);
    releaseCamera();
    call("setShared", DRV_KEY, "");
    if (PB("showHint", true)) call("subtitle", "");
    setBodyCollision(true);
    audioStop(false);
    M.roof.opacity = 1; M.roof.depthWrite = true;
    S.throttleOn = false;
    S.coast = Math.abs(S.v) > 0.05;
    S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y;
  }
  function requestToggle() {
    if (S.t - S.lastToggle < 0.45) return;
    if (S.mode === "idle") startMount();
    else if (S.mode === "riding") startDismount();
  }
  
  function forceExit() {
    if (S.mode === "idle") return;
    S.mode = "idle";
    releaseRiderPose();
    call("holdPlayerPosition", 0, false);
    call("unlockPlayerAnim", 0);
    call("lockPlayer", 0, false);
    releaseCamera();
    call("setShared", DRV_KEY, "");
    setBodyCollision(true);
  }

  var interactOK = false;
  if (typeof Game.registerInteractAction === "function") {
    try {
      Game.registerInteractAction(root, {
        id: "tuktuk_ride", label: "اضغط F للركوب", icon: "🛺", priority: 5,
        radius: PN("interactRadius", 3.4),
        onActivate: function () { requestToggle(); }
      });
      interactOK = true;
    } catch (e) { interactOK = false; }
  }

  
  
  
  function idleFrame(dt) {
    
    var f = down("KeyF");
    if (!interactOK && f && !S.fPrev) {
      var pp = playerWorldPos(_tmpB);
      if (pp) {
        var dx = pp.x - root.position.x, dz = pp.z - root.position.z;
        if (Math.sqrt(dx * dx + dz * dz) < PN("interactRadius", 3.4)) requestToggle();
      }
    }
    S.fPrev = f;
    if (S.coast) {
      physicsStep(dt, false, false, false, false, false);
      updateChassisVisuals(dt, 0);
      S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y;
      if (Math.abs(S.v) < 0.05) { S.v = 0; S.coast = false; }
    } else {
      measuredVisuals(dt);
    }
  }
  function mountFrame(dt) {
    var e = smooth(0, 1, S.modeT / MOUNT_TIME);
    S.steerIn = damp(S.steerIn, 0, 8, dt);
    physicsStep(dt, false, false, false, false, false);
    updateChassisVisuals(dt, 1);
    seatWorld(_seatW);
    var px = lerp(S.mountFrom.x, _seatW.x, e);
    var pz = lerp(S.mountFrom.z, _seatW.z, e);
    var py = lerp(S.mountFrom.y, _seatW.y, e) + Math.sin(PI * e) * 0.35;
    placePlayer(px, py, pz);
    if (e > 0.25) setPlayerYawSafe(riderYaw());
    if (e > 0.5) calibrateYaw();
    applyRiderPose(e);
    if (S.modeT >= MOUNT_TIME) {
      S.mode = "riding"; S.modeT = 0; S.lastToggle = S.t;
      if (PB("showHint", true)) {
        call("subtitle", "W/S قيادة · A/D توجيه · Space فرامل يد · H كلاكس · الماوس/الأسهم للكاميرا · F نزول");
        S.hintT = S.t + 6;
      }
    }
  }
  function ridingFrame(dt) {
    var fk = down("KeyF");
    if (fk && !S.fPrev) requestToggle();
    S.fPrev = fk;
    var hk = down("KeyH");
    hornSet(hk);
    S.hPrev = hk;
    if (S.mode !== "riding") return;
    physicsStep(dt, down("KeyW"), down("KeyS"), down("KeyA"), down("KeyD"), down("Space"));
    updateChassisVisuals(dt, 1);
    seatWorld(_seatW);
    placePlayer(_seatW.x, _seatW.y, _seatW.z);
    setPlayerYawSafe(riderYaw());
    if (S.modeT < 1.5) calibrateYaw();
    applyRiderPose(1);
    if (S.hintT > 0 && S.t > S.hintT) { S.hintT = -1; call("subtitle", ""); }
  }
  function dismountFrame(dt) {
    var e = smooth(0, 1, S.modeT / DISMOUNT_TIME);
    physicsStep(dt, false, false, false, false, true);
    updateChassisVisuals(dt, 1);
    seatWorld(_seatW);
    var px = lerp(_seatW.x, S.exitPos.x, e), pz = lerp(_seatW.z, S.exitPos.z, e);
    var py = lerp(_seatW.y, S.exitPos.y, e) + Math.sin(PI * e) * 0.3;
    placePlayer(px, py, pz);
    applyRiderPose(1 - e);
    if (S.modeT >= DISMOUNT_TIME) finishDismount();
  }

  
  
  
  
  var _col = new THREE.Color();
  function emitPuff() {
    var p = null, j;
    for (j = 0; j < puffs.length; j++) { if (puffs[j].life <= 0) { p = puffs[j]; break; } }
    if (!p) return;
    ensureMatrices();
    p.pos.copy(exhaustPos);
    chassis.localToWorld(p.pos);
    var bx = Math.sin(S.yaw), bz = Math.cos(S.yaw);
    p.vel.set(bx * (0.5 + Math.abs(S.v) * 0.04) + (Math.random() - 0.5) * 0.25, 0.35 + Math.random() * 0.25, bz * (0.5 + Math.abs(S.v) * 0.04) + (Math.random() - 0.5) * 0.25);
    p.max = 0.8 + Math.random() * 0.5; p.life = p.max;
    p.mesh.visible = true;
  }
  function updateSmoke(dt) {
    var j, p, anyAlive = false;
    if (S.engine === "run" && (S.mode === "riding" || S.mode === "mounting" || S.coast)) {
      S.smokeT -= dt;
      if (S.smokeT <= 0) { emitPuff(); S.smokeT = lerp(0.40, 0.10, clamp(S.thr, 0, 1)) * (S.rpm < 1600 ? 1.3 : 1); }
    }
    for (j = 0; j < puffs.length; j++) {
      p = puffs[j];
      if (p.life <= 0) continue;
      anyAlive = true;
      p.life -= dt;
      if (p.life <= 0) { p.mesh.visible = false; continue; }
      p.pos.x += p.vel.x * dt; p.pos.y += p.vel.y * dt; p.pos.z += p.vel.z * dt;
      var k2 = 1 - p.life / p.max;
      _tmpA.copy(p.pos);
      root.worldToLocal(_tmpA);
      p.mesh.position.copy(_tmpA);
      var sc = 0.5 + k2 * 2.2;
      p.mesh.scale.set(sc, sc, sc);
      p.mesh.material.opacity = (1 - k2) * (0.10 + 0.14 * S.thr);
    }
    return anyAlive;
  }
  function ambient(dt) {
    var active = (S.mode !== "idle");
    
    if (S.mode === "idle" && !S.coast && S.engine !== "off") { S.engine = "off"; S.rpm = 0; S.gear = 1; S.thr = 0; }
    var lights = PB("headlights", true) && active;
    if (headSpot) headSpot.intensity = lights ? 2.4 : 0;
    M.head.emissiveIntensity = lights ? 1.5 : 0.25;
    M.tail.emissiveIntensity = S.brakeOn ? 2.4 : (active ? 0.7 : 0.25);
    M.rev.emissiveIntensity = S.reverseOn ? 1.6 : 0.05;
    var blink = (Math.floor(S.t * 3) % 2 === 0) ? 1 : 0;
    M.sigL.emissiveIntensity = (active && S.steerIn > 0.45 && Math.abs(S.v) < 9) ? 1.8 * blink : 0.05;
    M.sigR.emissiveIntensity = (active && S.steerIn < -0.45 && Math.abs(S.v) < 9) ? 1.8 * blink : 0.05;
    updateSmoke(dt);
  }

  
  
  
  function netSync(dt) {
    if (S.mode === "idle" && Math.abs(S.v) < 0.05) return;
    S.syncT += dt;
    if (S.syncT >= 0.05) { S.syncT = 0; call("syncObject", root); }
  }
  function cleanup() {
    if (S.cleaned) return;
    S.cleaned = true;
    try { forceExit(); } catch (e) {}
    try { audioStop(true); } catch (e) {}
    try {
      if (typeof window !== "undefined" && window.removeEventListener) {
        window.removeEventListener("mousedown", onMouseDown, true);
        window.removeEventListener("mouseup", onMouseUp, true);
        window.removeEventListener("mousemove", onMouseMove, true);
        window.removeEventListener("wheel", onWheel, true);
      }
    } catch (e) {}
    try { root.position.copy(spawnPos); root.rotation.y = spawnYaw; } catch (e) {}
    try { root.userData.__tukCleanup = null; } catch (e) {}
  }
  root.userData.__tukCleanup = cleanup;

  function frame(dt) {
    S.frameNo++;
    refreshParams(dt, false);
    if (S.mode === "idle") idleFrame(dt);
    else if (S.mode === "mounting") mountFrame(dt);
    else if (S.mode === "riding") ridingFrame(dt);
    else if (S.mode === "dismounting") dismountFrame(dt);
    ambient(dt);
    if (S.mode !== "idle") { cameraFrame(dt); S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y; }
    netSync(dt);
    audioUpdate(dt);
  }

  refreshParams(0, true);
  S.paramT = 0;

  Game.onUpdate(function (dt) {
    if (!root.parent) { cleanup(); return false; }
    if (S.cleaned) return false;
    dt = (dt > 0) ? Math.min(dt, 0.05) : 0.016;
    S.t += dt;
    S.modeT += dt;
    try { frame(dt); } catch (err) {
      if (!S.errLogged) { S.errLogged = true; try { console.error("tuktuk:", err); } catch (e2) {} }
    }
  });
})(typeof Game !== "undefined" ? Game : null, typeof root !== "undefined" ? root : null);
