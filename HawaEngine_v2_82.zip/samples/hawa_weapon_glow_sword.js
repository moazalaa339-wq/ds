/**
 * سلاح متوهج — محاور مصحّحة لشخصية Hawa (suit/soldier/lowpoly)
 * سلسلة الذراع في المحرك: كتف → مرفق → رسغ على المحور المحلي -Y (نحو الأصابع)
 * لذلك النصل يُبنى على -Y عشان الطرف يمشي مع اتجاه اليد مش لورا.
 * يمين ماوس: إخراج/إخفاء | شمال ماوس: ضربة
 */
(function (Game, root) {
  "use strict";
  if (!Game || typeof Game.onUpdate !== "function") return;
  var THREE = Game.THREE;
  if (!THREE || !Game.scene) return;

  Game.defineParams([
    { key: "glowColor", label: "لون توهج اليد", type: "color", value: "#00e5ff" },
    { key: "glowIntensity", label: "شدة التوهج (0-1)", type: "number", value: 0.85, min: 0.1, max: 1, step: 0.05 },
    { key: "glowPulseSpeed", label: "سرعة نبض التوهج", type: "number", value: 3.0, min: 0.5, max: 8, step: 0.1 },
    { key: "weaponColor", label: "لون السلاح (المعدن)", type: "color", value: "#3a4a5a" },
    { key: "weaponEdgeColor", label: "لون حافة السلاح المضيئة", type: "color", value: "#00e5ff" },
    { key: "weaponHiltColor", label: "لون المقبض", type: "color", value: "#1a1a1a" },
    { key: "weaponGlowColor", label: "لون توهج السلاح", type: "color", value: "#00e5ff" },
    { key: "weaponScale", label: "حجم السلاح", type: "number", value: 1.0, min: 0.5, max: 2, step: 0.1 },
    { key: "weaponLength", label: "طول النصل (متر)", type: "number", value: 0.85, min: 0.3, max: 1.5, step: 0.05 },
    /* الرسغ: كف اليد تحت المفصل على -Y بحوالي 0.04–0.08 */
    { key: "gripPosX", label: "إزاحة السلاح X في اليد (متر)", type: "number", value: 0, min: -0.3, max: 0.3, step: 0.01 },
    { key: "gripPosY", label: "إزاحة السلاح Y في اليد (متر)", type: "number", value: -0.05, min: -0.3, max: 0.3, step: 0.01 },
    { key: "gripPosZ", label: "إزاحة السلاح Z في اليد (متر)", type: "number", value: 0.02, min: -0.3, max: 0.3, step: 0.01 },
    /* 0,0,0 لأن النصل مبني على -Y = اتجاه الأصابع — ممنوع -90 القديم */
    { key: "gripRotX", label: "دوران السلاح X (درجة)", type: "number", value: 0, min: -180, max: 180, step: 5 },
    { key: "gripRotY", label: "دوران السلاح Y (درجة)", type: "number", value: 0, min: -180, max: 180, step: 5 },
    { key: "gripRotZ", label: "دوران السلاح Z (درجة)", type: "number", value: 0, min: -180, max: 180, step: 5 },
    { key: "drawTime", label: "مدة إخراج السلاح (ثانية)", type: "number", value: 0.55, min: 0.2, max: 2, step: 0.05 },
    { key: "sheatheTime", label: "مدة إخفاء السلاح (ثانية)", type: "number", value: 0.45, min: 0.2, max: 2, step: 0.05 },
    { key: "idleSwaySpeed", label: "سرعة تمايل السلاح أثناء الوقوف", type: "number", value: 1.5, min: 0.5, max: 4, step: 0.1 },
    { key: "idleSwayAmount", label: "مقدار تمايل السلاح", type: "number", value: 0.02, min: 0.005, max: 0.15, step: 0.005 },
    { key: "readyArmX", label: "رفع الذراع وضع الاستعداد", type: "number", value: -1.15, min: -2.5, max: 0.5, step: 0.05 },
    { key: "readyForeX", label: "ثني الساعد وضع الاستعداد", type: "number", value: -0.55, min: -2, max: 0.5, step: 0.05 },
    { key: "swingSpeed", label: "سرعة ضربة السلاح", type: "number", value: 1.15, min: 0.5, max: 2, step: 0.1 },
    { key: "swingCooldown", label: "تبريد بين الضربات (ثانية)", type: "number", value: 0.35, min: 0.1, max: 2, step: 0.05 },
    { key: "damage", label: "قوة الضربة", type: "number", value: 15, min: 5, max: 100, step: 1 },
    { key: "reach", label: "مدى الضربة (متر)", type: "number", value: 2.0, min: 0.5, max: 4, step: 0.1 },
    { key: "particleCount", label: "عدد جزيئات التوهج", type: "number", value: 12, min: 0, max: 40, step: 1 },
    { key: "particleSize", label: "حجم الجزيئات (متر)", type: "number", value: 0.03, min: 0.005, max: 0.1, step: 0.005 },
    { key: "particleSpeed", label: "سرعة الجزيئات (م/ث)", type: "number", value: 0.4, min: 0.05, max: 2, step: 0.05 },
    { key: "trailEnabled", label: "تفعيل أثر الضربة", type: "boolean", value: true },
    { key: "trailColor", label: "لون أثر الضربة", type: "color", value: "#00e5ff" },
    { key: "trailLifetime", label: "مدة بقاء الأثر (ثانية)", type: "number", value: 0.35, min: 0.1, max: 1, step: 0.05 },
    { key: "soundEnabled", label: "تفعيل الأصوات", type: "boolean", value: true },
    { key: "soundVolume", label: "مستوى الصوت (0-1)", type: "number", value: 0.4, min: 0, max: 1, step: 0.05 },
    { key: "hitSound", label: "صوت ضربة السلاح", type: "audio", value: "" },
    { key: "drawSound", label: "صوت إخراج السلاح", type: "audio", value: "" },
    { key: "sheatheSound", label: "صوت إخفاء السلاح", type: "audio", value: "" },
    { key: "holdMusic", label: "موسيقى أثناء الإمساك بالسيف", type: "audio", value: "" },
    { key: "holdMusicVolume", label: "مستوى موسيقى السيف (0-1)", type: "number", value: 0.35, min: 0, max: 1, step: 0.05 },
    { key: "holdMusicLoop", label: "تكرار موسيقى السيف", type: "boolean", value: true },
    { key: "showDebugAxes", label: "إظهار محاور اليد (للتشخيص)", type: "boolean", value: false }
  ]);

  function PN(k, d) { var v = Game.params ? Game.params[k] : undefined; v = Number(v); return isFinite(v) ? v : d; }
  function PB(k, d) { var v = Game.params ? Game.params[k] : undefined; if (typeof v === "string") return v === "true" || v === "1"; return v !== undefined && v !== null ? !!v : d; }
  function PS(k, d) { var v = Game.params ? Game.params[k] : undefined; return (v === undefined || v === null || v === "") ? d : String(v); }
  function DEG2RAD(d) { return d * Math.PI / 180; }
  function playSfx(key) {
    if (!PB("soundEnabled", true)) return;
    var url = PS(key, "");
    if (!url) return;
    if (typeof Game.playSound === "function") {
      try { Game.playSound(url, { volume: PN("soundVolume", 0.4) }); } catch (e) {}
    } else {
      try {
        var a = new Audio(url);
        a.volume = Math.max(0, Math.min(1, PN("soundVolume", 0.4)));
        a.play().catch(function () {});
      } catch (e) {}
    }
  }

  var holdMusicEl = null;
  var holdMusicUrl = "";

  function resolveAudioUrl(ref) {
    if (!ref) return "";
    var s = String(ref);
    if (/^https?:\/\//i.test(s) || s.indexOf("blob:") === 0 || s.indexOf("data:") === 0) return s;
    if (typeof Game.resolveMediaUrl === "function") {
      try { var u = Game.resolveMediaUrl(s); if (u) return u; } catch (e) {}
    }
    if (typeof Game.getMediaUrl === "function") {
      try { var u2 = Game.getMediaUrl(s); if (u2) return u2; } catch (e) {}
    }
    // مراجع ملفات المحرك غالباً media:... أو اسم ملف
    if (s.indexOf("media:") === 0) return s.slice(6);
    return s;
  }

  function stopHoldMusic() {
    if (holdMusicEl) {
      try { holdMusicEl.pause(); holdMusicEl.currentTime = 0; } catch (e) {}
      try { holdMusicEl.src = ""; } catch (e) {}
      holdMusicEl = null;
    }
    holdMusicUrl = "";
  }

  function startHoldMusic() {
    if (!PB("soundEnabled", true)) { stopHoldMusic(); return; }
    var ref = PS("holdMusic", "");
    if (!ref) { stopHoldMusic(); return; }
    var url = resolveAudioUrl(ref);
    if (!url) { stopHoldMusic(); return; }
    var vol = Math.max(0, Math.min(1, PN("holdMusicVolume", 0.35)));
    var loop = PB("holdMusicLoop", true);
    // لو نفس الملف شغال خلاص — حدّث الصوت فقط
    if (holdMusicEl && holdMusicUrl === url) {
      try {
        holdMusicEl.volume = vol;
        holdMusicEl.loop = loop;
        if (holdMusicEl.paused) holdMusicEl.play().catch(function () {});
      } catch (e) {}
      return;
    }
    stopHoldMusic();
    try {
      var a = new Audio();
      a.loop = loop;
      a.volume = vol;
      a.preload = "auto";
      a.src = url;
      a.play().catch(function () {});
      holdMusicEl = a;
      holdMusicUrl = url;
    } catch (e) {
      holdMusicEl = null;
      holdMusicUrl = "";
    }
  }

  function updateHoldMusic() {
    if (state.weaponDrawn && !state.sheathing) startHoldMusic();
    else stopHoldMusic();
    if (holdMusicEl) {
      try {
        holdMusicEl.volume = Math.max(0, Math.min(1, PN("holdMusicVolume", 0.35)));
        holdMusicEl.loop = PB("holdMusicLoop", true);
        if (!PB("soundEnabled", true)) {
          holdMusicEl.pause();
        } else if (state.weaponDrawn && holdMusicEl.paused) {
          holdMusicEl.play().catch(function () {});
        }
      } catch (e) {}
    }
  }

  var state = {
    weaponDrawn: false, drawing: false, drawProgress: 0,
    sheathing: false, sheatheProgress: 0,
    isSwinging: false, swingProgress: 0, swingCooldown: 0,
    glowPulse: 0, idleTime: 0,
    handGlowMats: [], handGlowSaved: [], handGlowApplied: false, handGlowLight: null,
    weaponGroup: null, weaponEdgeMesh: null, weaponGlowMesh: null, weaponLight: null,
    weaponTipLocal: null, weaponTrail: [], particles: [], particleGeo: null, particleMat: null,
    rightHandBone: null, debugAxes: null, attachedParent: null, failCount: 0,
    lastGripKey: ""
  };

  /**
   * بناء السلاح: النصل على -Y (اتجاه الأصابع في rig الشخصية)
   * المقبض عند y=0 = نقطة القبض عند الرسغ/الكف
   */
  function buildWeapon() {
    var g = new THREE.Group();
    var sc = PN("weaponScale", 1.0);
    var len = PN("weaponLength", 0.85) * sc;
    var wC = PS("weaponColor", "#3a4a5a");
    var eC = PS("weaponEdgeColor", "#00e5ff");
    var hC = PS("weaponHiltColor", "#1a1a1a");
    var gC = PS("weaponGlowColor", "#00e5ff");

    // المقبض — مركزه عند 0 (نقطة القبض)
    var hilt = new THREE.Mesh(
      new THREE.CylinderGeometry(0.025 * sc, 0.028 * sc, 0.16 * sc, 8),
      new THREE.MeshStandardMaterial({ color: hC, metalness: 0.6, roughness: 0.4 })
    );
    hilt.position.y = 0;
    g.add(hilt);

    // حاجز اليد — جهة الطرف (نحو -Y)
    var guard = new THREE.Mesh(
      new THREE.BoxGeometry(0.14 * sc, 0.02 * sc, 0.04 * sc),
      new THREE.MeshStandardMaterial({ color: wC, metalness: 0.85, roughness: 0.25 })
    );
    guard.position.y = -0.09 * sc;
    g.add(guard);

    // النصل يمتد على -Y من الحاجز
    var blade = new THREE.Mesh(
      new THREE.BoxGeometry(0.055 * sc, len, 0.012 * sc),
      new THREE.MeshStandardMaterial({ color: wC, metalness: 0.9, roughness: 0.2 })
    );
    blade.position.y = -0.09 * sc - len / 2;
    g.add(blade);

    var edgeGeo = new THREE.BoxGeometry(0.006 * sc, len, 0.014 * sc);
    var edgeMat = new THREE.MeshStandardMaterial({
      color: eC, emissive: eC, emissiveIntensity: 1.2, metalness: 0.5, roughness: 0.3
    });
    var edgeR = new THREE.Mesh(edgeGeo, edgeMat);
    edgeR.position.set(0.0275 * sc, -0.09 * sc - len / 2, 0);
    g.add(edgeR);
    var edgeL = new THREE.Mesh(edgeGeo, edgeMat.clone());
    edgeL.position.set(-0.0275 * sc, -0.09 * sc - len / 2, 0);
    g.add(edgeL);

    // سن — طرف النصل (أبعد نقطة على -Y)
    var tip = new THREE.Mesh(
      new THREE.ConeGeometry(0.032 * sc, 0.1 * sc, 4),
      new THREE.MeshStandardMaterial({ color: wC, metalness: 0.9, roughness: 0.2 })
    );
    tip.position.y = -0.09 * sc - len - 0.04 * sc;
    tip.rotation.x = Math.PI; // القاعدة نحو المقبض، الطرف للخارج
    tip.rotation.y = Math.PI / 4;
    g.add(tip);

    var glow = new THREE.Mesh(
      new THREE.BoxGeometry(0.065 * sc, len * 0.9, 0.016 * sc),
      new THREE.MeshBasicMaterial({ color: gC, transparent: true, opacity: 0.25 })
    );
    glow.position.y = -0.09 * sc - len / 2;
    g.add(glow);

    var light = new THREE.PointLight(new THREE.Color(gC).getHex(), 1.5, 3, 2);
    light.position.y = -0.09 * sc - len * 0.55;
    g.add(light);

    var tipLocal = new THREE.Object3D();
    tipLocal.position.y = -0.09 * sc - len - 0.05 * sc;
    g.add(tipLocal);

    state.weaponTipLocal = tipLocal;
    state.weaponGlowMesh = glow;
    state.weaponEdgeMesh = edgeMat;
    state.weaponLight = light;
    return g;
  }

  function applyHandGlow() {
    if (state.handGlowApplied) return;
    var players = Game.getAllPlayers ? Game.getAllPlayers() : [];
    var me = null;
    for (var i = 0; i < players.length; i++) if (players[i].local) { me = players[i]; break; }
    if (!me) me = Game.getLocalPlayer ? Game.getLocalPlayer() : null;
    if (!me || !me.mesh) return;
    var gC = PS("glowColor", "#00e5ff");
    var intensity = PN("glowIntensity", 0.85);
    var armBone = null;
    try {
      if (typeof Game.getBone === "function") {
        armBone = Game.getBone(0, "rForearm") || Game.getBone(0, "rightForearm");
      }
    } catch (e) {}
    if (!armBone && me.mesh) {
      me.mesh.traverse(function (c) {
        if (armBone) return;
        var n = (c.name || "").toLowerCase();
        if (n.indexOf("forearm") >= 0 && (n.indexOf("r") === 0 || n.indexOf("right") >= 0)) armBone = c;
      });
    }
    if (!armBone) return;
    var targetMeshes = [];
    armBone.traverse(function (c) {
      if (c.isMesh && c.material) targetMeshes.push(c);
    });
    state.handGlowMats = [];
    state.handGlowSaved = [];
    for (var j = 0; j < targetMeshes.length; j++) {
      var m = targetMeshes[j];
      var arr = Array.isArray(m.material) ? m.material : [m.material];
      var newArr = [];
      for (var k = 0; k < arr.length; k++) {
        var cloned = arr[k].clone();
        state.handGlowSaved.push({ mat: arr[k], mesh: m, idx: k });
        cloned.emissive = new THREE.Color(gC);
        cloned.emissiveIntensity = intensity;
        newArr.push(cloned);
        state.handGlowMats.push(cloned);
      }
      m.material = Array.isArray(m.material) ? newArr : newArr[0];
    }
    var handLight = new THREE.PointLight(new THREE.Color(gC).getHex(), 0.8, 1.5, 2);
    try { armBone.add(handLight); } catch (e) {}
    state.handGlowLight = handLight;
    state.handGlowApplied = true;
  }

  function removeHandGlow() {
    if (!state.handGlowApplied) return;
    for (var i = 0; i < state.handGlowSaved.length; i++) {
      var s = state.handGlowSaved[i];
      try {
        var arr = Array.isArray(s.mesh.material) ? s.mesh.material : null;
        if (arr) arr[s.idx] = s.mat;
        else s.mesh.material = s.mat;
      } catch (e) {}
    }
    state.handGlowSaved = [];
    state.handGlowMats = [];
    if (state.handGlowLight && state.handGlowLight.parent) {
      try { state.handGlowLight.parent.remove(state.handGlowLight); } catch (e) {}
    }
    state.handGlowLight = null;
    state.handGlowApplied = false;
  }

  /** الرسغ (wr) أفضل من الساعد — نفس سلسلة -Y */
  function findRightHand() {
    if (state.rightHandBone && state.rightHandBone.parent) return state.rightHandBone;
    state.rightHandBone = null;
    var players = Game.getAllPlayers ? Game.getAllPlayers() : [];
    var me = null;
    for (var i = 0; i < players.length; i++) if (players[i].local) { me = players[i]; break; }
    if (!me) me = Game.getLocalPlayer ? Game.getLocalPlayer() : null;
    if (!me || !me.mesh) return null;

    var boneNames = ["rHand", "rightHand", "hand_r", "RightHand", "right_hand", "r_hand", "wr", "wrist", "rWrist", "rightWrist"];
    if (typeof Game.getBone === "function") {
      for (var b = 0; b < boneNames.length; b++) {
        try {
          var bn = Game.getBone(0, boneNames[b]);
          if (bn && bn.isObject3D) { state.rightHandBone = bn; return bn; }
        } catch (e) {}
      }
    }
    // من الـ rig: arms.R.wr
    try {
      if (me.rig && me.rig.AR && me.rig.AR.wr) {
        state.rightHandBone = me.rig.AR.wr;
        return state.rightHandBone;
      }
      if (me.rig && me.rig.arms && me.rig.arms.R && me.rig.arms.R.wr) {
        state.rightHandBone = me.rig.arms.R.wr;
        return state.rightHandBone;
      }
    } catch (e) {}

    var found = null;
    var priorities = [
      function (n) { return n === "wr" || n.indexOf("wrist") >= 0 || n.indexOf("rhand") >= 0 || n.indexOf("righthand") >= 0 || n.indexOf("hand_r") >= 0; },
      function (n) { return n.indexOf("rforearm") >= 0 || n.indexOf("rightforearm") >= 0 || n.indexOf("r_forearm") >= 0; }
    ];
    for (var p = 0; p < priorities.length && !found; p++) {
      var pred = priorities[p];
      me.mesh.traverse(function (c) {
        if (found) return;
        var n = (c.name || "").toLowerCase().replace(/[\s\-]/g, "");
        if (pred(n) && c.isObject3D) found = c;
      });
    }
    // fallback: أبعد مفصل على سلسلة الذراع اليمين (الرسغ)
    if (!found && me.mesh) {
      var candidates = [];
      me.mesh.traverse(function (c) {
        if (!c.isObject3D) return;
        var n = (c.name || "").toLowerCase();
        if (n.indexOf("arm") >= 0 || n.indexOf("hand") >= 0 || n.indexOf("fore") >= 0 || n.indexOf("wr") >= 0) {
          if (n.indexOf("l") === 0 || n.indexOf("left") >= 0) return;
          candidates.push(c);
        }
      });
      // اختر الأعمق (أكثر children depth) غالباً الرسغ
      if (candidates.length) {
        candidates.sort(function (a, b) {
          var da = 0, db = 0, x = a; while (x.parent) { da++; x = x.parent; }
          x = b; while (x.parent) { db++; x = x.parent; }
          return db - da;
        });
        found = candidates[0];
      }
    }
    state.rightHandBone = found;
    return found;
  }

  function applyGripTransform(weapon) {
    weapon.position.set(PN("gripPosX", 0), PN("gripPosY", -0.05), PN("gripPosZ", 0.02));
    weapon.rotation.set(
      DEG2RAD(PN("gripRotX", 0)),
      DEG2RAD(PN("gripRotY", 0)),
      DEG2RAD(PN("gripRotZ", 0))
    );
  }

  function attachWeaponToHand(weapon) {
    var hand = findRightHand();
    if (!hand) return false;
    if (weapon.parent) weapon.parent.remove(weapon);
    hand.add(weapon);
    state.attachedParent = hand;
    applyGripTransform(weapon);
    return true;
  }

  function detachWeapon() {
    if (state.weaponGroup && state.weaponGroup.parent) {
      state.weaponGroup.parent.remove(state.weaponGroup);
    }
    state.attachedParent = null;
  }

  function initParticles() {
    var count = Math.floor(PN("particleCount", 12));
    if (count <= 0) return;
    if (!state.particleGeo) state.particleGeo = new THREE.SphereGeometry(PN("particleSize", 0.03), 6, 4);
    if (!state.particleMat) state.particleMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(PS("glowColor", "#00e5ff")), transparent: true, opacity: 0.7
    });
    state.particles = [];
    for (var i = 0; i < count; i++) {
      var p = new THREE.Mesh(state.particleGeo, state.particleMat);
      p.userData = {
        phase: Math.random() * Math.PI * 2,
        speed: 0.5 + Math.random() * 0.5,
        offset: new THREE.Vector3((Math.random() - 0.5) * 0.15, -(Math.random() * 0.2), (Math.random() - 0.5) * 0.15)
      };
      p.visible = false;
      state.particles.push(p);
    }
  }

  function updateParticles(dt, anchor) {
    if (!anchor || state.particles.length === 0) return;
    var t = elapsed;
    var pSpeed = PN("particleSpeed", 0.4);
    for (var i = 0; i < state.particles.length; i++) {
      var p = state.particles[i];
      if (!p.parent && anchor) { try { anchor.add(p); } catch (e) {} }
      var ph = p.userData.phase;
      var sp = p.userData.speed * pSpeed;
      p.position.set(
        p.userData.offset.x + Math.sin(t * sp + ph) * 0.05,
        p.userData.offset.y - ((t * sp * 0.4 + ph) % 1) * 0.2,
        p.userData.offset.z + Math.cos(t * sp + ph * 1.3) * 0.05
      );
      p.visible = state.weaponDrawn;
    }
  }

  function spawnTrailPoint(worldPos) {
    if (!PB("trailEnabled", true)) return;
    var gC = PS("trailColor", "#00e5ff");
    var m = new THREE.Mesh(
      new THREE.SphereGeometry(0.04, 4, 3),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(gC), transparent: true, opacity: 0.7 })
    );
    m.position.copy(worldPos);
    m.userData.life = PN("trailLifetime", 0.35);
    m.userData.maxLife = m.userData.life;
    Game.scene.add(m);
    state.weaponTrail.push(m);
  }

  function updateTrail(dt) {
    for (var i = state.weaponTrail.length - 1; i >= 0; i--) {
      var m = state.weaponTrail[i];
      m.userData.life -= dt;
      var a = m.userData.life / m.userData.maxLife;
      if (a <= 0) {
        if (m.parent) m.parent.remove(m);
        if (m.geometry) m.geometry.dispose();
        if (m.material) m.material.dispose();
        state.weaponTrail.splice(i, 1);
        continue;
      }
      m.material.opacity = a * 0.7;
      m.scale.setScalar(0.5 + a * 0.5);
    }
  }

  function doSwing() {
    if (!state.weaponDrawn || state.isSwinging) return;
    if (state.swingCooldown > 0) return;
    state.isSwinging = true;
    state.swingProgress = 0;
    state.swingCooldown = PN("swingCooldown", 0.35);
    playSfx("hitSound");
    var players = Game.getAllPlayers ? Game.getAllPlayers() : [];
    var me = null;
    for (var i = 0; i < players.length; i++) if (players[i].local) { me = players[i]; break; }
    if (me && me.position) {
      var dmg = PN("damage", 15);
      var reach = PN("reach", 2.0);
      var fwd = (typeof Game.getPlayerForward === "function") ? Game.getPlayerForward(0) : null;
      for (var j = 0; j < players.length; j++) {
        var p = players[j];
        if (p.local || !p.position) continue;
        var dx = p.position.x - me.position.x;
        var dz = p.position.z - me.position.z;
        var dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < reach) {
          var hit = true;
          if (fwd && dist > 0.1) {
            var dot = (dx * fwd.x + dz * fwd.z) / dist;
            hit = dot > 0.2;
          }
          if (hit && typeof Game.damagePlayer === "function") {
            Game.damagePlayer(p.slot !== undefined ? p.slot : p.id, dmg);
          }
        }
      }
    }
  }

  function drawWeapon() {
    if (state.weaponDrawn || state.drawing) return;
    state.drawing = true;
    state.drawProgress = 0;
    applyHandGlow();
    if (!state.weaponGroup) {
      state.weaponGroup = buildWeapon();
      initParticles();
    }
    if (!attachWeaponToHand(state.weaponGroup)) {
      state.failCount++;
      if (state.failCount > 30 && typeof Game.subtitle === "function") {
        Game.subtitle("⚠ لم يتم العثور على يد اللاعب — فعّل showDebugAxes");
      }
    }
    state.weaponGroup.scale.setScalar(0.01);
    playSfx("drawSound");
  }

  function sheatheWeapon() {
    if (!state.weaponDrawn || state.sheathing) return;
    state.sheathing = true;
    state.sheatheProgress = 0;
    playSfx("sheatheSound");
  }

  /** وضع الاستعداد: ذراع مرفوعة قدام — سالب X = قدام في المحرك */
  function applyReadyPose(amount) {
    var a = Math.max(0, Math.min(1, amount));
    var armX = PN("readyArmX", -1.15) * a;
    var foreX = PN("readyForeX", -0.55) * a;
    if (typeof Game.setPlayerLimb === "function") {
      try {
        Game.setPlayerLimb(0, "rArm", armX, 0.15 * a, 0.1 * a, { lock: true });
        Game.setPlayerLimb(0, "rForearm", foreX, 0, 0, { lock: true });
        Game.setPlayerLimb(0, "spine", -0.08 * a, 0, 0, { lock: true });
      } catch (err) {}
    }
  }

  function applyDrawAnim(progress) {
    var e = progress * progress * (3 - 2 * progress);
    applyReadyPose(e);
  }

  function applySheatheAnim(progress) {
    applyReadyPose(1 - progress);
  }

  function releaseLimbs() {
    if (typeof Game.setPlayerLimb === "function") {
      try {
        Game.setPlayerLimb(0, "rArm", 0, 0, 0, { lock: false });
        Game.setPlayerLimb(0, "rForearm", 0, 0, 0, { lock: false });
        Game.setPlayerLimb(0, "spine", 0, 0, 0, { lock: false });
      } catch (e) {}
    }
  }

  /**
   * ضربة: من وضع الاستعداد → رفع للخلف → قطع للأمام (سالب X = قدام)
   * الطرف على -Y يمشي مع اتجاه الساعد في القوس
   */
  function applySwingAnim(progress) {
    var t = progress;
    var armR, armY, foreR, spineR;
    if (t < 0.25) {
      var p = t / 0.25;
      armR = PN("readyArmX", -1.15) - 0.7 * p;
      armY = 0.15 - 0.55 * p;
      foreR = PN("readyForeX", -0.55) - 0.5 * p;
      spineR = -0.08 - 0.12 * p;
    } else if (t < 0.55) {
      var p2 = (t - 0.25) / 0.3;
      armR = -1.85 + 2.4 * p2;
      armY = -0.4 + 1.1 * p2;
      foreR = -1.05 + 1.6 * p2;
      spineR = -0.2 + 0.4 * p2;
    } else {
      var p3 = (t - 0.55) / 0.45;
      armR = 0.55 + (PN("readyArmX", -1.15) - 0.55) * p3;
      armY = 0.7 + (0.15 - 0.7) * p3;
      foreR = 0.55 + (PN("readyForeX", -0.55) - 0.55) * p3;
      spineR = 0.2 + (-0.08 - 0.2) * p3;
    }
    if (typeof Game.setPlayerLimb === "function") {
      try {
        Game.setPlayerLimb(0, "rArm", armR, armY, 0.1, { lock: true });
        Game.setPlayerLimb(0, "rForearm", foreR, 0, 0, { lock: true });
        Game.setPlayerLimb(0, "spine", spineR, 0, 0, { lock: true });
      } catch (e) {}
    }
  }

  var canvasEl = null;
  function getCanvas() {
    if (canvasEl && canvasEl.parentNode) return canvasEl;
    if (typeof document === "undefined") return null;
    canvasEl = document.querySelector("canvas");
    return canvasEl;
  }
  function onMouseDown(e) {
    if (e.button === 2) {
      if (state.weaponDrawn && !state.isSwinging && !state.sheathing) sheatheWeapon();
      else if (!state.weaponDrawn && !state.drawing) drawWeapon();
    } else if (e.button === 0) {
      if (state.weaponDrawn && !state.sheathing) doSwing();
    }
  }
  function onContextMenu(e) { e.preventDefault(); return false; }
  var listenersAttached = false;
  function attachListeners() {
    if (listenersAttached) return;
    var c = getCanvas();
    if (!c) return;
    c.addEventListener("mousedown", onMouseDown);
    c.addEventListener("contextmenu", onContextMenu);
    listenersAttached = true;
  }
  function detachListeners() {
    var c = getCanvas();
    if (!c) return;
    c.removeEventListener("mousedown", onMouseDown);
    c.removeEventListener("contextmenu", onContextMenu);
    listenersAttached = false;
  }

  function toggleDebugAxes(on) {
    if (on && !state.debugAxes) {
      var hand = findRightHand();
      if (hand) {
        state.debugAxes = new THREE.AxesHelper(0.35);
        hand.add(state.debugAxes);
      }
    } else if (!on && state.debugAxes) {
      if (state.debugAxes.parent) state.debugAxes.parent.remove(state.debugAxes);
      state.debugAxes = null;
    }
  }

  var elapsed = 0;
  var lastDebug = false;

  Game.onUpdate(function (dt) {
    if (!dt || dt > 0.1) dt = 0.016;
    elapsed += dt;
    attachListeners();
    updateHoldMusic();

    var debugNow = PB("showDebugAxes", false);
    if (debugNow !== lastDebug) {
      toggleDebugAxes(debugNow);
      lastDebug = debugNow;
    }

    if (state.weaponGroup && state.weaponDrawn && !state.isSwinging) {
      var gk = [PN("gripPosX",0),PN("gripPosY",-0.05),PN("gripPosZ",0.02),PN("gripRotX",0),PN("gripRotY",0),PN("gripRotZ",0)].join(",");
      if (gk !== state.lastGripKey) {
        state.lastGripKey = gk;
        applyGripTransform(state.weaponGroup);
      }
    }

    state.glowPulse = 0.5 + Math.sin(elapsed * PN("glowPulseSpeed", 3.0)) * 0.5;

    if (state.drawing) {
      state.drawProgress += dt / PN("drawTime", 0.55);
      if (state.drawProgress >= 1) {
        state.drawProgress = 1;
        state.drawing = false;
        state.weaponDrawn = true;
      }
      if (state.weaponGroup) state.weaponGroup.scale.setScalar(0.01 + state.drawProgress * 0.99);
      applyDrawAnim(state.drawProgress);
    }

    if (state.sheathing) {
      state.sheatheProgress += dt / PN("sheatheTime", 0.45);
      if (state.sheatheProgress >= 1) {
        state.sheatheProgress = 1;
        state.sheathing = false;
        state.weaponDrawn = false;
        detachWeapon();
        removeHandGlow();
        releaseLimbs();
      } else {
        if (state.weaponGroup) state.weaponGroup.scale.setScalar(1 - state.sheatheProgress);
        applySheatheAnim(state.sheatheProgress);
      }
    }

    // وضع الاستعداد المستمر بعد الإخراج
    if (state.weaponDrawn && !state.isSwinging && !state.drawing && !state.sheathing) {
      applyReadyPose(1);
      if (state.weaponGroup) {
        state.idleTime += dt;
        var sway = PN("idleSwayAmount", 0.02);
        var swaySpd = PN("idleSwaySpeed", 1.5);
        var baseRotX = DEG2RAD(PN("gripRotX", 0));
        var baseRotY = DEG2RAD(PN("gripRotY", 0));
        var baseRotZ = DEG2RAD(PN("gripRotZ", 0));
        state.weaponGroup.rotation.x = baseRotX + Math.sin(state.idleTime * swaySpd * 0.7) * sway;
        state.weaponGroup.rotation.z = baseRotZ + Math.sin(state.idleTime * swaySpd) * sway;
        state.weaponGroup.rotation.y = baseRotY;
      }
    }

    if (state.isSwinging) {
      state.swingProgress += dt * PN("swingSpeed", 1.15) / 0.85;
      if (state.swingProgress >= 1) {
        state.swingProgress = 1;
        state.isSwinging = false;
        applyReadyPose(1);
      } else {
        applySwingAnim(state.swingProgress);
      }
      if (state.swingProgress > 0.22 && state.swingProgress < 0.72 && state.weaponTipLocal) {
        try {
          var tipWorld = new THREE.Vector3();
          state.weaponTipLocal.getWorldPosition(tipWorld);
          spawnTrailPoint(tipWorld);
        } catch (e) {}
      }
    }

    if (state.swingCooldown > 0) state.swingCooldown -= dt;

    if (state.handGlowApplied) {
      var inten = PN("glowIntensity", 0.85);
      for (var i = 0; i < state.handGlowMats.length; i++) {
        state.handGlowMats[i].emissiveIntensity = inten * (0.5 + state.glowPulse * 0.5);
      }
      if (state.handGlowLight) state.handGlowLight.intensity = 0.3 + state.glowPulse * 0.6;
    }
    if (state.weaponDrawn && state.weaponEdgeMesh) {
      state.weaponEdgeMesh.emissiveIntensity = 0.8 + state.glowPulse * 0.8;
    }
    if (state.weaponGlowMesh) {
      state.weaponGlowMesh.material.opacity = 0.15 + state.glowPulse * 0.2;
    }
    if (state.weaponLight && state.weaponDrawn) {
      state.weaponLight.intensity = 1.0 + state.glowPulse * 1.0;
    }
    if (state.weaponDrawn && state.weaponGroup && state.particles.length > 0) {
      updateParticles(dt, state.weaponGroup);
    } else if (state.particles.length > 0) {
      for (var k = 0; k < state.particles.length; k++) state.particles[k].visible = false;
    }
    updateTrail(dt);
  });

  if (root && root.userData) {
    root.userData.__weaponCleanup = function () {
      detachListeners();
      stopHoldMusic();
      removeHandGlow();
      releaseLimbs();
      detachWeapon();
      if (state.debugAxes && state.debugAxes.parent) {
        try { state.debugAxes.parent.remove(state.debugAxes); } catch (e) {}
      }
      state.debugAxes = null;
      if (state.weaponGroup) {
        state.weaponGroup.traverse(function (o) {
          if (o.geometry) o.geometry.dispose();
          if (o.material) {
            if (Array.isArray(o.material)) o.material.forEach(function (m) { m.dispose(); });
            else o.material.dispose();
          }
        });
        state.weaponGroup = null;
      }
      for (var i = 0; i < state.weaponTrail.length; i++) {
        var m = state.weaponTrail[i];
        if (m.parent) m.parent.remove(m);
        if (m.geometry) m.geometry.dispose();
        if (m.material) m.material.dispose();
      }
      state.weaponTrail = [];
      if (state.particleGeo) state.particleGeo.dispose();
      if (state.particleMat) state.particleMat.dispose();
      state.particles = [];
    };
  }
})(typeof Game !== "undefined" ? Game : null, typeof root !== "undefined" ? root : null);
