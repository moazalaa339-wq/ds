(function (Game, root) {
  "use strict";
  if (!Game || !root) return;
  var THREE = Game.THREE || (typeof window !== "undefined" ? window.THREE : null);
  if (!THREE) return;
  if (typeof Game.onUpdate !== "function") return;

  var OBJECT_NAME = "موتسيكل_ريس";
  try { root.userData.instanceName = OBJECT_NAME; } catch (e) {}
  root.userData.forceMeshCollision = true;
  root.userData.customDrive = true;
  try { if (typeof root.userData.__bikeCleanup === "function") root.userData.__bikeCleanup(); } catch (e) {}

  
  
  
  if (typeof Game.defineParams === "function") {
    Game.defineParams([
      { key: "bodyColor", label: "لون الهيكل الأساسي", type: "color", value: "#c1121f" },
      { key: "accentColor", label: "لون الخطوط والتفاصيل", type: "color", value: "#101114" },
      { key: "goldColor", label: "لون الجنوط والمقدمة", type: "color", value: "#d9a72b" },
      { key: "glowColor", label: "لون إضاءة الأرض", type: "color", value: "#19b5ff" },
      { key: "glowOn", label: "إضاءة نيون تحت الموتسيكل", type: "boolean", value: true },
      { key: "raceNumber", label: "رقم السباق", type: "text", value: "46" },
      { key: "brandText", label: "اسم الفريق على الجنب", type: "text", value: "TURBO" },

      { key: "maxSpeed", label: "السرعة القصوى (م/ث)", type: "number", value: 62, min: 20, max: 100, step: 1 },
      { key: "power", label: "قوة المحرك (م²/ث³)", type: "number", value: 210, min: 60, max: 500, step: 5 },
      { key: "traction", label: "أقصى تسارع بالتماسك (م/ث²)", type: "number", value: 9, min: 3, max: 16, step: 0.5 },
      { key: "brakePower", label: "قوة الفرامل (م/ث²)", type: "number", value: 16, min: 5, max: 30, step: 0.5 },
      { key: "engineBrake", label: "كبح المحرك (م/ث²)", type: "number", value: 3, min: 0, max: 8, step: 0.5 },
      { key: "redlineRpm", label: "أقصى لفات المحرك (لفة/د)", type: "number", value: 13000, min: 8000, max: 18000, step: 500 },
      { key: "maxLeanDeg", label: "أقصى ميل في المنعطف (درجة)", type: "number", value: 52, min: 20, max: 65, step: 1 },
      { key: "leanResponse", label: "سرعة الميل (1/ث)", type: "number", value: 5.5, min: 1.5, max: 14, step: 0.5 },
      { key: "steerMaxDeg", label: "أقصى زاوية للمقود في السرعة البطيئة (درجة)", type: "number", value: 26, min: 10, max: 40, step: 1 },
      { key: "wheelieAmount", label: "قوة رفع العجلة الأمامية (0-1)", type: "number", value: 0.6, min: 0, max: 1, step: 0.05 },
      { key: "nitroBoost", label: "زيادة القوة مع النيترو (نسبة)", type: "number", value: 0.45, min: 0, max: 1.2, step: 0.05 },
      { key: "nitroDrain", label: "استهلاك النيترو (%/ث)", type: "number", value: 28, min: 5, max: 80, step: 1 },
      { key: "nitroRegen", label: "شحن النيترو (%/ث)", type: "number", value: 7, min: 0, max: 30, step: 0.5 },
      { key: "collision", label: "التصادم مع الحوائط", type: "boolean", value: true },
      { key: "sparks", label: "شرار الدعسة عند الميل الشديد", type: "boolean", value: true },

      { key: "camDistance", label: "مسافة الكاميرا (م)", type: "number", value: 5.2, min: 2, max: 14, step: 0.5 },
      { key: "camHeightDeg", label: "ارتفاع الكاميرا الافتراضي (درجة)", type: "number", value: 13, min: -2, max: 70, step: 1 },
      { key: "camFov", label: "زاوية الرؤية الأساسية (درجة)", type: "number", value: 64, min: 35, max: 100, step: 1 },
      { key: "speedFovBoost", label: "زيادة الزاوية مع السرعة (درجة)", type: "number", value: 16, min: 0, max: 35, step: 1 },
      { key: "camRoll", label: "ميل الكاميرا مع الموتسيكل (0-1)", type: "number", value: 0.3, min: 0, max: 1, step: 0.05 },
      { key: "camShake", label: "اهتزاز الكاميرا مع السرعة (0-1)", type: "number", value: 0.5, min: 0, max: 1, step: 0.05 },
      { key: "camSensitivity", label: "حساسية الماوس (راديان/بكسل)", type: "number", value: 0.0045, min: 0.001, max: 0.015, step: 0.0005 },
      { key: "camKeySpeed", label: "سرعة تدوير الكاميرا بالأسهم (راديان/ث)", type: "number", value: 1.8, min: 0.5, max: 5, step: 0.1 },
      { key: "camFollow", label: "سرعة تتبع الكاميرا للاتجاه (1/ث)", type: "number", value: 5, min: 1, max: 15, step: 0.5 },
      { key: "camRecenterDelay", label: "مهلة رجوع الكاميرا للخلف (ث)", type: "number", value: 2.2, min: 0.5, max: 10, step: 0.5 },
      { key: "camLerp", label: "نعومة الكاميرا (0-1)", type: "number", value: 0.45, min: 0.05, max: 1, step: 0.05 },

      { key: "interactRadius", label: "مسافة الركوب (م)", type: "number", value: 3, min: 1.5, max: 8, step: 0.1 },
      { key: "headlights", label: "الكشافات الأمامية", type: "boolean", value: true },
      { key: "soundOn", label: "صوت الموتور", type: "boolean", value: true },
      { key: "soundVolume", label: "مستوى الصوت (0-1)", type: "number", value: 0.6, min: 0, max: 1, step: 0.05 },
      { key: "showHud", label: "عداد السرعة على الشاشة", type: "boolean", value: true },
      { key: "showHint", label: "تعليمات التحكم عند الركوب", type: "boolean", value: true },

      { key: "riderLift", label: "ضبط ارتفاع الراكب (م)", type: "number", value: 0, min: -0.3, max: 0.3, step: 0.01 },
      { key: "riderLeanComp", label: "ميل جذع الراكب مع المنعطف (0-1)", type: "number", value: 0.8, min: 0, max: 1.5, step: 0.05 },
      { key: "flipArmSide", label: "عكس ميل الذراعين جانبياً", type: "boolean", value: false },
      { key: "flipKnee", label: "عكس ثني الركبة", type: "boolean", value: false },
      { key: "flipLean", label: "عكس ميل الجذع", type: "boolean", value: false },
      { key: "riderYawOffsetDeg", label: "تعديل اتجاه الراكب (درجة)", type: "number", value: 0, min: -180, max: 180, step: 15 }
    ]);
  }

  function PR(key) { var p = Game.params; return p ? p[key] : undefined; }
  function PN(key, def) {
    var v = PR(key);
    if (v === undefined || v === null || v === "") return def;
    v = Number(v);
    return isFinite(v) ? v : def;
  }
  function PB(key, def) {
    var v = PR(key);
    if (v === undefined || v === null) return def;
    if (typeof v === "string") return v === "true" || v === "1";
    return !!v;
  }
  function PS(key, def) {
    var v = PR(key);
    return (v === undefined || v === null || v === "") ? def : String(v);
  }
  function call(name) {
    var f = Game[name];
    if (typeof f !== "function") return undefined;
    try { return f.apply(Game, Array.prototype.slice.call(arguments, 1)); } catch (e) { return undefined; }
  }
  function down(code) { return !!call("isKeyDown", code); }

  
  
  
  var PI = Math.PI, TAU = Math.PI * 2, GRAV = 9.81;
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function damp(cur, target, rate, dt) { return cur + (target - cur) * (1 - Math.exp(-rate * dt)); }
  function wrap(a) { while (a > PI) a -= TAU; while (a < -PI) a += TAU; return a; }
  function smooth(e0, e1, x) { var t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); }
  function sgn(x) { return x < 0 ? -1 : (x > 0 ? 1 : 0); }

  
  
  
  var DIM = { wheelBase: 1.52, rearR: 0.31, rearW: 0.19, frontR: 0.31, frontW: 0.12, rake: 0.4189, forkLen: 0.777 };
  var HEAD = { x: 0, y: 1.02, z: -1.20 };                 
  var GRIP = { x: 0.335, y: -0.10, z: 0.30 };            
  var PEG = { x: 0.27, y: 0.42, z: -0.30 };               
  var HIP = { x: 0, y: 0.93, z: -0.38 };                  
  
  function fitRider() {
    var d = call("getPlayerDims", 0);
    if (!d || !d.ride) return;
    RIDER.hipH = d.ride.hipHeight;
    RIDER.thigh = d.ride.thigh; RIDER.shin = d.ride.shin;
    RIDER.upperArm = d.ride.upperArm; RIDER.foreArm = d.ride.foreArm;
    RIDER.shoulderX = d.ride.shoulderWidth / 2;
    RIDER.torso = Math.max(0.3, d.ride.shoulderHeight - d.ride.hipHeight);
  }
  var RIDER = { hipH: 0.96, torso: 0.55, shoulderX: 0.20, upperArm: 0.31, foreArm: 0.29, thigh: 0.46, shin: 0.50, hipX: 0.12 };
  var MOUNT_TIME = 1.0, DISMOUNT_TIME = 0.8, PARK_LEAN = 0.20;
  var GEAR_TOP = [0.19, 0.31, 0.44, 0.59, 0.78, 1.0];     
  var CAM_NAMES = ["مطاردة", "سينمائية منخفضة", "درون", "عين السواق"];

  
  
  
  var S = {
    mode: "idle", t: 0, modeT: 0, lastToggle: -99, cleaned: false, errLogged: false, frameNo: 0, matFrame: -1,
    v: 0, yaw: root.rotation.y, steerIn: 0, steerVis: 0, yawRate: 0, accel: 0, lat: 0, lean: PARK_LEAN, leanVel: 0,
    pitch: 0, forkComp: 0, wSpinR: 0, wSpinF: 0, throttle: 0, throttleVis: 0, brakeLvl: 0, brakeOn: false,
    gear: 1, rpm01: 0.1, rpm: 1300, shiftCut: 0, nitro: 100, nitroOn: false, nitroVis: 0, pop: 0, deploy: 1,
    camMode: 0, camAzOff: 0, camPitch: PN("camHeightDeg", 13) * PI / 180, camDistUser: 1, camYaw: root.rotation.y, lastCamInput: -99,
    orbitA: 0, camHit: 0, camLabelT: -1, hintT: -1, yawFix: 0, yawFixTries: 0, yawFixT: 0, coast: false,
    mountFrom: new THREE.Vector3(), exitPos: new THREE.Vector3(),
    fPrev: false, hPrev: false, cPrev: false, collT: 0, wallT: -99, lastPos: new THREE.Vector3(), lastYawM: root.rotation.y,
    syncT: 0, paramT: 1, hudT: 0, dashT: 0, sparkT: 0, popT: 0, tuck: 0.8, prevThr: false
  };
  var spawnPos = root.position.clone();
  var spawnYaw = root.rotation.y;
  var DRV_KEY = "bike_driver_" + (root.userData && root.userData.id != null ? root.userData.id : (root.userData && root.userData.instanceName ? root.userData.instanceName : (OBJECT_NAME || "bike")));
  S.lastPos.copy(root.position);

  
  
  
  function stdMat(color, rough, metal, extra) {
    var o = { color: color, roughness: rough, metalness: metal };
    if (extra) { for (var k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) o[k] = extra[k]; } }
    return new THREE.MeshStandardMaterial(o);
  }
  function canvasTex(w, h, draw) {
    if (typeof document === "undefined") return null;
    try {
      var c = document.createElement("canvas");
      c.width = w; c.height = h;
      var ctx = c.getContext("2d");
      if (!ctx) return null;
      draw(ctx, w, h);
      var t = new THREE.CanvasTexture(c);
      if (THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
      else if (THREE.sRGBEncoding !== undefined) t.encoding = THREE.sRGBEncoding;
      t.anisotropy = 4;
      return { tex: t, canvas: c, draw: draw };
    } catch (e) { return null; }
  }
  function redrawTex(o) {
    if (!o) return;
    try {
      var ctx = o.canvas.getContext("2d");
      ctx.clearRect(0, 0, o.canvas.width, o.canvas.height);
      o.draw(ctx, o.canvas.width, o.canvas.height);
      o.tex.needsUpdate = true;
    } catch (e) {}
  }
  function texMat(o, fallback, extra) {
    var p = { color: o ? 0xffffff : fallback, roughness: 0.5, metalness: 0.1 };
    if (o) p.map = o.tex;
    if (extra) { for (var k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) p[k] = extra[k]; } }
    return new THREE.MeshStandardMaterial(p);
  }
  function paintMat() {
    try {
      return new THREE.MeshPhysicalMaterial({ color: 0xc1121f, roughness: 0.22, metalness: 0.3, clearcoat: 1.0, clearcoatRoughness: 0.08, side: THREE.DoubleSide });
    } catch (e) { return stdMat(0xc1121f, 0.25, 0.3, { side: THREE.DoubleSide }); }
  }

  var TX = {};
  TX.carbon = canvasTex(64, 64, function (ctx, w, h) {
    var x, y;
    ctx.fillStyle = "#0b0b0d"; ctx.fillRect(0, 0, w, h);
    for (y = 0; y < h; y += 8) {
      for (x = 0; x < w; x += 8) {
        ctx.fillStyle = (((x + y) / 8) % 2 === 0) ? "#1d1f24" : "#121317";
        ctx.fillRect(x, y, 8, 8);
        ctx.fillStyle = "rgba(255,255,255,0.06)";
        ctx.fillRect(x, y, 8, 2);
      }
    }
  });
  if (TX.carbon && THREE.RepeatWrapping !== undefined) {
    try { TX.carbon.tex.wrapS = THREE.RepeatWrapping; TX.carbon.tex.wrapT = THREE.RepeatWrapping; TX.carbon.tex.repeat.set(3, 3); } catch (e) {}
  }
  TX.number = canvasTex(128, 128, function (ctx, w, h) {
    ctx.fillStyle = "#f6f6f2"; ctx.beginPath(); ctx.arc(w / 2, h / 2, w * 0.48, 0, TAU); ctx.fill();
    ctx.lineWidth = 8; ctx.strokeStyle = "#101114"; ctx.stroke();
    ctx.fillStyle = "#101114"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 72px sans-serif"; ctx.fillText(PS("raceNumber", "46"), w / 2, h / 2 + 4, w * 0.7);
  });
  TX.brand = canvasTex(256, 64, function (ctx, w, h) {
    ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.font = "italic bold 46px sans-serif";
    ctx.lineWidth = 6; ctx.strokeStyle = "rgba(0,0,0,0.85)"; ctx.strokeText(PS("brandText", "TURBO"), w / 2, h / 2, w - 16);
    ctx.fillStyle = "#f4f4f0"; ctx.fillText(PS("brandText", "TURBO"), w / 2, h / 2, w - 16);
  });
  TX.plate = canvasTex(128, 64, function (ctx, w, h) {
    ctx.fillStyle = "#f1f1ea"; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#111"; ctx.lineWidth = 4; ctx.strokeRect(3, 3, w - 6, h - 6);
    ctx.fillStyle = "#111"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.font = "bold 34px sans-serif";
    ctx.fillText("RACE " + PS("raceNumber", "46"), w / 2, h / 2 + 2, w - 12);
  });
  
  var dashState = { kmh: 0, gear: 1, rpm01: 0.1, nitro: 100, nitroOn: false };
  TX.dash = canvasTex(256, 128, function (ctx, w, h) {
    var i, n = 24, on;
    ctx.fillStyle = "#04070c"; ctx.fillRect(0, 0, w, h);
    for (i = 0; i < n; i++) {
      on = (i / n) < dashState.rpm01;
      ctx.fillStyle = on ? (i > n * 0.82 ? "#ff2a2a" : (i > n * 0.62 ? "#ffb000" : "#27e0ff")) : "#12202c";
      ctx.fillRect(8 + i * 10, 10, 8, 16);
    }
    ctx.fillStyle = "#f4f8ff"; ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
    ctx.font = "bold 62px sans-serif"; ctx.fillText(String(Math.round(dashState.kmh)), 10, 88);
    ctx.font = "bold 16px sans-serif"; ctx.fillStyle = "#7da0c0"; ctx.fillText("km/h", 12, 112);
    ctx.fillStyle = "#ffb000"; ctx.font = "bold 58px sans-serif"; ctx.textAlign = "right"; ctx.fillText(String(dashState.gear), w - 18, 88);
    ctx.fillStyle = "#7da0c0"; ctx.font = "bold 14px sans-serif"; ctx.fillText("GEAR", w - 18, 110);
    ctx.fillStyle = "#12202c"; ctx.fillRect(100, 100, 90, 8);
    ctx.fillStyle = dashState.nitroOn ? "#7cf3ff" : "#1fa3ff"; ctx.fillRect(100, 100, 90 * clamp(dashState.nitro / 100, 0, 1), 8);
  });

  var M = {
    paint: paintMat(),
    accent: stdMat(0x101114, 0.4, 0.3),
    gold: stdMat(0xd9a72b, 0.28, 0.85, { emissive: 0x3a2a05, emissiveIntensity: 0.5 }),
    carbon: texMat(TX.carbon, 0x15161a, { roughness: 0.32, metalness: 0.35 }),
    alu: stdMat(0xaab3bd, 0.32, 0.8, { emissive: 0x20262c, emissiveIntensity: 0.6 }),
    gun: stdMat(0x3a3f47, 0.45, 0.8, { emissive: 0x111418, emissiveIntensity: 0.5 }),
    steel: stdMat(0xc9ced5, 0.22, 0.9, { emissive: 0x2a3036, emissiveIntensity: 0.6 }),
    titan: stdMat(0x8b92a0, 0.3, 0.9, { emissive: 0x1a1f33, emissiveIntensity: 0.6 }),
    heat: stdMat(0x3a54c8, 0.35, 0.9, { emissive: 0x0b1a66, emissiveIntensity: 0.8 }),
    rubber: stdMat(0x111111, 0.95, 0.05),
    seat: stdMat(0x17181b, 0.9, 0.05),
    chain: stdMat(0x2b2b2b, 0.5, 0.8),
    disc: stdMat(0xb9bec6, 0.3, 0.9, { side: THREE.DoubleSide, emissive: 0x1f242a, emissiveIntensity: 0.5 }),
    caliper: stdMat(0xd62839, 0.35, 0.5),
    spring: stdMat(0xd62839, 0.4, 0.5),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x1b2430, roughness: 0.05, metalness: 0.0, transparent: true, opacity: 0.45, side: THREE.DoubleSide, depthWrite: false }),
    mirror: stdMat(0xcfe4ff, 0.05, 0.95, { emissive: 0x2a3a4a, emissiveIntensity: 0.5 }),
    lens: stdMat(0xffffff, 0.1, 0.1, { emissive: 0xdff2ff, emissiveIntensity: 1.2 }),
    drl: new THREE.MeshBasicMaterial({ color: 0xcfeaff }),
    tail: stdMat(0x600000, 0.3, 0.2, { emissive: 0xff1414, emissiveIntensity: 0.6 }),
    sig: stdMat(0x6b4a00, 0.3, 0.2, { emissive: 0xffa800, emissiveIntensity: 0.05 }),
    dashScr: TX.dash ? new THREE.MeshBasicMaterial({ map: TX.dash.tex }) : stdMat(0x04070c, 0.3, 0.1, { emissive: 0x27e0ff, emissiveIntensity: 0.3 }),
    glow: new THREE.MeshBasicMaterial({ color: 0x19b5ff }),
    flame: new THREE.MeshBasicMaterial({ color: 0x66ccff, transparent: true, opacity: 0.85, depthWrite: false }),
    popFlame: new THREE.MeshBasicMaterial({ color: 0xff8a1f, transparent: true, opacity: 0.9, depthWrite: false }),
    spark: new THREE.MeshBasicMaterial({ color: 0xffd37a })
  };
  try { if (THREE.AdditiveBlending !== undefined) { M.flame.blending = THREE.AdditiveBlending; M.popFlame.blending = THREE.AdditiveBlending; M.spark.blending = THREE.AdditiveBlending; } } catch (e) {}

  
  
  
  var _up = new THREE.Vector3(0, 1, 0), _zAxis = new THREE.Vector3(0, 0, 1);

  function add(parent, geo, mat, x, y, z, shadow) {
    var m = new THREE.Mesh(geo, mat);
    m.position.set(x || 0, y || 0, z || 0);
    if (shadow) m.castShadow = true;
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  function rod(parent, p1, p2, r, mat, seg) {
    var a = new THREE.Vector3(p1[0], p1[1], p1[2]), b = new THREE.Vector3(p2[0], p2[1], p2[2]);
    var dir = b.clone().sub(a), len = dir.length();
    if (len < 1e-5) return null;
    var m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg || 8, 1), mat);
    m.position.copy(a).add(b).multiplyScalar(0.5);
    m.quaternion.setFromUnitVectors(_up, dir.normalize());
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  
  function beam(parent, p1, p2, w, h, mat) {
    var a = new THREE.Vector3(p1[0], p1[1], p1[2]), b = new THREE.Vector3(p2[0], p2[1], p2[2]);
    var dir = b.clone().sub(a), len = dir.length();
    if (len < 1e-5) return null;
    var m = new THREE.Mesh(rboxGeo(w, h, len, Math.min(w, h) * 0.3), mat);
    m.position.copy(a).add(b).multiplyScalar(0.5);
    m.quaternion.setFromUnitVectors(_zAxis, dir.normalize());
    m.userData.noCollision = true;
    m.castShadow = true;
    parent.add(m);
    return m;
  }
  function tube(parent, pts, r, mat, segs, radial) {
    var v = [], i;
    for (i = 0; i < pts.length; i++) v.push(new THREE.Vector3(pts[i][0], pts[i][1], pts[i][2]));
    var curve = new THREE.CatmullRomCurve3(v);
    var m = new THREE.Mesh(new THREE.TubeGeometry(curve, segs || 24, r, radial || 8, false), mat);
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  function rboxGeo(w, h, d, r) {
    var b = Math.max(0.002, Math.min(r || 0.02, w * 0.4, h * 0.4, d * 0.4));
    var iw = Math.max(0.001, w - 2 * b), ih = Math.max(0.001, h - 2 * b), id = Math.max(0.001, d - 2 * b);
    var s = new THREE.Shape();
    s.moveTo(-iw / 2, -ih / 2); s.lineTo(iw / 2, -ih / 2); s.lineTo(iw / 2, ih / 2); s.lineTo(-iw / 2, ih / 2); s.lineTo(-iw / 2, -ih / 2);
    var g = new THREE.ExtrudeGeometry(s, { depth: id, bevelEnabled: true, bevelThickness: b, bevelSize: b, bevelSegments: 2, steps: 1 });
    g.translate(0, 0, -id / 2);
    return g;
  }
  
  function profileGeo(pts, width, bevel) {
    var s = new THREE.Shape(), i;
    for (i = 0; i < pts.length; i++) {
      if (i === 0) s.moveTo(-pts[i][0], pts[i][1]); else s.lineTo(-pts[i][0], pts[i][1]);
    }
    s.lineTo(-pts[0][0], pts[0][1]);
    var b = bevel || 0.03, depth = Math.max(0.001, width - 2 * b);
    var g = new THREE.ExtrudeGeometry(s, { depth: depth, bevelEnabled: true, bevelThickness: b, bevelSize: b, bevelSegments: 3, steps: 1 });
    g.translate(0, 0, -depth / 2);
    g.rotateY(PI / 2);
    return g;
  }
  function fenderGeo(r, w, thetaStart, thetaLen) {
    var g = new THREE.CylinderGeometry(r, r, w, 28, 1, true, thetaStart, thetaLen);
    g.rotateZ(PI / 2);
    return g;
  }
  var geoBolt = new THREE.CylinderGeometry(0.009, 0.009, 0.012, 6);
  geoBolt.rotateZ(PI / 2);

  
  function buildWheel(R, W, name, discR) {
    var g = new THREE.Group();
    g.name = name;
    var rimR = R * 0.70, hw = W / 2, i, a, side, V = THREE.Vector2;
    var prof = [
      new V(rimR - 0.012, -hw * 0.70), new V(rimR + 0.012, -hw * 0.92), new V(R - 0.07, -hw), new V(R - 0.025, -hw * 0.94),
      new V(R - 0.003, -hw * 0.62), new V(R, -hw * 0.30), new V(R, hw * 0.30), new V(R - 0.003, hw * 0.62),
      new V(R - 0.025, hw * 0.94), new V(R - 0.07, hw), new V(rimR + 0.012, hw * 0.92), new V(rimR - 0.012, hw * 0.70)
    ];
    var tg = new THREE.LatheGeometry(prof, 40);
    tg.rotateZ(PI / 2);
    add(g, tg, M.rubber, 0, 0, 0, true);
    var rg = new THREE.CylinderGeometry(rimR + 0.004, rimR + 0.004, W * 0.78, 32, 1, true);
    rg.rotateZ(PI / 2);
    add(g, rg, M.gold, 0, 0, 0);
    var hubG = new THREE.CylinderGeometry(0.045, 0.045, W * 1.05, 14);
    hubG.rotateZ(PI / 2);
    add(g, hubG, M.alu, 0, 0, 0);
    var spokeG = new THREE.BoxGeometry(0.014, rimR * 0.86, 0.034);
    for (side = -1; side <= 1; side += 2) {
      for (i = 0; i < 5; i++) {
        a = i * TAU / 5;
        var s1 = add(g, spokeG, M.gold, side * hw * 0.52, Math.cos(a + 0.09) * rimR * 0.46, Math.sin(a + 0.09) * rimR * 0.46);
        s1.rotation.x = -(a + 0.09);
        var s2 = add(g, spokeG, M.gold, side * hw * 0.52, Math.cos(a - 0.09) * rimR * 0.46, Math.sin(a - 0.09) * rimR * 0.46);
        s2.rotation.x = -(a - 0.09);
      }
      var ring = add(g, new THREE.RingGeometry(rimR - 0.01, rimR + 0.02, 40), M.accent, side * hw * 0.80, 0, 0);
      ring.rotation.y = side * PI / 2;
      var wmk = add(g, new THREE.RingGeometry(R - 0.052, R - 0.045, 40), M.drl, side * (hw * 0.985), 0, 0);
      wmk.rotation.y = side * PI / 2;
    }
    if (discR) {
      
      var sides = (name === "wheel_front") ? [-1, 1] : [1];
      for (var q = 0; q < sides.length; q++) {
        var sx = sides[q];
        var dsc = add(g, new THREE.RingGeometry(discR * 0.62, discR, 40), M.disc, sx * (hw * 0.62), 0, 0);
        dsc.rotation.y = PI / 2;
        var car = add(g, new THREE.RingGeometry(discR * 0.5, discR * 0.64, 24), M.gold, sx * (hw * 0.64), 0, 0);
        car.rotation.y = PI / 2;
        for (i = 0; i < 6; i++) {
          a = i * TAU / 6;
          add(g, geoBolt, M.steel, sx * (hw * 0.66), Math.cos(a) * discR * 0.57, Math.sin(a) * discR * 0.57);
        }
      }
    }
    return g;
  }

  
  
  
  var chassis = new THREE.Group(); chassis.name = "bike_chassis"; root.add(chassis);
  var steerGroup = new THREE.Group(); steerGroup.name = "bike_steer_axis";
  steerGroup.position.set(HEAD.x, HEAD.y, HEAD.z); steerGroup.rotation.x = DIM.rake; chassis.add(steerGroup);
  var steerRot = new THREE.Group(); steerRot.name = "bike_steer"; steerGroup.add(steerRot);
  var lowerFork = new THREE.Group(); lowerFork.name = "bike_fork_lower"; steerRot.add(lowerFork);
  var solidMeshes = [];
  function solid(m) { m.userData.noCollision = false; m.userData.solid = true; m.userData.forceMeshCollision = true; solidMeshes.push(m); return m; }
  var sx, i, k;

  
  var wheelF = buildWheel(DIM.frontR, DIM.frontW, "wheel_front", 0.135);
  wheelF.position.set(0, -DIM.forkLen, 0); lowerFork.add(wheelF);
  var swing = new THREE.Group(); swing.name = "bike_swingarm"; chassis.add(swing);
  var wheelR = buildWheel(DIM.rearR, DIM.rearW, "wheel_rear", 0.125);
  wheelR.position.set(0, DIM.rearR, 0); chassis.add(wheelR);
  
  var sprocketR = add(wheelR, new THREE.CylinderGeometry(0.098, 0.098, 0.010, 28).rotateZ(PI / 2), M.alu, -0.108, 0, 0);
  var sprocketF = add(chassis, new THREE.CylinderGeometry(0.042, 0.042, 0.012, 16).rotateZ(PI / 2), M.alu, -0.108, 0.42, -0.52);
  rod(chassis, [-0.108, DIM.rearR + 0.098, 0], [-0.108, 0.42 + 0.042, -0.52], 0.006, M.chain, 5);
  rod(chassis, [-0.108, DIM.rearR - 0.098, 0], [-0.108, 0.42 - 0.042, -0.52], 0.006, M.chain, 5);

  
  for (sx = -1; sx <= 1; sx += 2) {
    rod(steerRot, [sx * 0.10, 0.0, 0], [sx * 0.10, -0.40, 0], 0.024, M.gun, 12);             
    rod(lowerFork, [sx * 0.10, -0.30, 0], [sx * 0.10, -DIM.forkLen, 0], 0.019, M.gold, 12);   
    add(lowerFork, new THREE.CylinderGeometry(0.03, 0.03, 0.05, 12).rotateZ(PI / 2), M.alu, sx * 0.10, -DIM.forkLen, 0);
    var cal = add(lowerFork, rboxGeo(0.05, 0.11, 0.09, 0.012), M.caliper, sx * 0.075, -DIM.forkLen + 0.12, -0.12);   
    add(lowerFork, new THREE.CylinderGeometry(0.012, 0.012, 0.03, 8), M.gold, sx * 0.09, -DIM.forkLen + 0.17, -0.12);
  }
  add(steerRot, rboxGeo(0.30, 0.04, 0.07, 0.012), M.alu, 0, -0.02, 0);                          
  add(steerRot, rboxGeo(0.28, 0.035, 0.07, 0.012), M.alu, 0, -0.30, 0);
  add(steerRot, new THREE.CylinderGeometry(0.03, 0.03, 0.06, 12), M.gold, 0, 0.05, 0);
  
  add(lowerFork, fenderGeo(0.345, 0.15, -0.3, PI + 0.1), M.carbon, 0, -DIM.forkLen, 0, true);
  
  var gripGroupL = new THREE.Group(); gripGroupL.position.set(-GRIP.x, GRIP.y, GRIP.z); steerRot.add(gripGroupL);
  var gripGroupR = new THREE.Group(); gripGroupR.position.set(GRIP.x, GRIP.y, GRIP.z); steerRot.add(gripGroupR);
  rod(steerRot, [-0.075, -0.12, 0.02], [-0.27, GRIP.y, GRIP.z], 0.0125, M.alu, 8);
  rod(steerRot, [0.075, -0.12, 0.02], [0.27, GRIP.y, GRIP.z], 0.0125, M.alu, 8);
  add(gripGroupL, new THREE.CylinderGeometry(0.0195, 0.0195, 0.13, 12).rotateZ(PI / 2), M.rubber, 0, 0, 0);
  add(gripGroupR, new THREE.CylinderGeometry(0.021, 0.021, 0.13, 12).rotateZ(PI / 2), M.rubber, 0, 0, 0);
  add(gripGroupL, new THREE.CylinderGeometry(0.014, 0.014, 0.02, 8).rotateZ(PI / 2), M.gold, -0.07, 0, 0);
  add(gripGroupR, new THREE.CylinderGeometry(0.014, 0.014, 0.02, 8).rotateZ(PI / 2), M.gold, 0.07, 0, 0);
  rod(steerRot, [-0.30, GRIP.y + 0.01, GRIP.z - 0.02], [-0.31, GRIP.y + 0.03, GRIP.z - 0.16], 0.006, M.alu, 5);    
  rod(steerRot, [0.30, GRIP.y + 0.01, GRIP.z - 0.02], [0.31, GRIP.y + 0.03, GRIP.z - 0.16], 0.006, M.alu, 5);      
  add(steerRot, rboxGeo(0.05, 0.035, 0.05, 0.01), M.accent, 0.23, -0.10, 0.22);                      
  add(steerRot, rboxGeo(0.05, 0.035, 0.05, 0.01), M.accent, -0.23, -0.10, 0.22);
  rod(steerRot, [0.0, -0.05, -0.02], [0.0, -0.05, 0.14], 0.01, M.gold, 6);                          
  
  var gripObjL = new THREE.Object3D(); gripGroupL.add(gripObjL);
  var gripObjR = new THREE.Object3D(); gripGroupR.add(gripObjR);

  
  for (sx = -1; sx <= 1; sx += 2) {
    beam(chassis, [sx * 0.10, 0.99, -1.12], [sx * 0.17, 0.80, -0.62], 0.05, 0.07, M.alu);
    beam(chassis, [sx * 0.17, 0.80, -0.62], [sx * 0.155, 0.50, -0.55], 0.05, 0.085, M.alu);
    beam(chassis, [sx * 0.155, 0.50, -0.55], [sx * 0.105, 0.31, 0.0], 0.04, 0.075, M.alu);       
    beam(chassis, [sx * 0.13, 0.84, -0.50], [sx * 0.095, 0.80, 0.15], 0.03, 0.04, M.gun);        
    beam(chassis, [sx * 0.12, 0.60, -0.28], [sx * 0.09, 0.78, 0.04], 0.025, 0.03, M.gun);
    add(chassis, new THREE.CylinderGeometry(0.03, 0.03, 0.03, 12).rotateZ(PI / 2), M.gold, sx * 0.165, 0.50, -0.55);
    add(chassis, new THREE.CylinderGeometry(0.026, 0.026, 0.012, 12).rotateZ(PI / 2), M.alu, sx * 0.125, DIM.rearR, 0.0);
    
    rod(chassis, [sx * 0.15, 0.55, -0.22], [sx * PEG.x, PEG.y, PEG.z], 0.012, M.alu, 6);
    add(chassis, new THREE.CylinderGeometry(0.011, 0.011, 0.085, 8).rotateZ(PI / 2), M.steel, sx * (PEG.x + 0.02), PEG.y, PEG.z);
    
    
    add(chassis, rboxGeo(0.04, 0.07, 0.10, 0.01), M.caliper, 0.085, 0.38, 0.09);
  }
  var pegObjL = new THREE.Object3D(); pegObjL.position.set(-PEG.x, PEG.y, PEG.z); chassis.add(pegObjL);
  var pegObjR = new THREE.Object3D(); pegObjR.position.set(PEG.x, PEG.y, PEG.z); chassis.add(pegObjR);
  beam(chassis, [-0.105, DIM.rearR + 0.05, 0.0], [0.105, DIM.rearR + 0.05, 0.0], 0.02, 0.02, M.gun);
  
  rod(chassis, [0, 0.74, -0.16], [0, 0.40, -0.48], 0.027, M.gold, 12);
  rod(chassis, [0, 0.69, -0.20], [0, 0.50, -0.38], 0.041, M.spring, 12);
  add(chassis, new THREE.CylinderGeometry(0.02, 0.02, 0.14, 10), M.gold, 0.05, 0.62, -0.28);

  
  var engineBody = solid(add(chassis, rboxGeo(0.26, 0.26, 0.38, 0.03), M.gun, 0, 0.40, -0.60, true));
  var cylBlock = add(chassis, rboxGeo(0.27, 0.22, 0.34, 0.03), M.gun, 0, 0.62, -0.80, true);
  cylBlock.rotation.x = -0.45;
  for (k = 0; k < 7; k++) {
    var fin = add(chassis, rboxGeo(0.29, 0.012, 0.36, 0.004), M.alu, 0, 0.53 + k * 0.026, -0.78 - k * 0.012);
    fin.rotation.x = -0.45;
  }
  var cover = add(chassis, rboxGeo(0.25, 0.05, 0.30, 0.015), M.accent, 0, 0.77, -0.87, true);
  cover.rotation.x = -0.45;
  add(chassis, new THREE.CylinderGeometry(0.05, 0.05, 0.03, 16).rotateZ(PI / 2), M.gold, 0.15, 0.40, -0.60);
  add(chassis, new THREE.CylinderGeometry(0.05, 0.05, 0.03, 16).rotateZ(PI / 2), M.alu, -0.15, 0.40, -0.60);
  add(chassis, rboxGeo(0.30, 0.30, 0.05, 0.015), M.accent, 0, 0.64, -1.14);                        
  for (k = 0; k < 6; k++) add(chassis, new THREE.BoxGeometry(0.28, 0.006, 0.012), M.gun, 0, 0.52 + k * 0.045, -1.17);
  
  var hdX = [-0.075, -0.025, 0.025, 0.075];
  for (i = 0; i < 4; i++) {
    tube(chassis, [[hdX[i], 0.66, -1.00], [hdX[i], 0.45, -1.08], [hdX[i] * 0.6, 0.27, -0.95], [hdX[i] * 0.2, 0.22, -0.70]], 0.017, M.titan, 24, 8);
    add(chassis, new THREE.CylinderGeometry(0.02, 0.02, 0.05, 8), M.heat, hdX[i], 0.50, -1.065);
  }
  add(chassis, new THREE.CylinderGeometry(0.06, 0.06, 0.34, 14).rotateX(PI / 2), M.titan, 0, 0.22, -0.52, true);
  var exhTipL = new THREE.Object3D(); exhTipL.position.set(-0.14, 0.64, 0.74); chassis.add(exhTipL);
  var exhTipR = new THREE.Object3D(); exhTipR.position.set(0.14, 0.64, 0.74); chassis.add(exhTipR);
  for (sx = -1; sx <= 1; sx += 2) {
    tube(chassis, [[0, 0.22, -0.40], [sx * 0.07, 0.30, -0.10], [sx * 0.13, 0.52, 0.25], [sx * 0.14, 0.62, 0.62]], 0.026, M.titan, 24, 10);
    add(chassis, new THREE.CylinderGeometry(0.052, 0.046, 0.30, 14).rotateX(PI / 2 + 0.12), M.titan, sx * 0.14, 0.62, 0.60, true);
    add(chassis, new THREE.CylinderGeometry(0.044, 0.044, 0.06, 14).rotateX(PI / 2 + 0.12), M.carbon, sx * 0.14, 0.64, 0.76);
    add(chassis, new THREE.CylinderGeometry(0.054, 0.054, 0.035, 14).rotateX(PI / 2 + 0.12), M.heat, sx * 0.14, 0.62, 0.50);
  }

  
  var tank = add(chassis, profileGeo([
    [-1.05, 0.96], [-0.98, 1.06], [-0.70, 1.13], [-0.42, 1.10], [-0.30, 1.00], [-0.38, 0.90], [-0.70, 0.88], [-1.00, 0.90]
  ], 0.30, 0.075), M.paint, 0, 0, 0, true);
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, rboxGeo(0.02, 0.17, 0.30, 0.01), M.rubber, sx * 0.158, 0.985, -0.66);           
    add(chassis, new THREE.BoxGeometry(0.035, 0.006, 0.62), M.accent, sx * 0.045, 1.131, -0.70);   
  }
  add(chassis, new THREE.CylinderGeometry(0.045, 0.045, 0.016, 16), M.alu, 0, 1.133, -0.62);      
  var nose = add(chassis, profileGeo([
    [-1.40, 0.74], [-1.44, 0.88], [-1.36, 1.02], [-1.20, 1.12], [-0.98, 1.15], [-0.92, 0.96], [-1.02, 0.76], [-1.20, 0.70]
  ], 0.30, 0.06), M.paint, 0, 0, 0, true);
  for (sx = -1; sx <= 1; sx += 2) {
    var side = add(chassis, profileGeo([
      [-1.28, 0.82], [-1.04, 1.03], [-0.72, 0.93], [-0.52, 0.80], [-0.30, 0.55], [-0.45, 0.38], [-0.85, 0.34], [-1.20, 0.52]
    ], 0.03, 0.012), M.paint, sx * 0.175, 0, 0, true);
    add(chassis, rboxGeo(0.03, 0.05, 0.22, 0.01), M.accent, sx * 0.185, 0.86, -1.06);             
    add(chassis, rboxGeo(0.035, 0.03, 0.20, 0.008), M.carbon, sx * 0.19, 0.74, -0.78);
    
    var nr = add(chassis, new THREE.CircleGeometry(0.065, 24), texMat(TX.number, 0xf6f6f2, { transparent: true, side: THREE.DoubleSide }), sx * 0.2, 0.70, -0.62);
    nr.rotation.y = sx * PI / 2;
    var br = add(chassis, new THREE.PlaneGeometry(0.30, 0.075), texMat(TX.brand, 0xffffff, { transparent: true, side: THREE.DoubleSide }), sx * 0.2, 0.52, -0.62);
    br.rotation.y = sx * PI / 2;
    
    rod(chassis, [sx * 0.17, 1.02, -1.04], [sx * 0.34, 1.12, -1.00], 0.008, M.alu, 6);
    var mh = add(chassis, rboxGeo(0.10, 0.06, 0.02, 0.008), M.accent, sx * 0.36, 1.13, -1.00);
    mh.rotation.y = sx * -0.3 + sx * 0.1;
    var mg = add(chassis, new THREE.PlaneGeometry(0.085, 0.048), M.mirror, sx * 0.36, 1.13, -0.987);
    mg.rotation.y = sx * -0.3 + sx * 0.1;
    
    add(chassis, new THREE.SphereGeometry(0.014, 8, 6), M.sig, sx * 0.31, 1.09, -1.06);
    add(chassis, new THREE.SphereGeometry(0.014, 8, 6), M.sig, sx * 0.075, 0.82, 0.86);
  }
  add(chassis, rboxGeo(0.28, 0.07, 0.34, 0.02), M.carbon, 0, 0.27, -0.72, true);                    
  
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, new THREE.CylinderGeometry(0.052, 0.052, 0.035, 20).rotateX(PI / 2), M.alu, sx * 0.085, 0.93, -1.435);
    add(chassis, new THREE.SphereGeometry(0.045, 16, 10, 0, TAU, 0, PI / 2).rotateX(-PI / 2), M.lens, sx * 0.085, 0.93, -1.445);
  }
  add(chassis, rboxGeo(0.30, 0.012, 0.01, 0.003), M.drl, 0, 0.985, -1.45);                           
  var winArc = new THREE.CylinderGeometry(0.62, 0.62, 0.27, 20, 1, true, PI - 0.28, 0.56);
  var wind = add(chassis, winArc, M.glass, 0, 1.22, -0.92 - 0.62 + 0.03);
  wind.rotation.x = 0.82;
  rod(chassis, [-0.145, 1.08, -1.0], [-0.145, 1.28, -0.88], 0.006, M.alu, 5);
  rod(chassis, [0.145, 1.08, -1.0], [0.145, 1.28, -0.88], 0.006, M.alu, 5);
  
  add(chassis, rboxGeo(0.20, 0.11, 0.05, 0.015), M.accent, 0, 1.06, -0.98);
  var dashScreen = add(chassis, new THREE.PlaneGeometry(0.17, 0.085), M.dashScr, 0, 1.075, -0.953);
  dashScreen.rotation.x = -0.55;
  var dashHolder = dashScreen;

  
  add(chassis, rboxGeo(0.30, 0.07, 0.52, 0.03), M.seat, 0, 0.82, -0.38);
  var tail = add(chassis, profileGeo([
    [-0.05, 0.86], [0.15, 0.97], [0.45, 1.01], [0.74, 0.97], [0.82, 0.90], [0.74, 0.84], [0.40, 0.80]
  ], 0.22, 0.06), M.paint, 0, 0, 0, true);
  add(chassis, rboxGeo(0.14, 0.03, 0.30, 0.012), M.seat, 0, 0.995, 0.22);
  add(chassis, rboxGeo(0.20, 0.018, 0.012, 0.004), M.tail, 0, 0.93, 0.84);                          
  add(chassis, new THREE.BoxGeometry(0.02, 0.05, 0.012), M.tail, -0.075, 0.90, 0.835);
  add(chassis, new THREE.BoxGeometry(0.02, 0.05, 0.012), M.tail, 0.075, 0.90, 0.835);
  var plateHolder = add(chassis, rboxGeo(0.20, 0.10, 0.01, 0.004), M.carbon, 0, 0.74, 0.86);
  plateHolder.rotation.x = 0.25;
  var plateMesh = add(chassis, new THREE.PlaneGeometry(0.17, 0.085), texMat(TX.plate, 0xf1f1ea), 0, 0.74, 0.867);
  plateMesh.rotation.x = 0.25;
  add(chassis, rboxGeo(0.12, 0.012, 0.18, 0.004), M.carbon, 0, 0.60, 0.52);                         

  
  var stand = new THREE.Group(); stand.position.set(-0.17, 0.38, -0.40); chassis.add(stand);
  rod(stand, [0, 0, 0], [-0.12, -0.32, 0], 0.014, M.gun, 8);
  add(stand, new THREE.BoxGeometry(0.07, 0.012, 0.06), M.rubber, -0.12, -0.325, 0);

  
  var flameGeo = new THREE.ConeGeometry(0.045, 0.55, 10); flameGeo.translate(0, 0.275, 0); flameGeo.rotateX(PI / 2);
  var flames = [];
  var flameSets = [exhTipL, exhTipR];
  for (i = 0; i < 2; i++) {
    var fl = new THREE.Mesh(flameGeo, M.flame); fl.visible = false; fl.userData.noCollision = true; flameSets[i].add(fl);
    var fl2 = new THREE.Mesh(flameGeo, M.popFlame); fl2.visible = false; fl2.userData.noCollision = true; fl2.scale.set(0.7, 0.7, 0.5); flameSets[i].add(fl2);
    flames.push({ nitro: fl, pop: fl2 });
  }
  var headSpot = null, glowLight = null;
  try {
    headSpot = new THREE.SpotLight(0xe8f4ff, 0, 70, 0.42, 0.55, 1.4);
    headSpot.position.set(0, 0.93, -1.4); headSpot.castShadow = false; chassis.add(headSpot);
    headSpot.target.position.set(0, 0.4, -20); chassis.add(headSpot.target);
    glowLight = new THREE.PointLight(0x19b5ff, 1.0, 5, 2);
    glowLight.position.set(0, 0.12, -0.55); chassis.add(glowLight);
  } catch (e) { headSpot = null; glowLight = null; }
  
  add(chassis, rboxGeo(0.02, 0.012, 1.1, 0.004), M.glow, -0.19, 0.20, -0.5);
  add(chassis, rboxGeo(0.02, 0.012, 1.1, 0.004), M.glow, 0.19, 0.20, -0.5);

  
  var SPARK_N = 18;
  var sparkGeo = new THREE.BoxGeometry(0.02, 0.02, 0.05);
  var sparks = [];
  for (i = 0; i < SPARK_N; i++) {
    var sm = new THREE.Mesh(sparkGeo, M.spark); sm.visible = false; sm.userData.noCollision = true; root.add(sm);
    sparks.push({ mesh: sm, pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0 });
  }
  var wallList = [];

  
  
  
  var lastParamKey = "";
  function setCol(mat, str) { try { mat.color.set(str); } catch (e) {} }
  function refreshParams(dt, force) {
    S.paramT += dt;
    if (!force && S.paramT < 0.4) return;
    S.paramT = 0;
    var key = [PS("bodyColor", "#c1121f"), PS("accentColor", "#101114"), PS("goldColor", "#d9a72b"), PS("glowColor", "#19b5ff"), PS("raceNumber", ""), PS("brandText", "")].join("|");
    if (key === lastParamKey) return;
    lastParamKey = key;
    setCol(M.paint, PS("bodyColor", "#c1121f"));
    setCol(M.accent, PS("accentColor", "#101114"));
    setCol(M.gold, PS("goldColor", "#d9a72b"));
    setCol(M.glow, PS("glowColor", "#19b5ff"));
    try { if (glowLight) glowLight.color.set(PS("glowColor", "#19b5ff")); } catch (e) {}
    redrawTex(TX.number); redrawTex(TX.brand); redrawTex(TX.plate);
  }

  
  
  
  var AU = { ctx: null, o1: null, o2: null, o3: null, filt: null, mix: null, master: null, nz: null, nzFilt: null, nzGain: null, whoosh: null, whooshGain: null, noiseBuf: null };
  function audioStart() {
    if (AU.ctx || !PB("soundOn", true)) return;
    try {
      var AC = (typeof window !== "undefined") ? (window.AudioContext || window.webkitAudioContext) : null;
      if (!AC) return;
      var ctx = new AC();
      var master = ctx.createGain(); master.gain.value = 0.0001; master.connect(ctx.destination);
      var filt = ctx.createBiquadFilter(); filt.type = "lowpass"; filt.frequency.value = 800; filt.Q.value = 1.4; filt.connect(master);
      var mix = ctx.createGain(); mix.gain.value = 0.5; mix.connect(filt);
      var o1 = ctx.createOscillator(); o1.type = "sawtooth"; o1.frequency.value = 45;
      var o2 = ctx.createOscillator(); o2.type = "square"; o2.frequency.value = 90;
      var o3 = ctx.createOscillator(); o3.type = "sawtooth"; o3.frequency.value = 22;
      var g1 = ctx.createGain(); g1.gain.value = 0.55; var g2 = ctx.createGain(); g2.gain.value = 0.22; var g3 = ctx.createGain(); g3.gain.value = 0.4;
      o1.connect(g1); g1.connect(mix); o2.connect(g2); g2.connect(mix); o3.connect(g3); g3.connect(mix);
      var len = ctx.sampleRate, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0), q;
      for (q = 0; q < len; q++) d[q] = Math.random() * 2 - 1;
      var nz = ctx.createBufferSource(); nz.buffer = buf; nz.loop = true;
      var nzFilt = ctx.createBiquadFilter(); nzFilt.type = "bandpass"; nzFilt.frequency.value = 1800; nzFilt.Q.value = 0.8;
      var nzGain = ctx.createGain(); nzGain.gain.value = 0.0;
      nz.connect(nzFilt); nzFilt.connect(nzGain); nzGain.connect(master);
      var wh = ctx.createBufferSource(); wh.buffer = buf; wh.loop = true;
      var whF = ctx.createBiquadFilter(); whF.type = "highpass"; whF.frequency.value = 2500;
      var whG = ctx.createGain(); whG.gain.value = 0.0;
      wh.connect(whF); whF.connect(whG); whG.connect(master);
      o1.start(); o2.start(); o3.start(); nz.start(); wh.start();
      if (ctx.state === "suspended" && typeof ctx.resume === "function") ctx.resume();
      AU.ctx = ctx; AU.o1 = o1; AU.o2 = o2; AU.o3 = o3; AU.filt = filt; AU.mix = mix; AU.master = master;
      AU.nz = nz; AU.nzFilt = nzFilt; AU.nzGain = nzGain; AU.whoosh = wh; AU.whooshGain = whG; AU.noiseBuf = buf;
    } catch (e) { AU.ctx = null; }
  }
  function audioUpdate(dt) {
    if (!AU.ctx) return;
    try {
      var vol = clamp(PN("soundVolume", 0.6), 0, 1);
      var active = (S.mode === "riding" || S.mode === "mounting");
      var fire = S.rpm / 60 * 2;                           
      var thr = clamp(S.throttle, 0, 1), t = AU.ctx.currentTime;
      AU.o1.frequency.setTargetAtTime(fire, t, 0.04);
      AU.o2.frequency.setTargetAtTime(fire * 2, t, 0.04);
      AU.o3.frequency.setTargetAtTime(fire * 0.5, t, 0.04);
      AU.filt.frequency.setTargetAtTime(500 + S.rpm01 * 3600 + thr * 900, t, 0.06);
      AU.mix.gain.setTargetAtTime(0.28 + thr * 0.55, t, 0.05);
      AU.nzFilt.frequency.setTargetAtTime(1200 + S.rpm01 * 2600, t, 0.08);
      AU.nzGain.gain.setTargetAtTime(active ? (0.01 + thr * 0.06 * (0.3 + S.rpm01)) * vol : 0, t, 0.06);
      AU.whooshGain.gain.setTargetAtTime(S.nitroOn ? 0.08 * vol : 0.0, t, 0.08);
      AU.master.gain.setTargetAtTime(active ? vol * 0.22 : 0.0001, t, 0.12);
    } catch (e) {}
  }
  function audioPop() {
    if (!AU.ctx || !PB("soundOn", true)) return;
    try {
      var ctx = AU.ctx, t0 = ctx.currentTime, vol = clamp(PN("soundVolume", 0.6), 0, 1);
      var src = ctx.createBufferSource(); src.buffer = AU.noiseBuf;
      var f = ctx.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = 900 + Math.random() * 900; f.Q.value = 1.2;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(0.35 * vol, t0 + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.09);
      src.connect(f); f.connect(g); g.connect(ctx.destination);
      src.start(t0, Math.random() * 0.5, 0.12);
    } catch (e) {}
  }
  function audioHorn() {
    if (!AU.ctx || !PB("soundOn", true)) return;
    try {
      var ctx = AU.ctx, t0 = ctx.currentTime, vol = clamp(PN("soundVolume", 0.6), 0, 1) * 0.1;
      var og = ctx.createGain(); og.gain.value = 0.0001; og.connect(ctx.destination);
      var a = ctx.createOscillator(); a.type = "square"; a.frequency.value = 392;
      var c = ctx.createOscillator(); c.type = "square"; c.frequency.value = 494;
      a.connect(og); c.connect(og);
      og.gain.setValueAtTime(0.0001, t0); og.gain.linearRampToValueAtTime(vol, t0 + 0.02);
      og.gain.setValueAtTime(vol, t0 + 0.30); og.gain.linearRampToValueAtTime(0.0001, t0 + 0.34);
      a.start(t0); c.start(t0); a.stop(t0 + 0.4); c.stop(t0 + 0.4);
    } catch (e) {}
  }
  function audioStop(immediate) {
    if (!AU.ctx) return;
    var ctx = AU.ctx, a = AU;
    try { a.master.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.08); } catch (e) {}
    AU.ctx = null;
    var closer = function () {
      try { a.o1.stop(); a.o2.stop(); a.o3.stop(); a.nz.stop(); a.whoosh.stop(); } catch (e) {}
      try { ctx.close(); } catch (e2) {}
    };
    if (immediate || typeof setTimeout !== "function") closer(); else setTimeout(closer, 400);
  }

  
  
  
  var UI = { hud: null, speed: null, gear: null, rpm: null, nitro: null, label: null, fx: null, fxKey: "" };
  function uiCreate() {
    if (typeof document === "undefined" || UI.hud || !document.body) return;
    try {
      var fx = document.createElement("div");
      fx.setAttribute("data-script-ui", "1");
      fx.style.cssText = "position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:40;opacity:0;transition:opacity .15s linear;";
      document.body.appendChild(fx);
      UI.fx = fx;
      if (!PB("showHud", true)) return;
      var hud = document.createElement("div");
      hud.setAttribute("data-script-ui", "1");
      hud.style.cssText = "position:fixed;right:22px;bottom:22px;width:230px;padding:12px 16px;border-radius:14px;pointer-events:none;z-index:41;font-family:Arial,sans-serif;color:#eaf6ff;background:linear-gradient(145deg,rgba(8,14,22,.78),rgba(20,32,48,.62));border:1px solid rgba(120,200,255,.35);box-shadow:0 6px 28px rgba(0,0,0,.45),inset 0 0 18px rgba(80,180,255,.12);backdrop-filter:blur(4px);direction:ltr;";
      hud.innerHTML = "<div style='display:flex;justify-content:space-between;align-items:flex-end'><div><span data-k='sp' style='font-size:46px;font-weight:800;letter-spacing:-1px'>0</span><span style='font-size:12px;opacity:.7;margin-left:4px'>km/h</span></div><div style='text-align:right'><div style='font-size:11px;opacity:.65'>GEAR</div><div data-k='gr' style='font-size:34px;font-weight:800;color:#ffb000'>1</div></div></div>"
        + "<div style='margin-top:8px;height:7px;border-radius:4px;background:rgba(255,255,255,.12);overflow:hidden'><div data-k='rpm' style='height:100%;width:0%;background:linear-gradient(90deg,#27e0ff,#ffb000,#ff2a2a)'></div></div>"
        + "<div style='margin-top:7px;display:flex;align-items:center;gap:8px;font-size:11px;opacity:.85'>NITRO<div style='flex:1;height:6px;border-radius:3px;background:rgba(255,255,255,.12);overflow:hidden'><div data-k='nt' style='height:100%;width:100%;background:#1fa3ff'></div></div></div>"
        + "<div data-k='lb' style='margin-top:6px;font-size:11px;text-align:center;opacity:0;transition:opacity .3s;direction:rtl'></div>";
      document.body.appendChild(hud);
      UI.hud = hud;
      UI.speed = hud.querySelector("[data-k='sp']"); UI.gear = hud.querySelector("[data-k='gr']");
      UI.rpm = hud.querySelector("[data-k='rpm']"); UI.nitro = hud.querySelector("[data-k='nt']"); UI.label = hud.querySelector("[data-k='lb']");
    } catch (e) {}
  }
  function uiRemove() {
    try { if (UI.hud && UI.hud.parentNode) UI.hud.parentNode.removeChild(UI.hud); } catch (e) {}
    try { if (UI.fx && UI.fx.parentNode) UI.fx.parentNode.removeChild(UI.fx); } catch (e) {}
    UI.hud = null; UI.fx = null; UI.speed = null; UI.gear = null; UI.rpm = null; UI.nitro = null; UI.label = null; UI.fxKey = "";
  }
  function uiUpdate(dt) {
    if (!UI.fx && !UI.hud) return;
    S.hudT += dt;
    var vk = clamp(Math.abs(S.v) / Math.max(1, PN("maxSpeed", 62)), 0, 1.2);
    if (UI.fx) {
      var a = clamp(smooth(0.35, 1.0, vk) * 0.55 + S.nitroVis * 0.5, 0, 0.9);
      var key = a.toFixed(2) + (S.nitroVis > 0.3 ? "n" : "s");
      if (key !== UI.fxKey) {
        UI.fxKey = key;
        var tint = S.nitroVis > 0.3 ? "rgba(0,170,255," + (0.35 * S.nitroVis).toFixed(2) + ")" : "rgba(0,0,0,0)";
        UI.fx.style.background = "radial-gradient(ellipse at center, rgba(0,0,0,0) 52%, rgba(0,0,0,0.62) 100%)";
        UI.fx.style.boxShadow = "inset 0 0 160px " + tint;
        UI.fx.style.opacity = String(a);
      }
    }
    if (UI.hud && S.hudT >= 0.08) {
      S.hudT = 0;
      if (UI.speed) UI.speed.textContent = String(Math.round(Math.abs(S.v) * 3.6));
      if (UI.gear) UI.gear.textContent = (Math.abs(S.v) < 0.3 && !S.throttle) ? "N" : String(S.gear);
      if (UI.rpm) UI.rpm.style.width = Math.round(clamp(S.rpm01, 0, 1) * 100) + "%";
      if (UI.nitro) { UI.nitro.style.width = Math.round(clamp(S.nitro, 0, 100)) + "%"; UI.nitro.style.background = S.nitroOn ? "#7cf3ff" : "#1fa3ff"; }
      if (UI.label) {
        if (S.camLabelT > 0 && S.t < S.camLabelT) { UI.label.textContent = "الكاميرا: " + CAM_NAMES[S.camMode]; UI.label.style.opacity = "1"; }
        else UI.label.style.opacity = "0";
      }
    }
  }

  
  
  
  var mouse = { down: false, dx: 0, dy: 0, wheel: 0, lastX: null, lastY: null };
  function onMouseDown() { mouse.down = true; mouse.lastX = null; }
  function onMouseUp() { mouse.down = false; mouse.lastX = null; }
  function onMouseMove(e) {
    if (S.mode === "idle") return;
    var locked = (typeof document !== "undefined") && !!document.pointerLockElement;
    if (!locked && !mouse.down) { mouse.lastX = null; return; }
    var mx = e.movementX, my = e.movementY;
    if (mx === undefined || my === undefined) {
      if (mouse.lastX !== null) { mx = e.clientX - mouse.lastX; my = e.clientY - mouse.lastY; } else { mx = 0; my = 0; }
      mouse.lastX = e.clientX; mouse.lastY = e.clientY;
    }
    mouse.dx += mx; mouse.dy += my;
  }
  function onWheel(e) { if (S.mode !== "idle") mouse.wheel += (e.deltaY || 0); }
  if (typeof window !== "undefined" && window.addEventListener) {
    window.addEventListener("mousedown", onMouseDown, true);
    window.addEventListener("mouseup", onMouseUp, true);
    window.addEventListener("mousemove", onMouseMove, true);
    window.addEventListener("wheel", onWheel, { passive: true, capture: true });
  }

  
  
  
  var _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3(), _hipW = new THREE.Vector3(), _orgW = new THREE.Vector3(), _camT = new THREE.Vector3();
  var _gL = new THREE.Vector3(), _gR = new THREE.Vector3(), _pL = new THREE.Vector3(), _pR = new THREE.Vector3(), _rayO = new THREE.Vector3(), _rayD = new THREE.Vector3();
  var _ray = null, LN = null;

  function ensureMatrices() {
    if (S.matFrame === S.frameNo) return;
    S.matFrame = S.frameNo;
    root.updateMatrixWorld(true);
  }
  function playerWorldPos(out) {
    var lp = call("getLocalPlayer");
    if (!lp) return null;
    var m = lp.mesh;
    if (m && typeof m.getWorldPosition === "function") { m.getWorldPosition(out); return out; }
    if (lp.position) { out.set(lp.position.x || 0, lp.position.y || 0, lp.position.z || 0); return out; }
    return null;
  }
  function placePlayer(x, y, z) {
    if (typeof Game.setPlayerPosition === "function") { call("setPlayerPosition", 0, x, y, z, { hold: true }); return; }
    var lp = call("getLocalPlayer");
    if (lp && lp.mesh) lp.mesh.position.set(x, y, z);
  }
  function setPlayerYawSafe(yaw) {
    if (typeof Game.setPlayerYaw === "function") { call("setPlayerYaw", 0, yaw); return; }
    var lp = call("getLocalPlayer");
    if (lp && lp.mesh) lp.mesh.rotation.y = yaw;
  }
  function riderYaw() { return S.yaw + S.yawFix + PN("riderYawOffsetDeg", 0) * PI / 180; }
  function calibrateYaw() {
    if (S.yawFixTries >= 4 || S.t - S.yawFixT < 0.12) return;
    var f = call("getPlayerForward", 0);
    if (!f) return;
    var fx = (f.x !== undefined) ? f.x : f[0];
    var fz = (f.z !== undefined) ? f.z : ((f.y !== undefined && f.length === undefined) ? f.y : f[1]);
    if (!isFinite(fx) || !isFinite(fz) || (Math.abs(fx) + Math.abs(fz)) < 1e-4) return;
    S.yawFixT = S.t;
    var diff = wrap(Math.atan2(-Math.sin(S.yaw), -Math.cos(S.yaw)) - Math.atan2(fx, fz));
    if (Math.abs(diff) > 0.06) { S.yawFix = wrap(S.yawFix + diff); S.yawFixTries++; } else S.yawFixTries = 99;
  }
  function resolveLimbNames() {
    function pick(c) { for (var j = 0; j < c.length; j++) { if (call("getBone", 0, c[j])) return c[j]; } return c[0]; }
    LN = {
      rArm: "rightArm", lArm: "leftArm", rLeg: "rightLeg", lLeg: "leftLeg",
      rFore: pick(["rightForearm", "rightLowerArm", "rightElbow"]), lFore: pick(["leftForearm", "leftLowerArm", "leftElbow"]),
      rShin: pick(["rightShin", "rightLowerLeg", "rightCalf", "rightKnee"]), lShin: pick(["leftShin", "leftLowerLeg", "leftCalf", "leftKnee"]),
      belly: pick(["belly", "spine", "abdomen", "torso"]), chest: pick(["chest", "upperBody", "spine2"]), head: pick(["head"]), outR: -1
    };
    var b = call("getBone", 0, "rightArm");
    if (b && b.position && Math.abs(b.position.x) > 0.02) LN.outR = sgn(b.position.x);
  }
  function limb(name, rx, ry, rz) { call("setPlayerLimb", 0, name, rx, ry, rz, { lock: true }); }
  function limbFree(name) { call("setPlayerLimb", 0, name, 0, 0, 0, { lock: false }); }

  
  var _ik = [0, 0, 0];
  function solveLimb(f, u, lOut, L1, L2, outSign, legMode) {
    var D3 = Math.sqrt(f * f + u * u + lOut * lOut) || 1e-4;
    var D = clamp(D3, Math.abs(L1 - L2) + 0.03, (L1 + L2) * 0.985);
    var A = Math.acos(clamp((L1 * L1 + D * D - L2 * L2) / (2 * L1 * D), -1, 1));
    var E = Math.acos(clamp((L1 * L1 + L2 * L2 - D * D) / (2 * L1 * L2), -1, 1));
    var thetaT = Math.atan2(f, -u);
    var au = legMode ? (thetaT + A) : (thetaT - A);
    _ik[0] = -au;
    _ik[1] = Math.asin(clamp(outSign * lOut / D3, -0.9, 0.9));
    _ik[2] = legMode ? (PI - E) : -(PI - E);
    return _ik;
  }
  function applyRiderPose(blend) {
    if (!LN) resolveLimbNames();
    ensureMatrices();
    var flip = PB("flipArmSide", false) ? -1 : 1, kn = PB("flipKnee", false) ? -1 : 1, fl = PB("flipLean", false) ? -1 : 1;
    var outR = LN.outR * flip, outL = -LN.outR * flip;
    var tuck = S.tuck * blend;
    var psi = S.lean * PN("riderLeanComp", 0.8) * blend;
    var Fx = -Math.sin(S.yaw), Fz = -Math.cos(S.yaw), Rx = Math.cos(S.yaw), Rz = -Math.sin(S.yaw);
    
    var shiftX = -0.10 * clamp(S.lean / Math.max(0.2, PN("maxLeanDeg", 52) * PI / 180), -1, 1) * blend;
    _v1.set(HIP.x + shiftX, HIP.y, HIP.z); chassis.localToWorld(_v1);
    var hx = _v1.x, hy = _v1.y, hz = _v1.z;
    var tl = RIDER.torso, sinT = Math.sin(tuck), cosT = Math.cos(tuck), sinP = Math.sin(psi), cosP = Math.cos(psi);
    var shCx = hx + Fx * tl * sinT - Rx * tl * sinP * cosT, shCy = hy + tl * cosT * cosP, shCz = hz + Fz * tl * sinT - Rz * tl * sinP * cosT;
    gripObjL.getWorldPosition(_gL); gripObjR.getWorldPosition(_gR);
    pegObjL.getWorldPosition(_pL); pegObjR.getWorldPosition(_pR);
    var side, a, dx, dy, dz, tgt, org;
    for (side = 1; side >= -1; side -= 2) {
      tgt = (side > 0) ? _gR : _gL;
      var sX = shCx + Rx * RIDER.shoulderX * side, sY = shCy, sZ = shCz + Rz * RIDER.shoulderX * side;
      dx = tgt.x - sX; dy = tgt.y - sY; dz = tgt.z - sZ;
      a = solveLimb(dx * Fx + dz * Fz, dy, (dx * Rx + dz * Rz) * side, RIDER.upperArm, RIDER.foreArm, (side > 0 ? outR : outL), false);
      var rxA = a[0] + tuck, rzA = a[1], rxF = a[2];
      if (side > 0) { limb(LN.rArm, rxA * blend, 0, rzA * blend); limb(LN.rFore, rxF * blend, 0, 0); }
      else { limb(LN.lArm, rxA * blend, 0, rzA * blend); limb(LN.lFore, rxF * blend, 0, 0); }
      tgt = (side > 0) ? _pR : _pL;
      var hX = hx + Rx * RIDER.hipX * side, hZ = hz + Rz * RIDER.hipX * side;
      dx = tgt.x - hX; dy = tgt.y - hy; dz = tgt.z - hZ;
      a = solveLimb(dx * Fx + dz * Fz, dy, (dx * Rx + dz * Rz) * side, RIDER.thigh, RIDER.shin, (side > 0 ? outR : outL), true);
      if (side > 0) { limb(LN.rLeg, a[0] * blend, 0, a[1] * blend); limb(LN.rShin, a[2] * kn * blend, 0, 0); }
      else { limb(LN.lLeg, a[0] * blend, 0, a[1] * blend); limb(LN.lShin, a[2] * kn * blend, 0, 0); }
    }
    
    limb(LN.belly, -tuck * 0.5, 0, outR * psi * 0.5 * fl);
    limb(LN.chest, -tuck * 0.5, 0, outR * psi * 0.5 * fl);
    limb(LN.head, tuck * 0.75, 0, -outR * psi * 0.7 * fl);
  }
  function releaseRiderPose() {
    if (!LN) return;
    var n = [LN.rArm, LN.lArm, LN.rFore, LN.lFore, LN.rLeg, LN.lLeg, LN.rShin, LN.lShin, LN.belly, LN.chest, LN.head], j;
    for (j = 0; j < n.length; j++) limbFree(n[j]);
  }
  
  function riderOrigin(out) {
    ensureMatrices();
    var shiftX = -0.10 * clamp(S.lean / Math.max(0.2, PN("maxLeanDeg", 52) * PI / 180), -1, 1);
    out.set(HIP.x + shiftX, HIP.y, HIP.z); chassis.localToWorld(out);
    out.y = out.y - RIDER.hipH + PN("riderLift", 0);
    return out;
  }

  
  
  
  function isOwn(o) { while (o) { if (o === root) return true; o = o.parent; } return false; }
  function wallFlag(o) {
    var n = 0;
    while (o && n < 4) {
      var u = o.userData;
      if (u) { if (u.walkable || u.isFloor) return false; if (u.isWall || u.blocksPlayer) return true; }
      o = o.parent; n++;
    }
    return false;
  }
  function rebuildWalls() {
    wallList.length = 0; S.wallT = S.t;
    var sc = Game.scene;
    if (!sc || typeof sc.traverse !== "function") return;
    try { sc.traverse(function (o) { if (o.isMesh && o.visible !== false && !isOwn(o) && wallFlag(o)) wallList.push(o); }); } catch (e) {}
  }
  var RAY_FRONT = [[0, 0.6, -1.75], [-0.25, 0.6, -1.5], [0.25, 0.6, -1.5]];
  var RAY_REAR = [[0, 0.6, 0.95], [-0.2, 0.6, 0.8], [0.2, 0.6, 0.8]];
  function obstacleDistance(dirSign, reach) {
    if (!wallList.length) return Infinity;
    if (!_ray) _ray = new THREE.Raycaster();
    var set = dirSign < 0 ? RAY_FRONT : RAY_REAR, best = Infinity, j, sg = (dirSign < 0 ? 1 : -1);
    _rayD.set(-Math.sin(S.yaw) * sg, 0, -Math.cos(S.yaw) * sg);
    for (j = 0; j < set.length; j++) {
      _rayO.set(set[j][0], set[j][1], set[j][2]); root.localToWorld(_rayO);
      _ray.set(_rayO, _rayD); _ray.near = 0; _ray.far = reach;
      var hits = _ray.intersectObjects(wallList, false);
      if (hits.length && hits[0].distance < best) best = hits[0].distance;
    }
    return best;
  }

  
  
  
  var NOINPUT = { thr: false, brk: false, left: false, right: false, hb: false, nit: false };
  function physicsStep(dt, inp) {
    var maxV = PN("maxSpeed", 62), Pw = PN("power", 210), trac = PN("traction", 9), brakeP = PN("brakePower", 16);
    var eBrake = PN("engineBrake", 3), redline = PN("redlineRpm", 13000), idle = 1300;
    var v = S.v, a = 0, thr = inp.thr ? 1 : 0;
    S.throttle = damp(S.throttle, thr, 9, dt);
    
    var wantNit = inp.nit && thr > 0 && S.nitro > 1;
    S.nitroOn = wantNit;
    S.nitro = clamp(S.nitro + (wantNit ? -PN("nitroDrain", 28) : PN("nitroRegen", 7)) * dt, 0, 100);
    S.nitroVis = damp(S.nitroVis, wantNit ? 1 : 0, 6, dt);
    var boost = 1 + (wantNit ? PN("nitroBoost", 0.45) : 0);
    
    var vg = GEAR_TOP[S.gear - 1] * maxV * (wantNit ? 1.1 : 1);
    if (S.shiftCut > 0) S.shiftCut -= dt;
    if (S.gear < 6 && v > vg * 0.965 && S.shiftCut <= 0) { S.gear++; S.shiftCut = 0.13; S.pop = 0.1; }
    else if (S.gear > 1 && v < GEAR_TOP[S.gear - 2] * maxV * 0.55 && S.shiftCut <= 0) { S.gear--; S.shiftCut = 0.08; }
    vg = GEAR_TOP[S.gear - 1] * maxV;
    var rpmT;
    if (v < 1.2) rpmT = idle + (redline - idle) * 0.55 * S.throttle;
    else rpmT = idle + (redline - idle) * clamp(v / vg, 0, 1.03);
    S.rpm = damp(S.rpm, rpmT, 14, dt);
    S.rpm01 = clamp((S.rpm - idle) / (redline - idle), 0, 1.05);
    var torque = 0.55 + 0.45 * smooth(0.12, 0.62, S.rpm01) * (1 - 0.35 * smooth(0.86, 1.02, S.rpm01));
    
    var drive = 0;
    if (thr > 0 && S.shiftCut <= 0) drive = Math.min(trac, Pw * boost / Math.max(Math.abs(v), 4)) * torque * S.throttle;
    var aero = (Pw / (maxV * maxV * maxV)) * v * Math.abs(v);
    a += drive - aero;
    S.brakeOn = false;
    if (inp.brk) {
      if (v > 0.4) { a -= brakeP; S.brakeOn = true; }
      else { a -= 2.5 * (1 - clamp(-v / 1.5, 0, 1)); S.brakeOn = true; }
    }
    if (inp.hb) { a -= sgn(v) * brakeP * 1.35; S.brakeOn = true; }
    if (!thr && !inp.brk && !inp.hb && Math.abs(v) > 0.1) a -= sgn(v) * (0.35 + eBrake * (0.35 + 0.65 * S.rpm01));
    var nv = v + a * dt;
    if ((inp.brk || inp.hb || !thr) && sgn(nv) !== sgn(v) && v !== 0) nv = 0;
    nv = clamp(nv, -2.5, maxV * 1.25);
    S.accel = (nv - v) / dt;
    S.v = nv;
    
    if (S.prevThr && !inp.thr && S.rpm01 > 0.5 && Math.abs(S.v) > 8) { S.pop = 0.35; audioPop(); }
    S.prevThr = inp.thr;
    if (S.pop > 0) S.pop -= dt;

    
    var maxLean = PN("maxLeanDeg", 52) * PI / 180, steerMax = PN("steerMaxDeg", 26) * PI / 180;
    var sIn = (inp.left ? 1 : 0) - (inp.right ? 1 : 0);
    var spdAbs = Math.abs(S.v);
    S.steerIn = damp(S.steerIn, sIn, sIn === 0 ? 7 : (spdAbs > 25 ? 3.5 : 5.5), dt);
    var wLean = smooth(2.5, 9, spdAbs);
    var leanT = S.steerIn * maxLean * smooth(1.2, 9, spdAbs);
    var leanPrev = S.lean;
    S.lean = damp(S.lean, leanT, PN("leanResponse", 5.5), dt);
    S.leanVel = (S.lean - leanPrev) / dt;
    var deltaLow = S.steerIn * steerMax * (1 - wLean * 0.85);
    var steerT = deltaLow + 0.10 * S.lean - 0.05 * S.leanVel;
    S.steerVis = damp(S.steerVis, clamp(steerT, -steerMax, steerMax), 14, dt);
    var wSteer = (spdAbs / DIM.wheelBase) * Math.tan(deltaLow);
    var wLeanYaw = (spdAbs > 0.5) ? (GRAV * Math.tan(S.lean) / spdAbs) * sgn(S.v) : 0;
    S.yawRate = lerp(wSteer * sgn(S.v), wLeanYaw, wLean);
    S.lat = S.yawRate * S.v;
    S.yaw += S.yawRate * dt;

    
    if (PB("collision", true) && Math.abs(S.v) > 0.5) {
      if (S.t - S.wallT > 3) rebuildWalls();
      S.collT += dt;
      if (S.collT > 0.04) {
        S.collT = 0;
        var dist = obstacleDistance(sgn(S.v) > 0 ? -1 : 1, Math.abs(S.v) * 0.14 + 0.4);
        if (dist < Math.abs(S.v) * 0.09 + 0.2) {
          S.camHit = Math.min(1, Math.abs(S.v) / 25);
          S.v = -S.v * 0.15; S.lean = damp(S.lean, 0, 20, dt);
        }
      }
    }
    var step = S.v * dt;
    root.position.x += -Math.sin(S.yaw) * step;
    root.position.z += -Math.cos(S.yaw) * step;
    root.rotation.y = S.yaw;
  }

  
  function updateVisuals(dt, active) {
    var maxV = Math.max(1, PN("maxSpeed", 62)), vk = clamp(Math.abs(S.v) / maxV, 0, 1.2);
    
    var deployT = (active || Math.abs(S.v) > 0.5) ? 0 : 1;
    S.deploy = damp(S.deploy, deployT, 5, dt);
    var parkLean = PARK_LEAN * S.deploy;
    stand.rotation.x = -1.4 * (1 - S.deploy);
    var leanVis = active ? S.lean : (Math.abs(S.v) > 0.5 ? S.lean : parkLean);
    if (!active && Math.abs(S.v) <= 0.5) S.lean = damp(S.lean, parkLean, 5, dt);
    
    var wheelie = smooth(6.8, 9.2, S.accel) * (1 - smooth(12, 24, Math.abs(S.v))) * PN("wheelieAmount", 0.6) * (S.shiftCut > 0 ? 0.5 : 1);
    var pitchT = clamp(S.accel * 0.0035, -0.07, 0.03) + wheelie * 0.42;
    S.pitch = damp(S.pitch, active ? pitchT : 0, wheelie > 0.1 ? 4 : 8, dt);
    var compT = clamp(-S.accel * 0.0045, -0.02, 0.09) * (1 - wheelie) - wheelie * 0.03 + 0.012;
    S.forkComp = damp(S.forkComp, active ? compT : 0.0, 12, dt);
    var bob = active ? (Math.sin(S.t * 70) * 0.0012 * (0.4 + S.throttle) + Math.sin(S.t * 31) * 0.003 * vk) : 0;
    chassis.rotation.x = S.pitch;
    chassis.rotation.z = leanVis;
    chassis.position.y = bob;
    lowerFork.position.y = S.forkComp;
    steerRot.rotation.y = S.steerVis;
    S.wSpinR -= S.v / DIM.rearR * dt;
    S.wSpinF -= S.v / DIM.frontR * dt;
    wheelR.rotation.x = S.wSpinR; wheelF.rotation.x = S.wSpinF;
    S.throttleVis = damp(S.throttleVis, S.throttle, 12, dt);
    gripGroupR.rotation.x = -S.throttleVis * 0.55;
    
    S.dashT += dt;
    if (TX.dash && S.dashT > 0.1) {
      S.dashT = 0;
      dashState.kmh = Math.abs(S.v) * 3.6; dashState.gear = S.gear; dashState.rpm01 = clamp(S.rpm01, 0, 1);
      dashState.nitro = S.nitro; dashState.nitroOn = S.nitroOn;
      redrawTex(TX.dash);
    }
  }
  
  function measuredVisuals(dt) {
    var dx = root.position.x - S.lastPos.x, dz = root.position.z - S.lastPos.z;
    var v = (dx * (-Math.sin(root.rotation.y)) + dz * (-Math.cos(root.rotation.y))) / dt;
    var yr = wrap(root.rotation.y - S.lastYawM) / dt;
    S.lastPos.copy(root.position); S.lastYawM = root.rotation.y;
    v = clamp(v, -120, 120);
    S.accel = damp(S.accel, (v - S.v) / dt, 10, dt);
    S.v = damp(S.v, v, 12, dt);
    S.yaw = root.rotation.y; S.yawRate = yr; S.lat = yr * S.v;
    var spd = Math.abs(S.v);
    var leanT = (spd > 1.5) ? Math.atan(S.lat / GRAV) : S.lean;
    if (spd <= 1.5) leanT = PARK_LEAN * S.deploy;
    S.lean = damp(S.lean, clamp(leanT, -1.1, 1.1), 10, dt);
    S.steerVis = damp(S.steerVis, clamp(0.10 * S.lean, -0.5, 0.5), 8, dt);
    S.throttle = damp(S.throttle, 0, 6, dt); S.nitroOn = false; S.nitroVis = damp(S.nitroVis, 0, 6, dt);
    S.rpm01 = damp(S.rpm01, 0.1, 4, dt);
    updateVisuals(dt, false);
  }

  
  
  
  function releaseCamera() {
    if (typeof Game.clearCamera === "function") call("clearCamera", 0); else call("setCamera", 0, null);
  }
  var _cb = { x: 0, y: 0, z: 0, w: 1 };
  function quatFromBasis(xx, xy, xz, yx, yy, yz, zx, zy, zz) {
    var tr = xx + yy + zz, s;
    if (tr > 0) { s = 0.5 / Math.sqrt(tr + 1); _cb.w = 0.25 / s; _cb.x = (yz - zy) * s; _cb.y = (zx - xz) * s; _cb.z = (xy - yx) * s; }
    else if (xx > yy && xx > zz) { s = 2 * Math.sqrt(1 + xx - yy - zz); _cb.w = (yz - zy) / s; _cb.x = 0.25 * s; _cb.y = (yx + xy) / s; _cb.z = (zx + xz) / s; }
    else if (yy > zz) { s = 2 * Math.sqrt(1 + yy - xx - zz); _cb.w = (zx - xz) / s; _cb.x = (yx + xy) / s; _cb.y = 0.25 * s; _cb.z = (zy + yz) / s; }
    else { s = 2 * Math.sqrt(1 + zz - xx - yy); _cb.w = (xy - yx) / s; _cb.x = (zx + xz) / s; _cb.y = (zy + yz) / s; _cb.z = 0.25 * s; }
    return _cb;
  }
  
  function lookQuat(ex, ey, ez, tx, ty, tz, roll) {
    var zx = ex - tx, zy = ey - ty, zz = ez - tz, zl = Math.sqrt(zx * zx + zy * zy + zz * zz) || 1;
    zx /= zl; zy /= zl; zz /= zl;
    var xx = zz, xy = 0, xz = -zx, xl = Math.sqrt(xx * xx + xz * xz) || 1;    
    xx /= xl; xz /= xl;
    var yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    var c = Math.cos(roll), s = Math.sin(roll);
    var x2x = xx * c + yx * s, x2y = xy * c + yy * s, x2z = xz * c + yz * s;
    var y2x = -xx * s + yx * c, y2y = -xy * s + yy * c, y2z = -xz * s + yz * c;
    return quatFromBasis(x2x, x2y, x2z, y2x, y2y, y2z, zx, zy, zz);
  }
  function cameraFrame(dt) {
    var sens = PN("camSensitivity", 0.0045), keyRate = PN("camKeySpeed", 1.8), any = false;
    var ck = down("KeyC");
    if (ck && !S.cPrev) { S.camMode = (S.camMode + 1) % 4; S.camLabelT = S.t + 1.6; S.camAzOff = 0; S.camPitch = PN("camHeightDeg", 13) * PI / 180; S.lastCamInput = -99; }
    S.cPrev = ck;
    if (down("ArrowLeft")) { S.camAzOff += keyRate * dt; any = true; }
    if (down("ArrowRight")) { S.camAzOff -= keyRate * dt; any = true; }
    if (down("ArrowUp")) { S.camPitch += keyRate * 0.6 * dt; any = true; }
    if (down("ArrowDown")) { S.camPitch -= keyRate * 0.6 * dt; any = true; }
    if (mouse.dx !== 0 || mouse.dy !== 0) { S.camAzOff -= mouse.dx * sens; S.camPitch += mouse.dy * sens; mouse.dx = 0; mouse.dy = 0; any = true; }
    if (mouse.wheel !== 0) { S.camDistUser = clamp(S.camDistUser * Math.exp(mouse.wheel * 0.0012), 0.4, 2.6); mouse.wheel = 0; any = true; }
    if (any) S.lastCamInput = S.t;
    S.camPitch = clamp(S.camPitch, -0.05, 1.35);
    S.camAzOff = wrap(S.camAzOff);
    var defPitch = PN("camHeightDeg", 13) * PI / 180;
    if (S.t - S.lastCamInput > PN("camRecenterDelay", 2.2) && Math.abs(S.v) > 1.0) {
      S.camAzOff = damp(S.camAzOff, 0, 1.6, dt); S.camPitch = damp(S.camPitch, defPitch, 1.2, dt);
    }
    var maxV = Math.max(1, PN("maxSpeed", 62)), vk = clamp(Math.abs(S.v) / maxV, 0, 1.2);
    S.camYaw = S.camYaw + wrap(S.yaw - S.camYaw) * (1 - Math.exp(-PN("camFollow", 5) * dt));
    ensureMatrices();
    var rollK = PN("camRoll", 0.3), shakeK = PN("camShake", 0.5);
    var ex, ey, ez, tx, ty, tz, roll = 0, fov = PN("camFov", 64) + PN("speedFovBoost", 16) * smooth(0.1, 1.0, vk) + 6 * S.nitroVis, lerpK = clamp(PN("camLerp", 0.45), 0.05, 1);
    var cp, az, dist;
    _camT.set(0, 0.95, -0.4); root.localToWorld(_camT);
    if (S.camMode === 3) {
      
      var shiftX = -0.10 * clamp(S.lean / Math.max(0.2, PN("maxLeanDeg", 52) * PI / 180), -1, 1);
      _v2.set(HIP.x + shiftX, HIP.y + 0.62 * Math.cos(S.tuck) + 0.1, HIP.z - 0.62 * Math.sin(S.tuck) - 0.08); chassis.localToWorld(_v2);
      ex = _v2.x; ey = _v2.y; ez = _v2.z;
      var fx = -Math.sin(S.yaw), fz = -Math.cos(S.yaw);
      tx = ex + fx * 20; ty = ey - 0.9 + S.pitch * 8; tz = ez + fz * 20;
      roll = S.lean * Math.max(0.5, rollK * 2.2); lerpK = 0.9; fov = fov * 0.95;
      var idleVib = 0.0025 + 0.004 * vk;
      ex += (Math.random() - 0.5) * idleVib * shakeK * 2; ey += (Math.random() - 0.5) * idleVib * shakeK * 2;
    } else {
      var distBase = PN("camDistance", 5.2) * S.camDistUser, pitchUse = S.camPitch, azOff = S.camAzOff;
      if (S.camMode === 0) { dist = distBase * (1 + 0.12 * vk); }
      else if (S.camMode === 1) { dist = distBase * 0.62; pitchUse = Math.max(0.0, S.camPitch - 0.17) + 0.04; azOff += 0.5; fov += 12; }
      else { dist = distBase * 1.7; pitchUse = S.camPitch + 0.42; if (Math.abs(S.v) < 3) S.orbitA += dt * 0.28; azOff += S.orbitA; fov -= 4; }
      az = S.camYaw + azOff; cp = Math.cos(pitchUse);
      tx = _camT.x; ty = _camT.y + 0.1; tz = _camT.z;
      ex = tx + Math.sin(az) * cp * dist; ey = ty + Math.sin(pitchUse) * dist; ez = tz + Math.cos(az) * cp * dist;
      ey = Math.max(ey, spawnPos.y + 0.3);
      roll = S.lean * rollK * (S.camMode === 1 ? 0.6 : 0.35);
      var sh = shakeK * (0.003 + 0.03 * vk * vk + 0.02 * S.nitroVis);
      ex += (Math.random() - 0.5) * sh; ey += (Math.random() - 0.5) * sh; ez += (Math.random() - 0.5) * sh;
    }
    if (S.camHit > 0.01) { ex += (Math.random() - 0.5) * 0.4 * S.camHit; ey += (Math.random() - 0.5) * 0.3 * S.camHit; S.camHit = damp(S.camHit, 0, 7, dt); }
    var opts = { x: ex, y: ey, z: ez, lookX: tx, lookY: ty, lookZ: tz, fov: fov, lerp: lerpK };
    if (rollK > 0.001 || S.camMode === 3) {
      var q = lookQuat(ex, ey, ez, tx, ty, tz, roll);
      opts.quat = { x: q.x, y: q.y, z: q.z, w: q.w };
    }
    call("setCamera", 0, opts);
  }

  
  
  
  function setBodyCollision(on) {
    for (var j = 0; j < solidMeshes.length; j++) { solidMeshes[j].userData.noCollision = !on; solidMeshes[j].userData.solid = !!on; }
  }
  function myName() { return String(call("getMyName") || "me"); }
  function startMount() {
    var cur = call("getShared", DRV_KEY, "");
    if (cur && cur !== "" && cur !== myName()) {
      call("subtitle", "🚫 الموتسيكل مشغول — راكب واحد بس");
      return;
    }
    
    call("setShared", DRV_KEY, myName());
    cur = call("getShared", DRV_KEY, "");
    if (cur && cur !== myName()) {
      call("subtitle", "🚫 الموتسيكل مشغول");
      return;
    }
    if (!playerWorldPos(S.mountFrom)) {
      call("setShared", DRV_KEY, "");
      return;
    }
    try { root.userData.netDriver = (typeof Game.getPlayerId === "function" ? Game.getPlayerId() : myName()); } catch (e) {}
    S.lastToggle = S.t; S.mode = "mounting"; S.modeT = 0; S.v = 0; S.coast = false; S.yaw = root.rotation.y; S.camYaw = S.yaw;
    S.camAzOff = 0; S.camPitch = PN("camHeightDeg", 13) * PI / 180; S.camDistUser = 1; S.lastCamInput = -99; S.orbitA = 0;
    S.gear = 1; S.nitro = Math.max(S.nitro, 100); S.tuck = 0.8; S.steerIn = 0; S.steerVis = 0;
    S.yawFixTries = (S.yawFixTries >= 99) ? 99 : 0;
    call("lockPlayer", 0, true);
fitRider();
        call("lockPlayerAnim", 0, true);
    call("setShared", DRV_KEY, myName());
    setBodyCollision(false);
    audioStart(); uiCreate(); rebuildWalls();
    S.fPrev = down("KeyF"); S.cPrev = down("KeyC");
  }
  function startDismount() {
    S.lastToggle = S.t; S.mode = "dismounting"; S.modeT = 0;
    ensureMatrices();
    _v1.set(-0.95, 0, -0.35); root.localToWorld(_v1);
    S.exitPos.set(_v1.x, root.position.y, _v1.z);
  }
  function finishDismount() {
    S.mode = "idle"; S.modeT = 0;
    releaseRiderPose();
    var lp = call("getLocalPlayer"), ex = S.exitPos.x, ey = S.exitPos.y, ez = S.exitPos.z;
    if (typeof Game.teleportPlayer === "function") call("teleportPlayer", 0, ex, ey, ez, { hold: 300, yaw: S.yaw });
    else { call("holdPlayerPosition", 0, false); if (lp && lp.mesh) lp.mesh.position.set(ex, ey, ez); }
    call("holdPlayerPosition", 0, false);
    call("unlockPlayerAnim", 0);
    call("lockPlayer", 0, false);
    releaseCamera();
    call("setShared", DRV_KEY, "");
    try { root.userData.netDriver = null; } catch (e) {}
    if (PB("showHint", true)) call("subtitle", "");
    setBodyCollision(true);
    audioStop(false); uiRemove();
    S.throttle = 0; S.nitroOn = false;
    S.coast = Math.abs(S.v) > 0.05;
    S.lastPos.copy(root.position); S.lastYawM = root.rotation.y;
  }
  function requestToggle() {
    if (S.t - S.lastToggle < 0.45) return;
    if (S.mode === "idle") startMount(); else if (S.mode === "riding") startDismount();
  }
  function forceExit() {
    if (S.mode === "idle") return;
    S.mode = "idle";
    releaseRiderPose();
    call("holdPlayerPosition", 0, false); call("unlockPlayerAnim", 0); call("lockPlayer", 0, false);
    releaseCamera(); call("setShared", DRV_KEY, ""); setBodyCollision(true);
  }

  var interactOK = false;
  if (typeof Game.registerInteractAction === "function") {
    try {
      Game.registerInteractAction(root, {
        id: "bike_ride", label: "اضغط F لركوب الموتسيكل", icon: "🏍️", priority: 5,
        radius: PN("interactRadius", 3),
        onActivate: function () { requestToggle(); }
      });
      interactOK = true;
    } catch (e) { interactOK = false; }
  }

  
  
  
  function idleFrame(dt) {
    var f = down("KeyF");
    if (!interactOK && f && !S.fPrev) {
      var pp = playerWorldPos(_v2);
      if (pp) {
        var dx = pp.x - root.position.x, dz = pp.z - root.position.z;
        if (Math.sqrt(dx * dx + dz * dz) < PN("interactRadius", 3)) requestToggle();
      }
    }
    S.fPrev = f;
    if (S.coast) {
      physicsStep(dt, NOINPUT);
      updateVisuals(dt, false);
      S.lastPos.copy(root.position); S.lastYawM = root.rotation.y;
      if (Math.abs(S.v) < 0.05) { S.v = 0; S.coast = false; }
    } else measuredVisuals(dt);
  }
  function seatPlayer(blend) {
    riderOrigin(_orgW);
    return _orgW;
  }
  function mountFrame(dt) {
    var e = smooth(0, 1, S.modeT / MOUNT_TIME);
    S.steerIn = damp(S.steerIn, 0, 8, dt);
    S.deploy = damp(S.deploy, 0, 4.5, dt);
    physicsStep(dt, NOINPUT);
    S.lean = damp(S.lean, 0, 6, dt);
    updateVisuals(dt, true);
    S.tuck = damp(S.tuck, 0.8, 4, dt);
    seatPlayer(e);
    var px = lerp(S.mountFrom.x, _orgW.x, e), pz = lerp(S.mountFrom.z, _orgW.z, e);
    var py = lerp(S.mountFrom.y, _orgW.y, e) + Math.sin(PI * e) * 0.45;
    placePlayer(px, py, pz);
    if (e > 0.25) setPlayerYawSafe(riderYaw());
    if (e > 0.5) calibrateYaw();
    applyRiderPose(e);
    if (S.modeT >= MOUNT_TIME) {
      S.mode = "riding"; S.modeT = 0; S.lastToggle = S.t;
      if (PB("showHint", true)) {
        call("subtitle", "W غاز · S فرامل · A/D ميل · Space فرامل قوية · Shift نيترو · H كلاكس · C كاميرا · الماوس/الأسهم تدوير · F نزول");
        S.hintT = S.t + 7;
      }
    }
  }
  function ridingFrame(dt) {
    var fk = down("KeyF");
    if (fk && !S.fPrev) requestToggle();
    S.fPrev = fk;
    var hk = down("KeyH");
    if (hk && !S.hPrev) audioHorn();
    S.hPrev = hk;
    if (S.mode !== "riding") return;
    physicsStep(dt, { thr: down("KeyW"), brk: down("KeyS"), left: down("KeyA"), right: down("KeyD"), hb: down("Space"), nit: (down("ShiftLeft") || down("ShiftRight")) });
    
    var vk = clamp(Math.abs(S.v) / Math.max(1, PN("maxSpeed", 62)), 0, 1);
    var tuckT = lerp(0.8, 1.05, smooth(0.08, 0.55, vk)) - (S.brakeOn ? 0.12 : 0);
    S.tuck = damp(S.tuck, tuckT, 4, dt);
    updateVisuals(dt, true);
    seatPlayer(1);
    placePlayer(_orgW.x, _orgW.y, _orgW.z);
    setPlayerYawSafe(riderYaw());
    if (S.modeT < 1.5) calibrateYaw();
    applyRiderPose(1);
    if (S.hintT > 0 && S.t > S.hintT) { S.hintT = -1; call("subtitle", ""); }
  }
  function dismountFrame(dt) {
    var e = smooth(0, 1, S.modeT / DISMOUNT_TIME);
    physicsStep(dt, { thr: false, brk: false, left: false, right: false, hb: true, nit: false });
    updateVisuals(dt, true);
    seatPlayer(1);
    var px = lerp(_orgW.x, S.exitPos.x, e), pz = lerp(_orgW.z, S.exitPos.z, e);
    var py = lerp(_orgW.y, S.exitPos.y, e) + Math.sin(PI * e) * 0.35;
    placePlayer(px, py, pz);
    applyRiderPose(1 - e);
    if (S.modeT >= DISMOUNT_TIME && Math.abs(S.v) < 0.5) finishDismount();
  }

  
  
  
  var _col = new THREE.Color();
  function emitSpark(side) {
    var p = null, j;
    for (j = 0; j < sparks.length; j++) { if (sparks[j].life <= 0) { p = sparks[j]; break; } }
    if (!p) return;
    _v1.set(side * (PEG.x + 0.05), 0.06, PEG.z + 0.05); chassis.localToWorld(_v1);
    p.pos.copy(_v1);
    var bx = Math.sin(S.yaw), bz = Math.cos(S.yaw), rx = Math.cos(S.yaw), rz = -Math.sin(S.yaw);
    p.vel.set(bx * (2 + Math.random() * 4) + rx * side * (1 + Math.random() * 2), 1.5 + Math.random() * 2, bz * (2 + Math.random() * 4) + rz * side * (1 + Math.random() * 2));
    p.life = 0.25 + Math.random() * 0.25; p.mesh.visible = true;
  }
  function updateSparks(dt) {
    var j, p;
    if (S.mode === "riding" && PB("sparks", true)) {
      var lim = PN("maxLeanDeg", 52) * PI / 180 * 0.82;
      if (Math.abs(S.lean) > lim && Math.abs(S.v) > 8) {
        S.sparkT -= dt;
        if (S.sparkT <= 0) { emitSpark(S.lean > 0 ? -1 : 1); emitSpark(S.lean > 0 ? -1 : 1); S.sparkT = 0.03; }
      }
    }
    for (j = 0; j < sparks.length; j++) {
      p = sparks[j];
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.mesh.visible = false; continue; }
      p.vel.y -= 9.8 * dt;
      p.pos.x += p.vel.x * dt; p.pos.y += p.vel.y * dt; p.pos.z += p.vel.z * dt;
      if (p.pos.y < spawnPos.y + 0.01) { p.pos.y = spawnPos.y + 0.01; p.vel.y *= -0.3; }
      _v2.copy(p.pos); root.worldToLocal(_v2); p.mesh.position.copy(_v2);
    }
  }
  function ambient(dt) {
    var active = (S.mode !== "idle");
    var hl = PB("headlights", true) && active;
    if (headSpot) headSpot.intensity = hl ? 3.2 : 0;
    M.lens.emissiveIntensity = hl ? 1.8 : 0.3;
    M.drl.color.set(hl ? 0xffffff : 0x8aa0b0);
    
    var glowOn = PB("glowOn", true);
    M.glow.visible = glowOn;
    if (glowLight) glowLight.intensity = glowOn ? (active ? 1.5 : 0.8) : 0;
    
    M.tail.emissiveIntensity = S.brakeOn ? 2.6 : (active ? 0.9 : 0.3);
    var blink = (Math.floor(S.t * 3) % 2 === 0) ? 1 : 0;
    M.sig.emissiveIntensity = (active && Math.abs(S.steerIn) > 0.45 && Math.abs(S.v) < 14) ? 1.8 * blink : 0.05;
    
    var j, nv = S.nitroVis, pv = clamp(S.pop / 0.35, 0, 1);
    for (j = 0; j < flames.length; j++) {
      var fl = flames[j];
      fl.nitro.visible = nv > 0.05;
      if (fl.nitro.visible) { var fs = (0.6 + 0.8 * nv) * (0.85 + Math.random() * 0.3); fl.nitro.scale.set(0.8 + Math.random() * 0.3, 0.8 + Math.random() * 0.3, fs); }
      fl.pop.visible = pv > 0.05 && Math.random() > 0.25;
      if (fl.pop.visible) { var ps = 0.5 + pv * 0.9; fl.pop.scale.set(0.6, 0.6, ps * (0.7 + Math.random() * 0.6)); }
    }
    updateSparks(dt);
  }

  
  
  
  function netSync(dt) {
    if (S.mode === "idle" && !S.coast) return;
    S.syncT += dt;
    if (S.syncT >= 0.05) { S.syncT = 0; call("syncObject", root); }
  }
  function cleanup() {
    if (S.cleaned) return;
    S.cleaned = true;
    try { forceExit(); } catch (e) {}
    try { audioStop(true); } catch (e) {}
    try { uiRemove(); } catch (e) {}
    try {
      if (typeof window !== "undefined" && window.removeEventListener) {
        window.removeEventListener("mousedown", onMouseDown, true);
        window.removeEventListener("mouseup", onMouseUp, true);
        window.removeEventListener("mousemove", onMouseMove, true);
        window.removeEventListener("wheel", onWheel, true);
      }
    } catch (e) {}
    try { root.position.copy(spawnPos); root.rotation.y = spawnYaw; } catch (e) {}
    try { root.userData.__bikeCleanup = null; } catch (e) {}
  }
  root.userData.__bikeCleanup = cleanup;

  function frame(dt) {
    S.frameNo++;
    refreshParams(dt, false);
    if (S.mode === "idle") idleFrame(dt);
    else if (S.mode === "mounting") mountFrame(dt);
    else if (S.mode === "riding") ridingFrame(dt);
    else if (S.mode === "dismounting") dismountFrame(dt);
    ambient(dt);
    if (S.mode !== "idle") { cameraFrame(dt); S.lastPos.copy(root.position); S.lastYawM = root.rotation.y; }
    uiUpdate(dt);
    netSync(dt);
    audioUpdate(dt);
  }

  refreshParams(0, true);
  S.paramT = 0;
  
  chassis.rotation.z = PARK_LEAN;
  S.lean = PARK_LEAN;

  Game.onUpdate(function (dt) {
    if (!root.parent) { cleanup(); return false; }
    if (S.cleaned) return false;
    dt = (dt > 0) ? Math.min(dt, 0.05) : 0.016;
    S.t += dt;
    S.modeT += dt;
    try { frame(dt); } catch (err) {
      if (!S.errLogged) { S.errLogged = true; try { console.error("bike:", err); } catch (e2) {} }
    }
  });
})(typeof Game !== "undefined" ? Game : null, typeof root !== "undefined" ? root : null);
