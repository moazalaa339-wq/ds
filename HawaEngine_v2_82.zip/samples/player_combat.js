

(function (Game, root) {
  "use strict";
  if (!Game || typeof Game.onUpdate !== "function") {
    try { console.error("weapon: Game.onUpdate missing"); } catch (e) {}
    return;
  }
  var THREE = Game.THREE || (typeof window !== "undefined" ? window.THREE : null);
  if (!THREE) { try { console.error("weapon: THREE missing"); } catch (e) {} return; }
  var scene = Game.scene;
  if (!scene) { try { console.error("weapon: no scene"); } catch (e) {} return; }

  var MAX_HP = 100, DAMAGE = 20, COOLDOWN = 0.25, SPEED = 40;
  var balls = [], hp = MAX_HP, cd = 0, dead = false, deadT = 0, deathPos = null, shotCount = 0;
  var ePrev = false, warnedNet = false;

  var geo = new THREE.SphereGeometry(0.22, 16, 12);
  var matLocal = new THREE.MeshBasicMaterial({ color: 0xffcc00 });
  var matRemote = new THREE.MeshBasicMaterial({ color: 0x00ccff });

  
  var bar = new THREE.Group();
  var barBg = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 0.14), new THREE.MeshBasicMaterial({ color: 0x222222, depthTest: false }));
  var barFill = new THREE.Mesh(new THREE.PlaneGeometry(1.22, 0.1), new THREE.MeshBasicMaterial({ color: 0x33ff66, depthTest: false }));
  barFill.position.z = 0.02;
  bar.add(barBg); bar.add(barFill); bar.renderOrder = 1000; scene.add(bar);

  function call(name) {
    var f = Game[name];
    if (typeof f !== "function") return undefined;
    try { return f.apply(Game, Array.prototype.slice.call(arguments, 1)); } catch (e) { return undefined; }
  }
  function say(t) {
    if (typeof Game.subtitle === "function") call("subtitle", t);
    else try { console.log(t); } catch (e) {}
  }
  function myId() {
    var id = call("getPlayerId");
    return typeof id === "number" ? id : 0;
  }
  function playerPos() {
    var pl = call("getLocalPlayer");
    if (pl && pl.position) return pl.position;
    if (pl && pl.mesh && pl.mesh.position) return pl.mesh.position;
    return null;
  }
  
  function remotePlayers() {
    if (typeof Game.getRemotePlayers === "function") {
      var list = call("getRemotePlayers");
      if (list && list.length) return list;
    }
    if (typeof NetMP !== "undefined" && NetMP && NetMP.remotes) {
      return Array.from(NetMP.remotes.values());
    }
    return [];
  }

  function updateBar() {
    var p = playerPos();
    if (!p) { bar.visible = false; return; }
    bar.visible = !dead;
    bar.position.set(p.x, p.y + 2.2, p.z);
    if (Game.camera) bar.quaternion.copy(Game.camera.quaternion);
    var r = Math.max(0.001, Math.min(1, hp / MAX_HP));
    barFill.scale.x = r;
    barFill.position.x = -0.61 * (1 - r);
    barFill.material.color.setHex(r > 0.5 ? 0x33ff66 : (r > 0.25 ? 0xffcc00 : 0xff3333));
  }

  function spawnBall(x, y, z, dx, dy, dz, local) {
    var mesh = new THREE.Mesh(geo, local ? matLocal : matRemote);
    mesh.position.set(x, y, z);
    scene.add(mesh);
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
    balls.push({ mesh: mesh, vx: dx / len * SPEED, vy: dy / len * SPEED, vz: dz / len * SPEED, life: 1.8, local: !!local, hit: false });
  }

  function shoot() {
    if (dead || cd > 0) return;
    cd = COOLDOWN;
    var p = playerPos();
    if (!p) { say("مفيش لاعب"); return; }
    var ox = p.x, oy = p.y + 1.4, oz = p.z;
    var dx = 0, dy = 0, dz = -1;
    if (Game.camera && typeof Game.camera.getWorldDirection === "function") {
      var dir = new THREE.Vector3();
      Game.camera.getWorldDirection(dir);
      dx = dir.x; dy = dir.y; dz = dir.z;
    } else {
      var fwd = call("getPlayerForward");
      if (fwd) { dx = fwd.x || 0; dz = fwd.z || -1; }
    }
    ox += dx * 0.7; oy += dy * 0.7; oz += dz * 0.7;
    spawnBall(ox, oy, oz, dx, dy, dz, true);
    shotCount++;
    say("⚽ كورة #" + shotCount);
    if (typeof Game.netEvent === "function") {
      Game.netEvent("*", "ball", { o: [ox, oy, oz], d: [dx, dy, dz], from: myId() });
    }
  }

  
  function applyDamage(amount, fromName) {
    if (dead) return;
    hp = Math.max(0, hp - (amount || DAMAGE));
    call("setShared", "hp_slot_" + myId(), hp);
    say("💥 -" + (amount || DAMAGE) + (fromName ? (" من " + fromName) : ""));
    if (hp <= 0) {
      dead = true; deadT = 0;
      var p = playerPos();
      deathPos = p ? { x: p.x, y: p.y, z: p.z } : { x: 0, y: 0, z: 0 };
      say("💀 موت");
      call("setPlayerPosition", 0, deathPos.x, deathPos.y + 16, deathPos.z, {});
    }
  }

  if (typeof Game.onNetEvent === "function") {
    Game.onNetEvent(function (type, payload, from, fromName) {
      payload = payload || {};
      if (type === "hit") {
        
        if (payload.to != null && +payload.to !== myId()) return;
        applyDamage(payload.damage, fromName);
      }
      if (type === "ball" && payload.o && payload.d) {
        spawnBall(payload.o[0], payload.o[1], payload.o[2], payload.d[0], payload.d[1], payload.d[2], false);
      }
    });
  } else if (!warnedNet) {
    warnedNet = true;
    say("⚠ الـ runtime ده مفيهوش أونلاين — الضرر بين اللاعبين هيشتغل في الأونلاين بس");
  }

  if (typeof window !== "undefined") {
    window.__hawaMouseDown = false;
    window.addEventListener("mousedown", function (e) { if (e.button === 0) window.__hawaMouseDown = true; }, true);
    window.addEventListener("mouseup", function (e) { if (e.button === 0) window.__hawaMouseDown = false; }, true);
  }

  Game.onUpdate(function (dt) {
    dt = (dt > 0 && dt < 0.1) ? dt : 0.016;
    if (cd > 0) cd -= dt;

    if (dead) {
      deadT += dt;
      if (deathPos) {
        var t = Math.min(1, deadT / 2);
        call("setPlayerPosition", 0, deathPos.x, deathPos.y + 16 * (1 - t) * (1 - t), deathPos.z, {});
      }
      if (deadT > 2.1) {
        dead = false; hp = MAX_HP;
        call("setShared", "hp_slot_" + myId(), hp);
        if (deathPos) call("setPlayerPosition", 0, deathPos.x, deathPos.y + 0.05, deathPos.z, {});
        say("إعادة ظهور");
      }
    }
    updateBar();

    var remotes = remotePlayers();
    for (var i = balls.length - 1; i >= 0; i--) {
      var b = balls[i];
      
      var steps = Math.max(1, Math.ceil(dt / (1 / 120)));
      var sdt = dt / steps;
      for (var st = 0; st < steps && b.life > 0; st++) {
        var px = b.mesh.position.x, py = b.mesh.position.y, pz = b.mesh.position.z;
        var sx = b.vx * sdt, sy = b.vy * sdt, sz = b.vz * sdt;
        var segLen = Math.sqrt(sx * sx + sy * sy + sz * sz);
        
        var wd = segLen > 0 ? call("hitWorld", px, py, pz, sx, sy, sz, segLen) : null;
        if (wd != null) {
          b.mesh.position.set(px + sx / segLen * wd, py + sy / segLen * wd, pz + sz / segLen * wd);
          b.life = 0;
          break;
        }
        b.mesh.position.x += sx; b.mesh.position.y += sy; b.mesh.position.z += sz;
        b.vy -= 6 * sdt;
        b.life -= sdt;
      }

      
      if (b.local && !b.hit && remotes.length) {
        for (var k = 0; k < remotes.length && !b.hit; k++) {
          var r = remotes[k];
          if (!r || !r.rig || !r.rig.root) continue;
          var box = new THREE.Box3().setFromObject(r.rig.root);
          box.expandByScalar(0.3);
          if (box.containsPoint(b.mesh.position)) {
            b.hit = true;
            b.life = 0.02;
            if (typeof Game.netEvent === "function") {
              Game.netEvent(r.slot, "hit", { damage: DAMAGE, to: r.slot, from: myId() });
            }
            say("🎯 إصابة");
          }
        }
      }

      if (b.life <= 0) {
        try { scene.remove(b.mesh); } catch (e) {}
        balls.splice(i, 1);
      }
    }

    var eDown = false;
    try {
      if (typeof Game.isKeyDown === "function") {
        eDown = !!Game.isKeyDown("KeyE");
        if (Game.isKeyDown("Mouse0")) eDown = true;
      }
    } catch (e) {}
    if (typeof window !== "undefined" && window.__hawaMouseDown) eDown = true;

    if (eDown && !ePrev) shoot();
    if (eDown && ePrev && cd <= 0 && typeof window !== "undefined" && window.__hawaMouseDown) shoot();
    ePrev = eDown;
  });

  say("سلاح جاهز — اضغط E");
})(typeof Game !== "undefined" ? Game : null, typeof root !== "undefined" ? root : null);
