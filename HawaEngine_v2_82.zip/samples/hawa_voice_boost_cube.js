// سكربت: صوت اللاعب يعلى لما يقرب من المكعب
// حط السكربت على المكعب نفسه. اللاعب لازم يفعّل المايك مرة بزر "مايك" (أو game.voice.on()).
const RANGE = 6;        // المسافة (بالوحدات) اللي عندها الصوت يبدأ يعلى
const BOOST_NEAR = 4;   // قوة الصوت جوه المنطقة (1 = عادي، 8 = أقصى حد)
const BOOST_FAR = 1;    // قوة الصوت برا المنطقة
let inside = false;

function onStart(self, game) {
  inside = false;
  game.voice.setBoost(BOOST_FAR);
}

function onUpdate(self, game, dt) {
  if (!game.voice.isOn()) return;           // المايك مش مفعّل
  const c = game.getCoords();               // مكان اللاعب المحلي
  const p = self.position;                  // مكان المكعب
  const d = Math.hypot(c.x - p.x, c.z - p.z);
  const near = d < RANGE;
  if (near !== inside) {
    inside = near;
    game.voice.setBoost(near ? BOOST_NEAR : BOOST_FAR);
  }
}

function onTouch(self, game, dt) {}
