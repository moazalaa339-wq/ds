// ===== مثال: عدد العربيات يحدد عدد البارامترات تلقائياً =====
// زوّد "عدد العربيات" في لوحة البارامترات، وهتظهر تلقائياً خانات:
// لون العربية 1..N ، مكان العربية 1..N (X/Y/Z) ، ملف صوت/صورة لكل عربية لو عايز.
Game.defineParams([
  { key: "carCount", label: "عدد العربيات", type: "number", value: 3, min: 0, max: 16, step: 1, count: true },
  { key: "carColor", label: "لون العربية", type: "color", value: "#e74c3c", each: "carCount" },
  { key: "carPos", label: "مكان العربية (م)", type: "vec3", value: [0, 0.5, 0], each: "carCount" },
  { key: "carSpeed", label: "سرعة العربية", type: "number", value: 4, min: 0, max: 30, step: 0.5, each: "carCount" }
]);

var cars = [];

function P(k, d) { var v = Game.params ? Game.params[k] : undefined; return v == null ? d : v; }

function buildCars() {
  var T = Game.THREE;
  cars.forEach(function (c) { Game.scene.remove(c.mesh); });
  cars = [];
  var n = Math.max(0, Math.round(+P("carCount", 0)));
  for (var i = 1; i <= n; i++) {
    var color = P("carColor_" + i, "#e74c3c");
    var pos = P("carPos_" + i, [i * 3, 0.5, 0]);
    var mesh = new T.Group();
    var body = new T.Mesh(new T.BoxGeometry(2, 0.8, 1), new T.MeshStandardMaterial({ color: color }));
    body.position.y = 0.4;
    var cabin = new T.Mesh(new T.BoxGeometry(1.1, 0.6, 0.9), new T.MeshStandardMaterial({ color: color }));
    cabin.position.set(-0.2, 1.1, 0);
    mesh.add(body, cabin);
    mesh.position.set(pos[0], pos[1], pos[2]);
    Game.scene.add(mesh);
    cars.push({ mesh: mesh, idx: i });
  }
}

var lastKey = "";
Game.onUpdate(function (dt) {
  // نعيد البناء لو تغيّر العدد أو لون/مكان أي عربية
  var key = JSON.stringify(Game.params || {});
  if (key === lastKey) return;
  lastKey = key;
  buildCars();
});
