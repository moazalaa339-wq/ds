(function (Game, root) {
  "use strict";
  if (!Game || !root) return;
  var THREE = Game.THREE || (typeof window !== "undefined" ? window.THREE : null);
  if (!THREE) return;

  
  Game.defineParams([
    { key: "bodyColor", label: "لون العربية", type: "color", value: "#c0392b" },
    { key: "maxSpeed", label: "أقصى سرعة (م/ث)", type: "number", value: 14, min: 4, max: 40, step: 1 },
    { key: "accel", label: "التسارع (م/ث²)", type: "number", value: 8, min: 2, max: 30, step: 1 },
    { key: "steerDeg", label: "أقصى انحناء للعجل (درجة)", type: "number", value: 32, min: 10, max: 50, step: 1 }
  ]);
  function P(k, d) { var v = Game.params && Game.params[k]; return v === undefined ? d : v; }

  root.userData.customDrive = true;

  
  var dims = null;
  try { dims = Game.getPlayerDims && Game.getPlayerDims(0); } catch (e) {}
  var sit = (dims && dims.sit) || { headAboveSeat: 0.86, kneeForward: 0.31, feetBelowSeat: 0.26, width: 0.57 };

  
  var FLOOR_Y = 0.30;                               
  var SEAT_TOP = FLOOR_Y + sit.feetBelowSeat;       
  var SEAT_X = -0.45, SEAT_Z = -0.25;               
  var ROOF_Y = SEAT_TOP + sit.headAboveSeat + 0.12; 
  var DASH_Z = SEAT_Z + sit.kneeForward + 0.22;     
  var L = 3.4, W = 1.75, WHEEL_R = 0.33, AXLE_F = 1.15, AXLE_R = -1.1;

  var mats = {
    body: new THREE.MeshStandardMaterial({ color: P("bodyColor", "#c0392b"), roughness: 0.4, metalness: 0.5 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: 0.8, metalness: 0.1 }),
    seat: new THREE.MeshStandardMaterial({ color: 0x2a1d17, roughness: 0.7 }),
    glass: new THREE.MeshStandardMaterial({ color: 0x9fd8ff, roughness: 0.1, metalness: 0.3, transparent: true, opacity: 0.35 })
  };
  function box(w, h, d, m, x, y, z, par) {
    var me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    me.position.set(x, y, z); me.castShadow = true; me.receiveShadow = true;
    (par || root).add(me); return me;
  }

  
  box(W, 0.10, L, mats.body, 0, FLOOR_Y - 0.05, 0);
  box(W, 0.32, 0.9, mats.body, 0, FLOOR_Y + 0.16, L / 2 - 0.45);        
  box(W, 0.45, 0.8, mats.body, 0, FLOOR_Y + 0.22, -L / 2 + 0.4);        
  box(0.08, 0.35, L, mats.body, -W / 2 + 0.04, FLOOR_Y + 0.17, 0);      
  box(0.08, 0.35, L, mats.body, W / 2 - 0.04, FLOOR_Y + 0.17, 0);       
  box(W, 0.45, 0.1, mats.dark, 0, FLOOR_Y + 0.22, L / 2);               
  box(W, 0.45, 0.1, mats.dark, 0, FLOOR_Y + 0.22, -L / 2);

  
  [-0.45, 0.45].forEach(function (sx) {
    box(0.55, 0.10, 0.50, mats.seat, sx, SEAT_TOP - 0.05, SEAT_Z);                
    box(0.55, 0.62, 0.10, mats.seat, sx, SEAT_TOP + 0.31, SEAT_Z - 0.30);         
  });

  
  box(W - 0.2, 0.30, 0.18, mats.dark, 0, SEAT_TOP + 0.25, DASH_Z + 0.09);
  var wheelG = new THREE.Group();
  wheelG.position.set(SEAT_X, SEAT_TOP + 0.42, DASH_Z - 0.10);
  wheelG.rotation.x = -0.9;
  var ring = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.025, 8, 24), mats.dark);
  wheelG.add(ring); root.add(wheelG);

  
  [[-W / 2 + 0.05, -0.85], [W / 2 - 0.05, -0.85], [-W / 2 + 0.05, DASH_Z + 0.05], [W / 2 - 0.05, DASH_Z + 0.05]].forEach(function (p) {
    box(0.07, ROOF_Y - FLOOR_Y, 0.07, mats.body, p[0], (ROOF_Y + FLOOR_Y) / 2, p[1]);
  });
  box(W, 0.07, (DASH_Z + 0.05) - (-0.85) + 0.3, mats.body, 0, ROOF_Y, (DASH_Z - 0.85) / 2);
  box(W - 0.15, ROOF_Y - SEAT_TOP - 0.55, 0.04, mats.glass, 0, SEAT_TOP + 0.55 + (ROOF_Y - SEAT_TOP - 0.55) / 2, DASH_Z + 0.05);

  
  var wheels = [];
  [[-1, AXLE_F, true], [1, AXLE_F, true], [-1, AXLE_R, false], [1, AXLE_R, false]].forEach(function (c) {
    var pivot = new THREE.Group();
    pivot.position.set(c[0] * (W / 2 + 0.02), WHEEL_R, c[1]);
    var tire = new THREE.Mesh(new THREE.CylinderGeometry(WHEEL_R, WHEEL_R, 0.22, 20), mats.dark);
    tire.rotation.z = Math.PI / 2; tire.castShadow = true;
    var hub = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.235, 12), new THREE.MeshStandardMaterial({ color: 0xcfd3d8, metalness: 0.8, roughness: 0.3 }));
    hub.rotation.z = Math.PI / 2;
    tire.add(hub); pivot.add(tire); root.add(pivot);
    wheels.push({ pivot: pivot, tire: tire, front: c[2] });
  });

  
  var driving = false, v = 0, steer = 0, tmp = new THREE.Vector3();
  var ARMS = [["rArm", -1.15, 0.12], ["lArm", -1.15, -0.12], ["rForearm", -0.35, 0], ["lForearm", -0.35, 0]];

  function key(a, b) { return Game.isKeyDown(a) || (b && Game.isKeyDown(b)); }

  function seatWorld(out) {
    root.updateMatrixWorld(true);
    out.set(SEAT_X, SEAT_TOP, SEAT_Z);
    return root.localToWorld(out);
  }
  function enter() {
    driving = true; v = 0;
    Game.lockPlayer(0, true);
    seatWorld(tmp);
    Game.seatPlayer(0, tmp.x, tmp.y, tmp.z, { yaw: root.rotation.y });
    ARMS.forEach(function (a) { Game.setPlayerLimb(0, a[0], a[1], 0, a[2], { lock: true }); });
    if (Game.subtitle) Game.subtitle("W/S تسارع · A/D توجيه · Space فرامل · F نزول");
  }
  function leave() {
    driving = false; v = 0;
    ARMS.forEach(function (a) { Game.setPlayerLimb(0, a[0], 0, 0, 0, { lock: false }); });
    tmp.set(-W / 2 - 0.9, 0, SEAT_Z); root.updateMatrixWorld(true); root.localToWorld(tmp);
    Game.unseatPlayer(0, tmp.x, root.position.y, tmp.z);
    Game.lockPlayer(0, false);
  }
  Game.registerInteractAction(root, {
    radius: 3.2, label: "ركوب / نزول العربية",
    onActivate: function () { if (driving) leave(); else enter(); }
  });

  
  var syncT = 0;
  Game.onUpdate(function (dt) {
    dt = Math.min(dt, 0.05);
    if (driving) {
      var maxV = P("maxSpeed", 14), acc = P("accel", 8);
      var thr = (key("KeyW", "ArrowUp") ? 1 : 0) - (key("KeyS", "ArrowDown") ? 1 : 0);
      var st = (key("KeyD", "ArrowRight") ? 1 : 0) - (key("KeyA", "ArrowLeft") ? 1 : 0);
      if (thr) v += thr * acc * dt; else v -= Math.sign(v) * Math.min(Math.abs(v), 3 * dt);
      if (key("Space")) v -= Math.sign(v) * Math.min(Math.abs(v), 16 * dt);
      v = Math.max(-maxV * 0.4, Math.min(maxV, v));
      steer += (st * P("steerDeg", 32) * Math.PI / 180 - steer) * Math.min(1, dt * 8);

      var yaw = root.rotation.y;
      var dx = Math.sin(yaw), dz = Math.cos(yaw);
      
      if (Math.abs(v) > 0.1 && Game.hitWorld) {
        var dir = Math.sign(v), reach = L / 2 + 0.3 + Math.abs(v) * dt;
        var h = Game.hitWorld(root.position.x, root.position.y + 0.6, root.position.z, dx * dir, 0, dz * dir, reach);
        if (h != null) v = 0;
      }
      root.rotation.y += (v / (AXLE_F - AXLE_R)) * Math.tan(steer) * dt;   
      root.position.x += Math.sin(root.rotation.y) * v * dt;
      root.position.z += Math.cos(root.rotation.y) * v * dt;

      
      seatWorld(tmp);
      Game.seatPlayer(0, tmp.x, tmp.y, tmp.z, { yaw: root.rotation.y });
      wheelG.rotation.z = -steer * 2.2;

      syncT += dt;
      if (syncT > 0.05) { syncT = 0; if (Game.syncObject) Game.syncObject(root); }
    }
    
    wheels.forEach(function (w) {
      w.tire.rotation.x += (v / WHEEL_R) * dt;
      if (w.front) w.pivot.rotation.y = steer;
    });
  });
})(Game, root);
