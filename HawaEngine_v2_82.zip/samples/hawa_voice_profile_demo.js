// ===== مثال: التحكم في صوت لاعب معيّن بالسلوت (رقم اللاعب) =====
// السلوت 1 = أول لاعب أونلاين، وهكذا. البروفايل بيتربط باللاعب (اسمه/سلوته) ومش بيتخلط مع غيره.
Game.defineParams([
  { key: "slot", label: "رقم اللاعب (سلوت)", type: "number", value: 1, min: 0, max: 8, step: 1 },
  { key: "volume", label: "مستوى الصوت (0 - 4)", type: "number", value: 1.5, min: 0, max: 4, step: 0.1 },
  { key: "pan", label: "توزيع يمين/شمال (-1 شمال .. 1 يمين)", type: "number", value: 0, min: -1, max: 1, step: 0.1 },
  { key: "eqLow", label: "قاع (ديسيبل)", type: "number", value: 6, min: -12, max: 12, step: 1 },
  { key: "eqMid", label: "وسط (ديسيبل)", type: "number", value: 0, min: -12, max: 12, step: 1 },
  { key: "eqHigh", label: "حدّة (ديسيبل)", type: "number", value: -4, min: -12, max: 12, step: 1 },
  { key: "echoOn", label: "صدى", type: "boolean", value: true },
  { key: "echoTime", label: "مدة الصدى (ثانية)", type: "number", value: 0.3, min: 0.05, max: 1.5, step: 0.05 },
  { key: "echoFeedback", label: "تكرار الصدى", type: "number", value: 0.4, min: 0, max: 0.9, step: 0.05 },
  { key: "echoMix", label: "قوة الصدى", type: "number", value: 0.35, min: 0, max: 1, step: 0.05 },
  { key: "spatial", label: "صوت مكاني (يجي من مكان اللاعب)", type: "boolean", value: true },
  { key: "fixedPos", label: "مكان ثابت للصوت بدل مكان اللاعب", type: "boolean", value: false },
  { key: "posX", label: "X (م)", type: "number", value: 0, min: -100, max: 100, step: 0.5 },
  { key: "posY", label: "Y (م)", type: "number", value: 1.5, min: -10, max: 50, step: 0.5 },
  { key: "posZ", label: "Z (م)", type: "number", value: 0, min: -100, max: 100, step: 0.5 }
]);

function P(k, d) { var v = Game.params ? Game.params[k] : undefined; return v == null ? d : v; }

var applied = false;
Game.onUpdate(function (dt) {
  if (applied) return;
  applied = true;
  var slot = P("slot", 1);
  Game.voice.setProfile(slot, {
    volume: P("volume", 1.5),
    pan: P("pan", 0),
    eq: { low: P("eqLow", 6), mid: P("eqMid", 0), high: P("eqHigh", -4) },
    echo: { on: P("echoOn", true), time: P("echoTime", 0.3), feedback: P("echoFeedback", 0.4), mix: P("echoMix", 0.35) },
    spatial: P("spatial", true),
    pos: P("fixedPos", false) ? { x: P("posX", 0), y: P("posY", 1.5), z: P("posZ", 0) } : null
  });
});
