(function (Game, root) {
  "use strict";
  if (!Game || !root) return;
  var THREE = Game.THREE || (typeof window !== "undefined" ? window.THREE : null);
  if (!THREE) return;
  if (typeof Game.onUpdate !== "function") return;

  var OBJECT_NAME = "توك_توك";
  try { root.userData.instanceName = OBJECT_NAME; } catch (e) {}
  root.userData.forceMeshCollision = true;
  root.userData.customDrive = true;
  try { if (typeof root.userData.__tukCleanup === "function") root.userData.__tukCleanup(); } catch (e) {}

  
  
  
  if (typeof Game.defineParams === "function") {
    Game.defineParams([
      { key: "bodyColor", label: "لون الهيكل", type: "color", value: "#1e9e55" },
      { key: "roofColor", label: "لون السقف", type: "color", value: "#f4c20d" },
      { key: "accentColor", label: "لون الزخارف", type: "color", value: "#d62839" },
      { key: "ledColor", label: "لون إضاءة الليد", type: "color", value: "#00e5ff" },
      { key: "ledRainbow", label: "ليد بألوان متغيرة", type: "boolean", value: true },
      { key: "bannerText", label: "كتابة الزجاج الأمامي", type: "text", value: "ما شاء الله" },
      { key: "plateText", label: "رقم اللوحة", type: "text", value: "توك توك ١٢٣٤" },

      { key: "maxSpeed", label: "السرعة القصوى (م/ث)", type: "number", value: 18, min: 5, max: 45, step: 0.5 },
      { key: "reverseMaxSpeed", label: "سرعة الرجوع القصوى (م/ث)", type: "number", value: 5, min: 1, max: 15, step: 0.5 },
      { key: "accel", label: "التسارع (م/ث²)", type: "number", value: 6.5, min: 1, max: 20, step: 0.5 },
      { key: "brakePower", label: "قوة الفرامل (م/ث²)", type: "number", value: 15, min: 3, max: 40, step: 1 },
      { key: "handbrakePower", label: "قوة فرامل اليد (م/ث²)", type: "number", value: 24, min: 5, max: 50, step: 1 },
      { key: "rolling", label: "احتكاك الأرض (م/ث²)", type: "number", value: 1.4, min: 0, max: 6, step: 0.1 },
      { key: "drag", label: "مقاومة الهواء (1/ث)", type: "number", value: 0.12, min: 0, max: 1, step: 0.01 },
      { key: "steerMaxDeg", label: "أقصى زاوية للعجلة الأمامية (درجة)", type: "number", value: 36, min: 10, max: 55, step: 1 },
      { key: "steerResponse", label: "سرعة استجابة التوجيه (1/ث)", type: "number", value: 7, min: 1, max: 20, step: 0.5 },
      { key: "maxLateralAccel", label: "أقصى تسارع جانبي (م/ث²)", type: "number", value: 9, min: 3, max: 25, step: 0.5 },
      { key: "leanAmount", label: "ميل الهيكل في المنعطف (راديان لكل م/ث²)", type: "number", value: 0.009, min: 0, max: 0.03, step: 0.001 },
      { key: "suspensionRate", label: "سرعة رد فعل التعليق (1/ث)", type: "number", value: 9, min: 2, max: 25, step: 0.5 },
      { key: "collision", label: "التصادم مع الحوائط", type: "boolean", value: true },

      { key: "camDistance", label: "مسافة الكاميرا (م)", type: "number", value: 6.5, min: 2.5, max: 16, step: 0.5 },
      { key: "camHeightDeg", label: "ارتفاع الكاميرا الافتراضي (درجة)", type: "number", value: 16, min: -2, max: 80, step: 1 },
      { key: "camFov", label: "زاوية الرؤية (درجة)", type: "number", value: 62, min: 35, max: 100, step: 1 },
      { key: "speedFovBoost", label: "زيادة الزاوية عند السرعة (درجة)", type: "number", value: 8, min: 0, max: 25, step: 1 },
      { key: "camSensitivity", label: "حساسية الماوس (راديان/بكسل)", type: "number", value: 0.0045, min: 0.001, max: 0.015, step: 0.0005 },
      { key: "camKeySpeed", label: "سرعة تدوير الكاميرا بالأسهم (راديان/ث)", type: "number", value: 1.8, min: 0.5, max: 5, step: 0.1 },
      { key: "camFollow", label: "سرعة تتبع الكاميرا للاتجاه (1/ث)", type: "number", value: 4.5, min: 1, max: 15, step: 0.5 },
      { key: "camRecenterDelay", label: "مهلة رجوع الكاميرا للخلف (ث)", type: "number", value: 2.5, min: 0.5, max: 10, step: 0.5 },
      { key: "camLerp", label: "نعومة الكاميرا (0-1)", type: "number", value: 0.4, min: 0.05, max: 1, step: 0.05 },
      { key: "roofFade", label: "تشفيف السقف لما الكاميرا تعلى", type: "boolean", value: true },

      { key: "interactRadius", label: "مسافة الركوب (م)", type: "number", value: 3.4, min: 1.5, max: 8, step: 0.1 },
      { key: "headlights", label: "كشافات التوك توك", type: "boolean", value: true },
      { key: "soundOn", label: "صوت الموتور والكلاكس", type: "boolean", value: true },
      { key: "soundVolume", label: "مستوى الصوت (0-1)", type: "number", value: 0.5, min: 0, max: 1, step: 0.05 },
      { key: "showHint", label: "إظهار تعليمات التحكم عند الركوب", type: "boolean", value: true },

      { key: "riderLift", label: "ضبط ارتفاع الراكب (م)", type: "number", value: 0, min: -0.3, max: 0.3, step: 0.01 },
      { key: "flipArmSide", label: "عكس ميل الذراعين جانبياً", type: "boolean", value: false },
      { key: "flipKnee", label: "عكس ثني الركبة", type: "boolean", value: false },
      { key: "riderYawOffsetDeg", label: "تعديل اتجاه الراكب (درجة)", type: "number", value: 0, min: -180, max: 180, step: 15 }
    ]);
  }

  function PR(key) { var p = Game.params; return p ? p[key] : undefined; }
  function PN(key, def) {
    var v = PR(key);
    if (v === undefined || v === null || v === "") return def;
    v = Number(v);
    return isFinite(v) ? v : def;
  }
  function PB(key, def) {
    var v = PR(key);
    if (v === undefined || v === null) return def;
    if (typeof v === "string") return v === "true" || v === "1";
    return !!v;
  }
  function PS(key, def) {
    var v = PR(key);
    return (v === undefined || v === null || v === "") ? def : String(v);
  }

  
  function call(name) {
    var f = Game[name];
    if (typeof f !== "function") return undefined;
    try { return f.apply(Game, Array.prototype.slice.call(arguments, 1)); } catch (e) { return undefined; }
  }
  function down(code) { return !!call("isKeyDown", code); }

  
  
  
  var PI = Math.PI, TAU = Math.PI * 2;
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function damp(cur, target, rate, dt) { return cur + (target - cur) * (1 - Math.exp(-rate * dt)); }
  function wrap(a) { while (a > PI) a -= TAU; while (a < -PI) a += TAU; return a; }
  function smooth(e0, e1, x) { var t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); }
  function sgn(x) { return x < 0 ? -1 : (x > 0 ? 1 : 0); }

  
  
  
  var DIM = {
    wheelBase: 2.0,
    rearR: 0.33, rearW: 0.20, rearX: 0.70,
    frontR: 0.31, frontW: 0.17, frontZ: -2.0
  };
  var BAR = { x: 0, y: 1.22, z: -0.82 };      
  var GRIP = { x: 0.37, y: 0, z: 0.06 };      
  var SEAT = { x: 0, y: 0, z: -0.30 };        
  var RIDER = {
    shoulderX: 0.20, shoulderY: 1.50,
    upperArm: 0.31, foreArm: 0.29,
    thighRx: -1.45, shinRx: 1.50, kneeSpread: 0.10
  };
  var MOUNT_TIME = 0.8, DISMOUNT_TIME = 0.7, BAR_RATIO = 0.58;

  
  
  
  var S = {
    mode: "idle", t: 0, modeT: 0, lastToggle: -99, cleaned: false, errLogged: false,
    v: 0, yaw: root.rotation.y, steerIn: 0, steerVis: 0, steerEff: 0, yawRate: 0, accel: 0, lat: 0,
    pitch: 0, roll: 0, wSpinR: 0, wSpinF: 0, barAngle: 0, throttleVis: 0,
    brakeOn: false, reverseOn: false, throttleOn: false,
    camAzOff: 0, camPitch: PN("camHeightDeg", 16) * PI / 180, camDistUser: 1, camYaw: root.rotation.y, lastCamInput: -99, camShake: 0,
    paramT: 1, hintT: -1, driver: "", yawFix: 0, yawFixTries: 0, yawFixT: 0,
    mountFrom: new THREE.Vector3(), exitPos: new THREE.Vector3(), blend: 0,
    fPrev: false, hPrev: false, collT: 0, wallT: -99, lastPos: new THREE.Vector3(), lastYawMeasured: root.rotation.y, syncT: 0,
    smokeT: 0, matFrame: -1, frameNo: 0, coast: false
  };
  var spawnPos = root.position.clone();
  var spawnYaw = root.rotation.y;
  var DRV_KEY = "tuk_driver_" + (root.uuid || "x");
  S.lastPos.copy(root.position);

  
  
  
  function stdMat(color, rough, metal, extra) {
    var o = { color: color, roughness: rough, metalness: metal };
    if (extra) { for (var k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) o[k] = extra[k]; } }
    return new THREE.MeshStandardMaterial(o);
  }
  var M = {
    body: stdMat(0x1e9e55, 0.34, 0.15, { side: THREE.DoubleSide }),
    roof: stdMat(0xf4c20d, 0.38, 0.12, { transparent: true, opacity: 1 }),
    accent: stdMat(0xd62839, 0.45, 0.1),
    cream: stdMat(0xf3e9cf, 0.8, 0.02),
    chrome: stdMat(0xdfe6ee, 0.22, 0.6, { emissive: 0x222a33, emissiveIntensity: 0.6 }),
    darkMetal: stdMat(0x2a2e33, 0.5, 0.6),
    rubber: stdMat(0x131313, 0.95, 0.05),
    mat: stdMat(0x1b1b1b, 0.98, 0.0),
    seat: stdMat(0x2b1a12, 0.75, 0.05),
    fabric: stdMat(0x2f5aa8, 0.95, 0.0),
    wood: stdMat(0x6a4326, 0.8, 0.05),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xaee0ff, roughness: 0.05, metalness: 0.0, transparent: true, opacity: 0.26, side: THREE.DoubleSide, depthWrite: false }),
    mirror: stdMat(0xcfe8ff, 0.05, 0.9, { emissive: 0x334455, emissiveIntensity: 0.5 }),
    head: stdMat(0xffffff, 0.1, 0.1, { emissive: 0xfff0c0, emissiveIntensity: 1.3 }),
    tail: stdMat(0x7a0000, 0.3, 0.2, { emissive: 0xff1010, emissiveIntensity: 0.4 }),
    rev: stdMat(0xdddddd, 0.3, 0.2, { emissive: 0xffffff, emissiveIntensity: 0.05 }),
    sigL: stdMat(0x6b4a00, 0.3, 0.2, { emissive: 0xffa800, emissiveIntensity: 0.05 }),
    sigR: stdMat(0x6b4a00, 0.3, 0.2, { emissive: 0xffa800, emissiveIntensity: 0.05 }),
    led: new THREE.MeshBasicMaterial({ color: 0x00e5ff }),
    spkLed: new THREE.MeshBasicMaterial({ color: 0x00e5ff }),
    spkCone: stdMat(0x0d0d0d, 0.7, 0.1),
    rimPaint: stdMat(0xd62839, 0.4, 0.2),
    smoke: stdMat(0x9a9a9a, 1.0, 0.0, { transparent: true, opacity: 0.3, depthWrite: false })
  };

  
  function canvasTex(w, h, draw) {
    if (typeof document === "undefined") return null;
    try {
      var c = document.createElement("canvas");
      c.width = w; c.height = h;
      var ctx = c.getContext("2d");
      if (!ctx) return null;
      draw(ctx, w, h);
      var t = new THREE.CanvasTexture(c);
      if (THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
      else if (THREE.sRGBEncoding !== undefined) t.encoding = THREE.sRGBEncoding;
      t.anisotropy = 4;
      return { tex: t, canvas: c, draw: draw };
    } catch (e) { return null; }
  }
  function redrawTex(o) {
    if (!o) return;
    try {
      var ctx = o.canvas.getContext("2d");
      ctx.clearRect(0, 0, o.canvas.width, o.canvas.height);
      o.draw(ctx, o.canvas.width, o.canvas.height);
      o.tex.needsUpdate = true;
    } catch (e) {}
  }
  function texMat(o, fallback, extra) {
    var p = { color: o ? 0xffffff : fallback, roughness: 0.6, metalness: 0.05 };
    if (o) p.map = o.tex;
    if (extra) { for (var k in extra) { if (Object.prototype.hasOwnProperty.call(extra, k)) p[k] = extra[k]; } }
    return new THREE.MeshStandardMaterial(p);
  }

  var TX = {};
  TX.plate = canvasTex(256, 128, function (ctx, w, h) {
    ctx.fillStyle = "#f2f2ec"; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#15305a"; ctx.lineWidth = 8; ctx.strokeRect(6, 6, w - 12, h - 12);
    ctx.fillStyle = "#15305a"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 30px sans-serif"; ctx.fillText("مصر", w / 2, h * 0.24);
    ctx.font = "bold 54px sans-serif"; ctx.fillText(PS("plateText", "توك توك ١٢٣٤"), w / 2, h * 0.66, w - 28);
  });
  TX.banner = canvasTex(512, 64, function (ctx, w, h) {
    ctx.fillStyle = "#7a0f1c"; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#ffd25a"; ctx.fillRect(0, 4, w, 3); ctx.fillRect(0, h - 7, w, 3);
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 40px sans-serif"; ctx.fillStyle = "#ffe08a";
    ctx.fillText(PS("bannerText", "ما شاء الله"), w / 2, h / 2 + 2, w - 40);
  });
  TX.side = canvasTex(256, 64, function (ctx, w, h) {
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 44px sans-serif";
    ctx.lineWidth = 6; ctx.strokeStyle = "#101010"; ctx.strokeText("توك توك", w / 2, h / 2);
    ctx.fillStyle = "#ffd25a"; ctx.fillText("توك توك", w / 2, h / 2);
  });
  TX.dial = canvasTex(256, 256, function (ctx, w, h) {
    var cx = w / 2, cy = h / 2, r = w * 0.46, i, k, a, x1, y1, x2, y2;
    ctx.fillStyle = "#0b0d10"; ctx.beginPath(); ctx.arc(cx, cy, r + 8, 0, TAU); ctx.fill();
    ctx.fillStyle = "#16202a"; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = "#e8e8e8"; ctx.fillStyle = "#e8e8e8"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 22px sans-serif";
    for (i = 0; i <= 8; i++) {
      k = i / 8; a = 2.094 - 4.189 * k;
      x1 = cx - Math.sin(a) * r * 0.86; y1 = cy - Math.cos(a) * r * 0.86;
      x2 = cx - Math.sin(a) * r * 0.98; y2 = cy - Math.cos(a) * r * 0.98;
      ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      ctx.fillText(String(i * 10), cx - Math.sin(a) * r * 0.68, cy - Math.cos(a) * r * 0.68);
    }
    ctx.font = "bold 18px sans-serif"; ctx.fillStyle = "#ffb000"; ctx.fillText("km/h", cx, cy + r * 0.45);
  });
  TX.eye = canvasTex(128, 128, function (ctx, w, h) {
    var c = w / 2, rs = [0.5, 0.36, 0.24, 0.11], cs = ["#16328a", "#f4f6ff", "#3b8cff", "#05070d"], i;
    for (i = 0; i < rs.length; i++) { ctx.fillStyle = cs[i]; ctx.beginPath(); ctx.arc(c, c, w * rs[i], 0, TAU); ctx.fill(); }
  });

  
  
  
  var _up = new THREE.Vector3(0, 1, 0);

  function add(parent, geo, mat, x, y, z, shadow) {
    var m = new THREE.Mesh(geo, mat);
    m.position.set(x || 0, y || 0, z || 0);
    if (shadow) m.castShadow = true;
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  
  function rod(parent, p1, p2, r, mat, seg) {
    var a = new THREE.Vector3(p1[0], p1[1], p1[2]);
    var b = new THREE.Vector3(p2[0], p2[1], p2[2]);
    var dir = b.clone().sub(a);
    var len = dir.length();
    if (len < 1e-5) return null;
    var m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg || 8, 1), mat);
    m.position.copy(a).add(b).multiplyScalar(0.5);
    m.quaternion.setFromUnitVectors(_up, dir.normalize());
    m.userData.noCollision = true;
    parent.add(m);
    return m;
  }
  
  function rboxGeo(w, h, d, r) {
    var b = Math.max(0.002, Math.min(r || 0.02, w * 0.4, h * 0.4, d * 0.4));
    var iw = Math.max(0.001, w - 2 * b), ih = Math.max(0.001, h - 2 * b), id = Math.max(0.001, d - 2 * b);
    var s = new THREE.Shape();
    s.moveTo(-iw / 2, -ih / 2); s.lineTo(iw / 2, -ih / 2); s.lineTo(iw / 2, ih / 2); s.lineTo(-iw / 2, ih / 2); s.lineTo(-iw / 2, -ih / 2);
    var g = new THREE.ExtrudeGeometry(s, { depth: id, bevelEnabled: true, bevelThickness: b, bevelSize: b, bevelSegments: 2, steps: 1 });
    g.translate(0, 0, -id / 2);
    return g;
  }
  
  function profileGeo(pts, width, bevel) {
    var s = new THREE.Shape(), i;
    for (i = 0; i < pts.length; i++) {
      if (i === 0) s.moveTo(-pts[i][0], pts[i][1]); else s.lineTo(-pts[i][0], pts[i][1]);
    }
    s.lineTo(-pts[0][0], pts[0][1]);
    var b = bevel || 0.03, depth = Math.max(0.001, width - 2 * b);
    var g = new THREE.ExtrudeGeometry(s, { depth: depth, bevelEnabled: true, bevelThickness: b, bevelSize: b, bevelSegments: 2, steps: 1 });
    g.translate(0, 0, -depth / 2);
    g.rotateY(PI / 2);
    return g;
  }
  
  function fenderGeo(r, w, thetaStart, thetaLen) {
    var g = new THREE.CylinderGeometry(r, r, w, 24, 1, true, thetaStart, thetaLen);
    g.rotateZ(PI / 2);
    return g;
  }

  
  var geoLug = new THREE.CylinderGeometry(0.014, 0.014, 0.02, 6);
  geoLug.rotateZ(PI / 2);
  function buildWheel(R, W, name) {
    var g = new THREE.Group();
    g.name = name;
    var rimR = R * 0.62, hw = W / 2, i, a, side;
    var V = THREE.Vector2;
    var prof = [
      new V(rimR, -hw * 0.82), new V(rimR + 0.02, -hw * 0.96), new V(R - 0.06, -hw), new V(R - 0.02, -hw * 0.9),
      new V(R, -hw * 0.55), new V(R, hw * 0.55), new V(R - 0.02, hw * 0.9), new V(R - 0.06, hw),
      new V(rimR + 0.02, hw * 0.96), new V(rimR, hw * 0.82)
    ];
    var tg = new THREE.LatheGeometry(prof, 32);
    tg.rotateZ(PI / 2);
    add(g, tg, M.rubber, 0, 0, 0);
    var rg = new THREE.CylinderGeometry(rimR, rimR, W * 0.86, 24, 1, true);
    rg.rotateZ(PI / 2);
    add(g, rg, M.chrome, 0, 0, 0);
    var hubG = new THREE.CylinderGeometry(0.05, 0.05, W * 1.02, 12);
    hubG.rotateZ(PI / 2);
    add(g, hubG, M.chrome, 0, 0, 0);
    var spokeG = new THREE.BoxGeometry(0.012, rimR * 0.92, 0.035);
    for (side = -1; side <= 1; side += 2) {
      var disc = add(g, new THREE.CircleGeometry(rimR * 0.98, 24), M.rimPaint, side * hw * 0.42, 0, 0);
      disc.rotation.y = side * PI / 2;
      for (i = 0; i < 6; i++) {
        a = i * PI / 3;
        var sp = add(g, spokeG, M.chrome, side * hw * 0.46, Math.cos(a) * rimR * 0.48, Math.sin(a) * rimR * 0.48);
        sp.rotation.x = -a;
      }
      for (i = 0; i < 5; i++) {
        a = i * TAU / 5;
        add(g, geoLug, M.darkMetal, side * hw * 0.56, Math.cos(a) * rimR * 0.27, Math.sin(a) * rimR * 0.27);
      }
    }
    return g;
  }

  
  
  
  var chassis = new THREE.Group(); chassis.name = "tuk_chassis"; root.add(chassis);
  var forkGroup = new THREE.Group(); forkGroup.name = "tuk_fork"; forkGroup.position.set(0, 0, DIM.frontZ); chassis.add(forkGroup);
  var barGroup = new THREE.Group(); barGroup.name = "tuk_handlebar"; barGroup.position.set(BAR.x, BAR.y, BAR.z); chassis.add(barGroup);
  var solidMeshes = [];
  function solid(m) { m.userData.noCollision = false; m.userData.solid = true; m.userData.forceMeshCollision = true; solidMeshes.push(m); return m; }
  var sx, i, k, z0;

  
  var wheelF = buildWheel(DIM.frontR, DIM.frontW, "wheel_front");
  wheelF.position.set(0, DIM.frontR, 0); forkGroup.add(wheelF);
  var wheelRL = buildWheel(DIM.rearR, DIM.rearW, "wheel_rear_left");
  wheelRL.position.set(-DIM.rearX, DIM.rearR, 0); chassis.add(wheelRL);
  var wheelRR = buildWheel(DIM.rearR, DIM.rearW, "wheel_rear_right");
  wheelRR.position.set(DIM.rearX, DIM.rearR, 0); chassis.add(wheelRR);

  
  solid(add(chassis, rboxGeo(1.12, 0.06, 2.05, 0.02), M.darkMetal, 0, 0.37, -0.50, true));
  var floorMat = add(chassis, new THREE.PlaneGeometry(0.96, 1.15), M.mat, 0, 0.403, -0.95);
  floorMat.rotation.x = -PI / 2;
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.42, 0.30, -1.75], [sx * 0.42, 0.30, 0.95], 0.04, M.darkMetal, 8);
    rod(chassis, [sx * 0.62, 0.36, 0.15], [sx * 0.58, 0.72, 0.10], 0.022, M.chrome, 6);      
    rod(chassis, [sx * 0.62, 0.52, 0.15], [sx * 0.62, 0.62, 0.15], 0.034, M.accent, 8);      
  }
  var crossZ = [-1.3, -0.6, 0.1, 0.7];
  for (i = 0; i < crossZ.length; i++) rod(chassis, [-0.42, 0.30, crossZ[i]], [0.42, 0.30, crossZ[i]], 0.03, M.darkMetal, 6);
  rod(chassis, [-DIM.rearX, DIM.rearR, 0], [DIM.rearX, DIM.rearR, 0], 0.035, M.darkMetal, 8);

  
  var apron = add(chassis, profileGeo([
    [-1.15, 0.40], [-1.15, 1.18], [-1.50, 1.14], [-1.84, 1.02], [-1.97, 0.90],
    [-1.93, 0.76], [-1.50, 0.76], [-1.28, 0.62], [-1.20, 0.40]
  ], 0.80, 0.05), M.body, 0, 0, 0, true);
  solid(apron);
  
  var fFender = add(forkGroup, fenderGeo(0.375, 0.24, 0.05, PI + 0.30), M.body, 0, DIM.frontR, 0, true);
  
  for (sx = -1; sx <= 1; sx += 2) {
    rod(forkGroup, [sx * 0.11, DIM.frontR, 0], [sx * 0.11, 0.86, 0.07], 0.022, M.chrome, 8);
    rod(forkGroup, [sx * 0.11, 0.56, 0.035], [sx * 0.11, 0.70, 0.055], 0.034, M.darkMetal, 8);
  }
  add(forkGroup, new THREE.CylinderGeometry(0.02, 0.02, 0.24, 8).rotateZ(PI / 2), M.chrome, 0, DIM.frontR, 0);

  
  var hlHousing = add(chassis, new THREE.CylinderGeometry(0.135, 0.12, 0.12, 20).rotateX(PI / 2), M.chrome, 0, 0.93, -1.945);
  var hlRing = add(chassis, new THREE.TorusGeometry(0.13, 0.014, 8, 24), M.chrome, 0, 0.93, -2.0);
  var hlLens = add(chassis, new THREE.SphereGeometry(0.115, 20, 12, 0, TAU, 0, PI / 2).rotateX(-PI / 2), M.head, 0, 0.93, -1.995);
  for (sx = -1; sx <= 1; sx += 2) {
    var sigF = add(chassis, new THREE.SphereGeometry(0.04, 10, 8), sx < 0 ? M.sigL : M.sigR, sx * 0.34, 0.96, -1.82);
    add(chassis, new THREE.TorusGeometry(0.045, 0.008, 6, 14), M.chrome, sx * 0.34, 0.96, -1.835);
  }
  
  rod(chassis, [0, 1.05, -1.62], [0, 1.15, -1.62], 0.012, M.chrome, 6);
  var ornament = add(chassis, new THREE.TetrahedronGeometry(0.045), M.chrome, 0, 1.18, -1.62);

  
  add(chassis, rboxGeo(0.54, 0.05, 0.30, 0.015), M.darkMetal, 0, 1.205, -1.02);
  add(chassis, rboxGeo(0.24, 0.10, 0.12, 0.02), M.darkMetal, 0, 1.265, -1.06);
  var dialMat = texMat(TX.dial, 0x16202a, { roughness: 0.4 });
  var dial = add(chassis, new THREE.CircleGeometry(0.085, 28), dialMat, 0, 1.285, -0.995);
  dial.rotation.x = -0.45;
  var needleGroup = new THREE.Group();
  needleGroup.position.set(0, 1.287, -0.992);
  needleGroup.rotation.x = -0.45;
  chassis.add(needleGroup);
  var needle = add(needleGroup, new THREE.BoxGeometry(0.007, 0.07, 0.003), M.accent, 0, 0.032, 0.002);
  add(needleGroup, new THREE.CylinderGeometry(0.01, 0.01, 0.006, 10).rotateX(PI / 2), M.chrome, 0, 0, 0.003);
  var warnLamp = add(chassis, new THREE.SphereGeometry(0.012, 8, 6), M.sigR, 0.14, 1.245, -0.985);
  var warnLamp2 = add(chassis, new THREE.SphereGeometry(0.012, 8, 6), M.rev, -0.14, 1.245, -0.985);
  
  rod(chassis, [0, 1.16, -1.06], [0, 1.15, -0.90], 0.04, M.darkMetal, 10);

  
  add(barGroup, new THREE.CylinderGeometry(0.032, 0.032, 0.1, 10), M.chrome, 0, -0.045, 0);
  rod(barGroup, [-0.20, 0, 0], [0.20, 0, 0], 0.017, M.chrome, 8);
  rod(barGroup, [-0.20, 0, 0], [-GRIP.x, 0, GRIP.z], 0.017, M.chrome, 8);
  rod(barGroup, [0.20, 0, 0], [GRIP.x, 0, GRIP.z], 0.017, M.chrome, 8);
  var gripL = new THREE.Group(); gripL.position.set(-GRIP.x, 0, GRIP.z); barGroup.add(gripL);
  var gripR = new THREE.Group(); gripR.position.set(GRIP.x, 0, GRIP.z); barGroup.add(gripR);
  add(gripL, new THREE.CylinderGeometry(0.024, 0.024, 0.14, 12).rotateZ(PI / 2), M.rubber, 0, 0, 0);
  add(gripR, new THREE.CylinderGeometry(0.026, 0.026, 0.14, 12).rotateZ(PI / 2), M.rubber, 0, 0, 0);
  add(gripR, new THREE.CylinderGeometry(0.03, 0.03, 0.012, 12).rotateZ(PI / 2), M.chrome, -0.075, 0, 0);
  add(gripL, new THREE.CylinderGeometry(0.03, 0.03, 0.012, 12).rotateZ(PI / 2), M.chrome, 0.075, 0, 0);
  rod(barGroup, [-0.30, 0.012, 0.03], [-0.31, 0.02, -0.12], 0.008, M.chrome, 5);     
  rod(barGroup, [0.30, 0.012, 0.03], [0.31, 0.02, -0.12], 0.008, M.chrome, 5);       
  add(barGroup, new THREE.CylinderGeometry(0.022, 0.022, 0.05, 8), M.darkMetal, 0.20, 0.03, -0.01);   

  
  var wBL = [-0.64, 1.18, -1.15], wBR = [0.64, 1.18, -1.15], wTL = [-0.64, 2.06, -0.98], wTR = [0.64, 2.06, -0.98];
  rod(chassis, wBL, wTL, 0.024, M.chrome, 8); rod(chassis, wBR, wTR, 0.024, M.chrome, 8);
  rod(chassis, wBL, wBR, 0.024, M.chrome, 8); rod(chassis, wTL, wTR, 0.02, M.chrome, 8);
  var wsTilt = Math.atan2(0.17, 0.88);
  var windshield = add(chassis, new THREE.PlaneGeometry(1.24, 0.896), M.glass, 0, 1.62, -1.065);
  windshield.rotation.x = wsTilt;
  var bannerMat = texMat(TX.banner, 0x7a0f1c, { transparent: true, opacity: 0.95, side: THREE.DoubleSide });
  var banner = add(chassis, new THREE.PlaneGeometry(1.2, 0.14), bannerMat, 0, 1.99, -0.995);
  banner.rotation.x = wsTilt;
  
  rod(chassis, [0, 1.21, -1.145], [0.45, 1.45, -1.10], 0.007, M.darkMetal, 5);
  rod(chassis, [0.10, 1.25, -1.140], [0.42, 1.425, -1.105], 0.004, M.rubber, 4);

  
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.64, 1.36, -1.12], [sx * 0.80, 1.34, -1.24], 0.012, M.chrome, 6);
    var mh = add(chassis, rboxGeo(0.10, 0.14, 0.03, 0.01), M.darkMetal, sx * 0.82, 1.34, -1.25);
    mh.rotation.y = sx * 0.35;
    var mg = add(chassis, new THREE.PlaneGeometry(0.085, 0.12), M.mirror, sx * 0.82 + sx * 0.002, 1.34, -1.236);
    mg.rotation.y = sx * 0.35 + PI;
  }

  
  var roofMesh = add(chassis, profileGeo([
    [-1.14, 2.06], [1.00, 2.06], [0.98, 2.14], [0.80, 2.22], [0.40, 2.27], [-0.20, 2.27], [-0.80, 2.23], [-1.08, 2.15]
  ], 1.52, 0.05), M.roof, 0, 0, 0, true);
  var liner = add(chassis, new THREE.PlaneGeometry(1.44, 2.0), M.cream, 0, 2.052, -0.07);
  liner.rotation.x = PI / 2;
  add(chassis, rboxGeo(1.54, 0.04, 0.06, 0.015), M.chrome, 0, 2.07, -1.15);
  add(chassis, rboxGeo(1.54, 0.04, 0.06, 0.015), M.chrome, 0, 2.07, 1.02);
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.77, 2.07, -1.12], [sx * 0.77, 2.07, 1.0], 0.018, M.chrome, 6);
    rod(chassis, [sx * 0.66, 0.90, 0.66], [sx * 0.68, 2.06, 0.86], 0.026, M.chrome, 8);      
    rod(chassis, [sx * 0.67, 1.30, 0.63], [sx * 0.67, 1.30, -0.04], 0.016, M.chrome, 6);      
    rod(chassis, [sx * 0.67, 1.30, -0.04], [sx * 0.67, 1.05, -0.04], 0.016, M.chrome, 6);
    
    rod(chassis, [sx * 0.72, 1.98, -0.95], [sx * 0.72, 1.98, 0.85], 0.045, M.fabric, 10);
    for (k = 0; k < 3; k++) add(chassis, rboxGeo(0.02, 0.12, 0.05, 0.006), M.accent, sx * 0.72, 1.97, -0.55 + k * 0.6);
  }
  
  for (sx = -1; sx <= 1; sx += 2) {
    rod(chassis, [sx * 0.55, 2.37, -0.90], [sx * 0.55, 2.37, 0.80], 0.014, M.chrome, 6);
    var postZ = [-0.85, -0.1, 0.5, 0.78];
    for (k = 0; k < postZ.length; k++) rod(chassis, [sx * 0.55, 2.25, postZ[k]], [sx * 0.55, 2.37, postZ[k]], 0.012, M.chrome, 6);
  }
  for (k = 0; k < 4; k++) rod(chassis, [-0.55, 2.37, -0.80 + k * 0.5], [0.55, 2.37, -0.80 + k * 0.5], 0.01, M.chrome, 5);

  
  var drvBase = solid(add(chassis, rboxGeo(0.60, 0.36, 0.52, 0.04), M.darkMetal, 0, 0.58, -0.30, true));
  add(chassis, rboxGeo(0.56, 0.10, 0.48, 0.035), M.seat, 0, 0.83, -0.30);
  add(chassis, rboxGeo(1.00, 0.42, 0.09, 0.04), M.seat, 0, 1.10, -0.04);        
  var pCush = add(chassis, rboxGeo(1.10, 0.10, 0.56, 0.04), M.seat, 0, 0.85, 0.30);
  add(chassis, rboxGeo(1.10, 0.46, 0.10, 0.04), M.seat, 0, 1.10, 0.64);          
  for (k = 0; k < 3; k++) {
    rod(chassis, [-0.52 + k * 0.52, 0.89, 0.04], [-0.52 + k * 0.52, 0.89, 0.58], 0.008, M.accent, 4);
  }
  rod(chassis, [-0.28, 0.885, -0.52], [0.28, 0.885, -0.52], 0.01, M.accent, 4);
  
  add(chassis, rboxGeo(0.12, 0.02, 0.07, 0.008), M.rubber, 0.30, 0.425, -0.93);
  rod(chassis, [0.30, 0.43, -0.93], [0.30, 0.55, -1.02], 0.01, M.chrome, 5);

  
  var rearBlock = solid(add(chassis, rboxGeo(1.26, 0.40, 0.97, 0.06), M.body, 0, 0.60, 0.465, true));
  add(chassis, rboxGeo(1.26, 0.05, 0.30, 0.015), M.body, 0, 0.825, 0.82);
  var backPanel = add(chassis, rboxGeo(1.26, 0.46, 0.07, 0.03), M.body, 0, 0.62, 0.975);
  for (sx = -1; sx <= 1; sx += 2) {
    
    add(chassis, fenderGeo(0.39, 0.26, 0.05, PI - 0.1), M.body, sx * DIM.rearX, DIM.rearR, 0, true);
    
    for (k = 0; k < 6; k++) add(chassis, new THREE.BoxGeometry(0.012, 0.025, 0.2), M.darkMetal, sx * 0.635, 0.50 + k * 0.045, 0.45);
    
    add(chassis, new THREE.BoxGeometry(0.012, 0.05, 0.95), M.accent, sx * 0.634, 0.74, 0.465);
    add(chassis, new THREE.BoxGeometry(0.012, 0.025, 0.95), M.cream, sx * 0.634, 0.69, 0.465);
    
    add(chassis, rboxGeo(0.14, 0.04, 1.0, 0.012), M.darkMetal, sx * 0.60, 0.41, -0.55);
    
    add(chassis, rboxGeo(0.20, 0.22, 0.012, 0.004), M.rubber, sx * DIM.rearX, 0.20, 0.38);
    
    add(chassis, rboxGeo(0.03, 0.03, 1.55, 0.008), M.led, sx * 0.575, 0.33, -0.55);
    
    var sticker = add(chassis, new THREE.PlaneGeometry(0.52, 0.13), texMat(TX.side, 0x222222, { transparent: true, side: THREE.DoubleSide }), sx * 0.642, 0.60, 0.465);
    sticker.rotation.y = sx * PI / 2;
  }
  rod(chassis, [-0.58, 0.30, 1.00], [0.58, 0.30, 1.00], 0.014, M.led, 6);
  
  rod(chassis, [-0.35, 0.33, -1.50], [0.35, 0.33, -1.50], 0.014, M.led, 6);

  
  var plateMat = texMat(TX.plate, 0xf2f2ec, { roughness: 0.5 });
  add(chassis, rboxGeo(0.50, 0.25, 0.012, 0.006), M.darkMetal, 0, 0.62, 1.017);
  var plate = add(chassis, new THREE.PlaneGeometry(0.46, 0.21), plateMat, 0, 0.62, 1.024);
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, rboxGeo(0.16, 0.12, 0.03, 0.01), M.chrome, sx * 0.52, 0.78, 1.02);
    add(chassis, rboxGeo(0.12, 0.08, 0.03, 0.008), M.tail, sx * 0.52, 0.78, 1.04);
    add(chassis, new THREE.SphereGeometry(0.03, 8, 6), sx < 0 ? M.sigL : M.sigR, sx * 0.52, 0.68, 1.04);
    add(chassis, new THREE.CircleGeometry(0.03, 10), M.rev, sx * 0.30, 0.78, 1.015);
    rod(chassis, [sx * 0.58, 0.44, 1.06], [sx * 0.64, 0.44, 0.92], 0.032, M.chrome, 8);
    rod(chassis, [sx * 0.50, 0.40, 1.02], [sx * 0.50, 0.44, 1.06], 0.014, M.darkMetal, 6);
  }
  rod(chassis, [-0.58, 0.44, 1.06], [0.58, 0.44, 1.06], 0.034, M.chrome, 10);
  
  var exhaustPos = new THREE.Vector3(0.50, 0.34, 1.10);
  rod(chassis, [0.50, 0.34, 0.55], [0.50, 0.34, 1.09], 0.04, M.darkMetal, 10);
  rod(chassis, [0.50, 0.34, 0.68], [0.50, 0.34, 0.98], 0.07, M.chrome, 12);
  add(chassis, new THREE.TorusGeometry(0.043, 0.008, 6, 14), M.chrome, 0.50, 0.34, 1.095);

  
  var speakers = [];
  for (sx = -1; sx <= 1; sx += 2) {
    add(chassis, rboxGeo(0.40, 0.42, 0.28, 0.03), M.darkMetal, sx * 0.31, 1.06, 0.82);
    var cone = add(chassis, new THREE.CylinderGeometry(0.15, 0.09, 0.05, 20).rotateX(PI / 2), M.spkCone, sx * 0.31, 0.98, 0.965);
    add(chassis, new THREE.TorusGeometry(0.16, 0.011, 8, 28), M.spkLed, sx * 0.31, 0.98, 0.968);
    add(chassis, new THREE.SphereGeometry(0.035, 10, 8), M.chrome, sx * 0.31, 0.98, 0.99);
    var tw = add(chassis, new THREE.CylinderGeometry(0.045, 0.03, 0.03, 12).rotateX(PI / 2), M.spkCone, sx * 0.31, 1.19, 0.965);
    add(chassis, new THREE.TorusGeometry(0.048, 0.006, 6, 16), M.spkLed, sx * 0.31, 1.19, 0.968);
    speakers.push(cone);
  }

  
  var pendant = new THREE.Group();
  pendant.position.set(0, 2.05, -0.88);
  chassis.add(pendant);
  rod(pendant, [0, 0, 0], [0, -0.14, 0], 0.003, M.chrome, 4);
  var beadColors = [0x2a7bff, 0xf4f4ff, 0x2a7bff, 0xd62839, 0xffd25a];
  for (i = 0; i < 6; i++) {
    var bead = add(pendant, new THREE.SphereGeometry(0.016, 8, 6), stdMat(beadColors[i % beadColors.length], 0.4, 0.1), 0, -0.04 - i * 0.034, 0);
  }
  var eye = add(pendant, new THREE.CircleGeometry(0.05, 20), texMat(TX.eye, 0x16328a, { side: THREE.DoubleSide }), 0, -0.29, 0);
  add(pendant, new THREE.ConeGeometry(0.02, 0.07, 8), M.accent, 0, -0.355, 0);

  
  var headSpot = null, underLight = null;
  try {
    headSpot = new THREE.SpotLight(0xfff1c8, 0, 45, 0.45, 0.5, 1.5);
    headSpot.position.set(0, 0.93, -2.0);
    headSpot.castShadow = false;
    chassis.add(headSpot);
    headSpot.target.position.set(0, 0.5, -16);
    chassis.add(headSpot.target);
    underLight = new THREE.PointLight(0x00e5ff, 1.0, 5, 2);
    underLight.position.set(0, 0.12, -0.45);
    chassis.add(underLight);
  } catch (e) { headSpot = null; underLight = null; }

  
  var SMOKE_N = 8;
  var smokeGeo = new THREE.SphereGeometry(0.08, 8, 6);
  var puffs = [];
  for (i = 0; i < SMOKE_N; i++) {
    var pm = new THREE.Mesh(smokeGeo, M.smoke.clone());
    pm.visible = false; pm.userData.noCollision = true;
    root.add(pm);
    puffs.push({ mesh: pm, pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0, max: 1 });
  }

  
  var wallList = [];

  
  
  
  var lastParamKey = "";
  function setCol(mat, str) { try { mat.color.set(str); } catch (e) {} }
  function refreshParams(dt, force) {
    S.paramT += dt;
    if (!force && S.paramT < 0.4) return;
    S.paramT = 0;
    var key = [PS("bodyColor", "#1e9e55"), PS("roofColor", "#f4c20d"), PS("accentColor", "#d62839"), PS("bannerText", ""), PS("plateText", "")].join("|");
    if (key === lastParamKey) return;
    lastParamKey = key;
    setCol(M.body, PS("bodyColor", "#1e9e55"));
    setCol(M.roof, PS("roofColor", "#f4c20d"));
    setCol(M.accent, PS("accentColor", "#d62839"));
    setCol(M.rimPaint, PS("accentColor", "#d62839"));
    redrawTex(TX.plate); redrawTex(TX.banner);
  }

  
  
  
  var AU = { ctx: null, o1: null, o2: null, lfo: null, filt: null, master: null, vol: 0.5 };
  function audioStart() {
    if (AU.ctx || !PB("soundOn", true)) return;
    try {
      var AC = (typeof window !== "undefined") ? (window.AudioContext || window.webkitAudioContext) : null;
      if (!AC) return;
      var ctx = new AC();
      var master = ctx.createGain(); master.gain.value = 0.0001; master.connect(ctx.destination);
      var pulse = ctx.createGain(); pulse.gain.value = 0.6; pulse.connect(master);
      var filt = ctx.createBiquadFilter(); filt.type = "lowpass"; filt.frequency.value = 500; filt.connect(pulse);
      var o1 = ctx.createOscillator(); o1.type = "sawtooth"; o1.frequency.value = 48;
      var o2 = ctx.createOscillator(); o2.type = "square"; o2.frequency.value = 24;
      var g1 = ctx.createGain(); g1.gain.value = 0.5;
      var g2 = ctx.createGain(); g2.gain.value = 0.35;
      o1.connect(g1); g1.connect(filt); o2.connect(g2); g2.connect(filt);
      var lfo = ctx.createOscillator(); lfo.type = "sine"; lfo.frequency.value = 12;
      var lfoGain = ctx.createGain(); lfoGain.gain.value = 0.4;
      lfo.connect(lfoGain); lfoGain.connect(pulse.gain);
      o1.start(); o2.start(); lfo.start();
      if (ctx.state === "suspended" && typeof ctx.resume === "function") ctx.resume();
      AU.ctx = ctx; AU.o1 = o1; AU.o2 = o2; AU.lfo = lfo; AU.filt = filt; AU.master = master;
    } catch (e) { AU.ctx = null; }
  }
  function audioUpdate(dt) {
    if (!AU.ctx) return;
    try {
      var vol = clamp(PN("soundVolume", 0.5), 0, 1);
      var active = (S.mode === "riding" || S.mode === "mounting");
      var rpm = 0.18 + clamp(Math.abs(S.v) / Math.max(1, PN("maxSpeed", 18)), 0, 1) * 0.75 + (S.throttleOn ? 0.12 : 0);
      var t = AU.ctx.currentTime;
      AU.o1.frequency.setTargetAtTime(38 + rpm * 70, t, 0.08);
      AU.o2.frequency.setTargetAtTime(19 + rpm * 35, t, 0.08);
      AU.lfo.frequency.setTargetAtTime(9 + rpm * 30, t, 0.1);
      AU.filt.frequency.setTargetAtTime(260 + rpm * 900, t, 0.1);
      AU.master.gain.setTargetAtTime(active ? vol * 0.16 * (0.6 + rpm * 0.6) : 0.0001, t, 0.15);
    } catch (e) {}
  }
  function audioHorn() {
    if (!AU.ctx || !PB("soundOn", true)) return;
    try {
      var ctx = AU.ctx, t0 = ctx.currentTime, vol = clamp(PN("soundVolume", 0.5), 0, 1) * 0.12, b;
      for (b = 0; b < 2; b++) {
        var st = t0 + b * 0.22;
        var og = ctx.createGain(); og.gain.value = 0.0001; og.connect(ctx.destination);
        var a = ctx.createOscillator(); a.type = "square"; a.frequency.value = 430;
        var c = ctx.createOscillator(); c.type = "square"; c.frequency.value = 540;
        a.connect(og); c.connect(og);
        og.gain.setValueAtTime(0.0001, st);
        og.gain.linearRampToValueAtTime(vol, st + 0.02);
        og.gain.setValueAtTime(vol, st + 0.13);
        og.gain.linearRampToValueAtTime(0.0001, st + 0.16);
        a.start(st); c.start(st); a.stop(st + 0.2); c.stop(st + 0.2);
      }
    } catch (e) {}
  }
  function audioStop(immediate) {
    if (!AU.ctx) return;
    var ctx = AU.ctx;
    try { AU.master.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.08); } catch (e) {}
    AU.ctx = null;
    var closer = function () { try { AU.o1.stop(); AU.o2.stop(); AU.lfo.stop(); } catch (e) {} try { ctx.close(); } catch (e2) {} };
    if (immediate || typeof setTimeout !== "function") closer(); else setTimeout(closer, 350);
  }

  
  
  
  var mouse = { down: false, dx: 0, dy: 0, wheel: 0, lastX: null, lastY: null };
  function onMouseDown() { mouse.down = true; mouse.lastX = null; }
  function onMouseUp() { mouse.down = false; mouse.lastX = null; }
  function onMouseMove(e) {
    if (S.mode === "idle") return;
    var locked = (typeof document !== "undefined") && !!document.pointerLockElement;
    if (!locked && !mouse.down) { mouse.lastX = null; return; }
    var mx = e.movementX, my = e.movementY;
    if (mx === undefined || my === undefined) {
      if (mouse.lastX !== null) { mx = e.clientX - mouse.lastX; my = e.clientY - mouse.lastY; } else { mx = 0; my = 0; }
      mouse.lastX = e.clientX; mouse.lastY = e.clientY;
    }
    mouse.dx += mx; mouse.dy += my;
  }
  function onWheel(e) { if (S.mode !== "idle") mouse.wheel += (e.deltaY || 0); }
  if (typeof window !== "undefined" && window.addEventListener) {
    window.addEventListener("mousedown", onMouseDown, true);
    window.addEventListener("mouseup", onMouseUp, true);
    window.addEventListener("mousemove", onMouseMove, true);
    window.addEventListener("wheel", onWheel, { passive: true, capture: true });
  }

  
  
  
  var _tmpA = new THREE.Vector3(), _tmpB = new THREE.Vector3(), _seatW = new THREE.Vector3(), _camT = new THREE.Vector3(), _ray = null;
  var LN = null;

  function ensureMatrices() {
    if (S.matFrame === S.frameNo) return;
    S.matFrame = S.frameNo;
    root.updateMatrixWorld(true);
  }
  function playerWorldPos(out) {
    var lp = call("getLocalPlayer");
    if (!lp) return null;
    var m = lp.mesh;
    if (m && typeof m.getWorldPosition === "function") { m.getWorldPosition(out); return out; }
    if (lp.position) { out.set(lp.position.x || 0, lp.position.y || 0, lp.position.z || 0); return out; }
    return null;
  }
  function placePlayer(x, y, z) {
    if (typeof Game.setPlayerPosition === "function") { call("setPlayerPosition", 0, x, y, z, { hold: true }); return; }
    var lp = call("getLocalPlayer");
    if (lp && lp.mesh) lp.mesh.position.set(x, y, z);
  }
  function setPlayerYawSafe(yaw) {
    if (typeof Game.setPlayerYaw === "function") { call("setPlayerYaw", 0, yaw); return; }
    var lp = call("getLocalPlayer");
    if (lp && lp.mesh) lp.mesh.rotation.y = yaw;
  }
  function seatWorld(out) {
    ensureMatrices();
    _tmpA.set(SEAT.x, SEAT.y + PN("riderLift", 0), SEAT.z);
    out.copy(_tmpA);
    chassis.localToWorld(out);
    return out;
  }
  function riderYaw() {
    return S.yaw + S.yawFix + PN("riderYawOffsetDeg", 0) * PI / 180;
  }
  
  function calibrateYaw() {
    if (S.yawFixTries >= 4 || S.t - S.yawFixT < 0.12) return;
    var f = call("getPlayerForward", 0);
    if (!f) return;
    var fx = (f.x !== undefined) ? f.x : f[0], fz = (f.z !== undefined) ? f.z : (f.y !== undefined && f.length === undefined ? f.y : f[1]);
    if (!isFinite(fx) || !isFinite(fz) || (Math.abs(fx) + Math.abs(fz)) < 1e-4) return;
    S.yawFixT = S.t;
    var wantX = -Math.sin(S.yaw), wantZ = -Math.cos(S.yaw);
    var diff = wrap(Math.atan2(wantX, wantZ) - Math.atan2(fx, fz));
    if (Math.abs(diff) > 0.06) { S.yawFix = wrap(S.yawFix + diff); S.yawFixTries++; }
    else S.yawFixTries = 99;
  }
  function resolveLimbNames() {
    function pick(c) {
      for (var j = 0; j < c.length; j++) { if (call("getBone", 0, c[j])) return c[j]; }
      return c[0];
    }
    LN = {
      rArm: "rightArm", lArm: "leftArm", rLeg: "rightLeg", lLeg: "leftLeg",
      rFore: pick(["rightForearm", "rightLowerArm", "rightElbow"]),
      lFore: pick(["leftForearm", "leftLowerArm", "leftElbow"]),
      rShin: pick(["rightShin", "rightLowerLeg", "rightCalf", "rightKnee"]),
      lShin: pick(["leftShin", "leftLowerLeg", "leftCalf", "leftKnee"]),
      outR: -1
    };
    var b = call("getBone", 0, "rightArm");
    if (b && b.position && Math.abs(b.position.x) > 0.02) LN.outR = sgn(b.position.x);
  }
  function limb(name, rx, ry, rz) { call("setPlayerLimb", 0, name, rx, ry, rz, { lock: true }); }
  function limbFree(name) { call("setPlayerLimb", 0, name, 0, 0, 0, { lock: false }); }

  
  function gripLocal(side, out) {
    var gx = side * GRIP.x, c = Math.cos(S.barAngle), s = Math.sin(S.barAngle);
    out.set(BAR.x + gx * c + GRIP.z * s, BAR.y + GRIP.y, BAR.z - gx * s + GRIP.z * c);
    return out;
  }
  
  var _armOut = [0, 0, 0];
  function solveArm(side, outSign) {
    gripLocal(side, _tmpB);
    var shx = SEAT.x + side * RIDER.shoulderX, shy = SEAT.y + RIDER.shoulderY, shz = SEAT.z;
    var f = -(_tmpB.z - shz), u = _tmpB.y - shy, lOut = (_tmpB.x - shx) * side;
    var r = Math.sqrt(f * f + lOut * lOut);
    var gamma = Math.atan2(lOut, f);
    var L1 = RIDER.upperArm, L2 = RIDER.foreArm;
    var D = Math.sqrt(r * r + u * u);
    var Dmax = (L1 + L2) * 0.985, Dmin = Math.abs(L1 - L2) + 0.03;
    var Dc = clamp(D, Dmin, Dmax);
    var cosA = clamp((L1 * L1 + Dc * Dc - L2 * L2) / (2 * L1 * Dc), -1, 1);
    var A = Math.acos(cosA);
    var cosE = clamp((L1 * L1 + L2 * L2 - Dc * Dc) / (2 * L1 * L2), -1, 1);
    var E = Math.acos(cosE);
    var thetaT = Math.atan2(r, -u);
    var au = thetaT - A;
    var aFwd = Math.sin(au) * Math.cos(gamma), aOut = Math.sin(au) * Math.sin(gamma), aDown = Math.cos(au);
    _armOut[0] = -Math.atan2(aFwd, aDown);
    _armOut[1] = Math.asin(clamp(outSign * aOut, -1, 1));
    _armOut[2] = -(PI - E);
    return _armOut;
  }
  
  function applyRiderPose(blend) {
    if (!LN) resolveLimbNames();
    var flip = PB("flipArmSide", false) ? -1 : 1;
    var outR = LN.outR * flip, outL = -LN.outR * flip;
    var kn = PB("flipKnee", false) ? -1 : 1;
    var a = solveArm(1, outR);
    limb(LN.rArm, a[0] * blend, 0, a[1] * blend);
    limb(LN.rFore, a[2] * blend, 0, 0);
    a = solveArm(-1, outL);
    limb(LN.lArm, a[0] * blend, 0, a[1] * blend);
    limb(LN.lFore, a[2] * blend, 0, 0);
    limb(LN.rLeg, RIDER.thighRx * blend, 0, outR * RIDER.kneeSpread * blend);
    limb(LN.lLeg, RIDER.thighRx * blend, 0, outL * RIDER.kneeSpread * blend);
    limb(LN.rShin, RIDER.shinRx * kn * blend, 0, 0);
    limb(LN.lShin, RIDER.shinRx * kn * blend, 0, 0);
  }
  function releaseRiderPose() {
    if (!LN) return;
    limbFree(LN.rArm); limbFree(LN.lArm); limbFree(LN.rFore); limbFree(LN.lFore);
    limbFree(LN.rLeg); limbFree(LN.lLeg); limbFree(LN.rShin); limbFree(LN.lShin);
  }

  
  
  
  function isOwn(o) { while (o) { if (o === root) return true; o = o.parent; } return false; }
  function wallFlag(o) {
    var n = 0;
    while (o && n < 4) {
      var u = o.userData;
      if (u) {
        if (u.walkable || u.isFloor) return false;
        if (u.isWall || u.blocksPlayer) return true;
      }
      o = o.parent; n++;
    }
    return false;
  }
  function rebuildWalls() {
    wallList.length = 0;
    S.wallT = S.t;
    var sc = Game.scene;
    if (!sc || typeof sc.traverse !== "function") return;
    try {
      sc.traverse(function (o) { if (o.isMesh && o.visible !== false && !isOwn(o) && wallFlag(o)) wallList.push(o); });
    } catch (e) {}
  }
  var RAY_FRONT = [[0, 0.7, -2.4], [-0.6, 0.7, -1.3], [0.6, 0.7, -1.3]];
  var RAY_REAR = [[0, 0.7, 1.15], [-0.6, 0.7, 0.95], [0.6, 0.7, 0.95]];
  function obstacleDistance(dirSign, reach) {
    if (!wallList.length) return Infinity;
    if (!_ray) _ray = new THREE.Raycaster();
    var set = dirSign < 0 ? RAY_FRONT : RAY_REAR, best = Infinity, j;
    var dx = -Math.sin(S.yaw) * (dirSign < 0 ? 1 : -1), dz = -Math.cos(S.yaw) * (dirSign < 0 ? 1 : -1);
    _tmpA.set(dx, 0, dz);
    for (j = 0; j < set.length; j++) {
      _tmpB.set(set[j][0], set[j][1], set[j][2]);
      root.localToWorld(_tmpB);
      _ray.set(_tmpB, _tmpA);
      _ray.near = 0; _ray.far = reach;
      var hits = _ray.intersectObjects(wallList, false);
      if (hits.length && hits[0].distance < best) best = hits[0].distance;
    }
    return best;
  }

  
  
  
  function physicsStep(dt, thr, brk, left, right, hb) {
    var maxV = PN("maxSpeed", 18), revMax = PN("reverseMaxSpeed", 5);
    var acc = PN("accel", 6.5), brakeP = PN("brakePower", 15), hbP = PN("handbrakePower", 24);
    var rolling = PN("rolling", 1.4), drag = PN("drag", 0.12);
    var v = S.v, a = 0;
    S.throttleOn = thr; S.brakeOn = false; S.reverseOn = false;

    if (thr) {
      if (v < -0.2) { a += brakeP; S.brakeOn = true; }
      else a += acc * (1 - clamp(v / maxV, 0, 1));
    }
    if (brk) {
      if (v > 0.2) { a -= brakeP; S.brakeOn = true; }
      else { a -= acc * 0.7 * (1 - clamp(-v / revMax, 0, 1)); S.reverseOn = true; }
    }
    if (!thr && !brk) a -= sgn(v) * (rolling + drag * Math.abs(v));
    else a -= sgn(v) * drag * Math.abs(v) * 0.4;
    if (hb) { a -= sgn(v) * hbP; S.brakeOn = true; }
    var nv = v + a * dt;
    if ((!thr && !brk || hb) && sgn(nv) !== sgn(v) && v !== 0) nv = 0;
    nv = clamp(nv, -revMax, maxV);
    S.accel = (nv - v) / dt;
    S.v = nv;

    
    var steerMaxRad = PN("steerMaxDeg", 36) * PI / 180;
    var sIn = (left ? 1 : 0) - (right ? 1 : 0);
    var resp = PN("steerResponse", 7);
    S.steerIn = damp(S.steerIn, sIn, sIn === 0 ? resp * 1.4 : resp, dt);
    var speedK = smooth(0, 1, Math.abs(S.v) / Math.max(1, maxV));
    S.steerVis = S.steerIn * steerMaxRad * (1 - 0.45 * speedK);
    var dLim = Math.atan(DIM.wheelBase * PN("maxLateralAccel", 9) / (S.v * S.v + 0.5));
    S.steerEff = sgn(S.steerVis) * Math.min(Math.abs(S.steerVis), dLim);
    S.yawRate = (S.v / DIM.wheelBase) * Math.tan(S.steerEff);
    S.lat = S.yawRate * S.v;
    S.yaw += S.yawRate * dt;

    
    var eh = root.userData.engineHit;
    if (eh) {
      root.userData.engineHit = null;
      var dn = (-Math.sin(S.yaw) * eh.nx - Math.cos(S.yaw) * eh.nz) * sgn(S.v);
      if (dn < -0.15 && Math.abs(S.v) > 0.5) { if (Math.abs(S.v) > 5) S.camShake = Math.min(1, Math.abs(S.v) / 12); S.v *= (1 + dn * 0.6); }
    }
    
    if (PB("collision", true) && Math.abs(S.v) > 0.3) {
      if (S.t - S.wallT > 3) rebuildWalls();
      S.collT += dt;
      if (S.collT > 0.04) {
        S.collT = 0;
        var reach = Math.abs(S.v) * 0.12 + 0.35;
        var dist = obstacleDistance(sgn(S.v) > 0 ? -1 : 1, reach);
        if (dist < Math.abs(S.v) * 0.08 + 0.18) {
          S.camShake = Math.min(1, Math.abs(S.v) / 12);
          S.v = -S.v * 0.2;
        }
      }
    }
    var step = S.v * dt;
    root.position.x += -Math.sin(S.yaw) * step;
    root.position.z += -Math.cos(S.yaw) * step;
    root.rotation.y = S.yaw;
  }

  
  function updateChassisVisuals(dt, bobAmp) {
    var lean = PN("leanAmount", 0.009), sr = PN("suspensionRate", 9);
    var rollT = clamp(-S.lat * lean, -0.12, 0.12);
    var pitchT = clamp(S.accel * 0.006, -0.06, 0.05);
    S.roll = damp(S.roll, rollT, sr, dt);
    S.pitch = damp(S.pitch, pitchT, sr, dt);
    var vk = clamp(Math.abs(S.v) / Math.max(1, PN("maxSpeed", 18)), 0, 1);
    var engineOn = (S.mode !== "idle");
    var bob = engineOn ? (Math.sin(S.t * 62) * 0.0016 + Math.sin(S.t * 27) * 0.004 * vk) * bobAmp : 0;
    chassis.rotation.x = S.pitch;
    chassis.rotation.z = S.roll;
    chassis.position.y = bob;
    
    S.wSpinR -= S.v / DIM.rearR * dt;
    S.wSpinF -= S.v / DIM.frontR * dt;
    wheelRL.rotation.x = S.wSpinR; wheelRR.rotation.x = S.wSpinR; wheelF.rotation.x = S.wSpinF;
    
    forkGroup.rotation.y = S.steerVis;
    S.barAngle = S.steerVis * BAR_RATIO;
    barGroup.rotation.y = S.barAngle;
    S.throttleVis = damp(S.throttleVis, S.throttleOn ? 1 : 0, 10, dt);
    gripR.rotation.x = -S.throttleVis * 0.5;
    
    var kmh = Math.abs(S.v) * 3.6;
    needleGroup.rotation.z = lerp(2.094, -2.094, clamp(kmh / 80, 0, 1)) + (engineOn ? Math.sin(S.t * 40) * 0.01 : 0);
  }
  
  function measuredVisuals(dt) {
    var dx = root.position.x - S.lastPos.x, dz = root.position.z - S.lastPos.z;
    var fx = -Math.sin(root.rotation.y), fz = -Math.cos(root.rotation.y);
    var v = (dx * fx + dz * fz) / dt;
    var yr = wrap(root.rotation.y - S.lastYawMeasured) / dt;
    S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y;
    v = clamp(v, -40, 40);
    S.accel = damp(S.accel, (v - S.v) / dt, 10, dt);
    S.v = damp(S.v, v, 12, dt);
    S.yaw = root.rotation.y;
    S.yawRate = yr;
    S.lat = yr * S.v;
    var steer = (Math.abs(S.v) > 0.5) ? Math.atan(yr * DIM.wheelBase / S.v) : 0;
    S.steerVis = damp(S.steerVis, clamp(steer, -0.65, 0.65), 8, dt);
    S.throttleOn = false; S.brakeOn = false; S.reverseOn = false;
    updateChassisVisuals(dt, 0);
  }

  
  
  
  function releaseCamera() {
    if (typeof Game.clearCamera === "function") call("clearCamera", 0);
    else call("setCamera", 0, null);
  }
  function cameraFrame(dt) {
    var sens = PN("camSensitivity", 0.0045), keyRate = PN("camKeySpeed", 1.8);
    var any = false;
    if (down("ArrowLeft")) { S.camAzOff += keyRate * dt; any = true; }
    if (down("ArrowRight")) { S.camAzOff -= keyRate * dt; any = true; }
    if (down("ArrowUp")) { S.camPitch += keyRate * 0.6 * dt; any = true; }
    if (down("ArrowDown")) { S.camPitch -= keyRate * 0.6 * dt; any = true; }
    if (mouse.dx !== 0 || mouse.dy !== 0) {
      S.camAzOff -= mouse.dx * sens; S.camPitch += mouse.dy * sens;
      mouse.dx = 0; mouse.dy = 0; any = true;
    }
    if (mouse.wheel !== 0) {
      S.camDistUser = clamp(S.camDistUser * Math.exp(mouse.wheel * 0.0012), 0.4, 2.6);
      mouse.wheel = 0; any = true;
    }
    if (any) S.lastCamInput = S.t;
    S.camPitch = clamp(S.camPitch, -0.05, 1.35);
    S.camAzOff = wrap(S.camAzOff);
    var defPitch = PN("camHeightDeg", 16) * PI / 180;
    
    if (S.t - S.lastCamInput > PN("camRecenterDelay", 2.5) && Math.abs(S.v) > 1.0) {
      S.camAzOff = damp(S.camAzOff, 0, 1.6, dt);
      S.camPitch = damp(S.camPitch, defPitch, 1.2, dt);
    }
    S.camYaw = S.camYaw + wrap(S.yaw - S.camYaw) * (1 - Math.exp(-PN("camFollow", 4.5) * dt));
    var az = S.camYaw + S.camAzOff;
    var maxV = Math.max(1, PN("maxSpeed", 18));
    var vk = clamp(Math.abs(S.v) / maxV, 0, 1);
    var dist = PN("camDistance", 6.5) * S.camDistUser * (1 + 0.08 * vk);
    ensureMatrices();
    _camT.set(0, 1.35, -0.45);
    chassis.localToWorld(_camT);
    var cp = Math.cos(S.camPitch);
    var cx = _camT.x + Math.sin(az) * cp * dist;
    var cy = _camT.y + Math.sin(S.camPitch) * dist;
    var cz = _camT.z + Math.cos(az) * cp * dist;
    cy = Math.max(cy, spawnPos.y + 0.45);
    if (S.camShake > 0.01) {
      cx += (Math.random() - 0.5) * 0.25 * S.camShake; cy += (Math.random() - 0.5) * 0.2 * S.camShake;
      S.camShake = damp(S.camShake, 0, 7, dt);
    }
    var fov = PN("camFov", 62) + PN("speedFovBoost", 8) * vk;
    call("setCamera", 0, { x: cx, y: cy, z: cz, lookX: _camT.x, lookY: _camT.y + 0.15, lookZ: _camT.z, fov: fov, lerp: clamp(PN("camLerp", 0.4), 0.05, 1) });
    
    if (PB("roofFade", true)) {
      var op = lerp(1, 0.22, smooth(0.10, 0.38, S.camPitch));
      M.roof.opacity = damp(M.roof.opacity, op, 8, dt);
      M.roof.depthWrite = M.roof.opacity > 0.97;
    } else { M.roof.opacity = 1; M.roof.depthWrite = true; }
  }

  
  
  
  function setBodyCollision(on) {
    for (var j = 0; j < solidMeshes.length; j++) {
      solidMeshes[j].userData.noCollision = !on;
      solidMeshes[j].userData.solid = !!on;
    }
  }
  function myName() { return String(call("getMyName") || "me"); }
  function startMount() {
    var cur = call("getShared", DRV_KEY, "");
    if (cur && cur !== myName()) return;
    if (!playerWorldPos(S.mountFrom)) return;
    S.lastToggle = S.t;
    S.mode = "mounting"; S.modeT = 0; S.v = 0; S.yaw = root.rotation.y; S.camYaw = S.yaw + 0.0;
    S.camAzOff = 0; S.camPitch = PN("camHeightDeg", 16) * PI / 180; S.camDistUser = 1; S.lastCamInput = -99;
    S.yawFixTries = (S.yawFixTries >= 99) ? 99 : 0;
    call("lockPlayer", 0, true);
    call("lockPlayerAnim", 0, true);
    call("setShared", DRV_KEY, myName());
    setBodyCollision(false);
    audioStart();
    rebuildWalls();
    S.fPrev = down("KeyF");
  }
  function startDismount() {
    S.lastToggle = S.t;
    S.mode = "dismounting"; S.modeT = 0;
    ensureMatrices();
    _tmpA.set(-1.30, 0, 0.10);
    root.localToWorld(_tmpA);
    S.exitPos.set(_tmpA.x, root.position.y, _tmpA.z);
  }
  function finishDismount() {
    S.mode = "idle"; S.modeT = 0;
    releaseRiderPose();
    var lp = call("getLocalPlayer");
    var ex = S.exitPos.x, ey = S.exitPos.y, ez = S.exitPos.z;
    if (typeof Game.teleportPlayer === "function") call("teleportPlayer", 0, ex, ey, ez, { hold: 300, yaw: S.yaw });
    else {
      call("holdPlayerPosition", 0, false);
      if (lp && lp.mesh) lp.mesh.position.set(ex, ey, ez);
    }
    call("holdPlayerPosition", 0, false);
    call("unlockPlayerAnim", 0);
    call("lockPlayer", 0, false);
    releaseCamera();
    call("setShared", DRV_KEY, "");
    if (PB("showHint", true)) call("subtitle", "");
    setBodyCollision(true);
    audioStop(false);
    M.roof.opacity = 1; M.roof.depthWrite = true;
    S.throttleOn = false;
    S.coast = Math.abs(S.v) > 0.05;
    S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y;
  }
  function requestToggle() {
    if (S.t - S.lastToggle < 0.45) return;
    if (S.mode === "idle") startMount();
    else if (S.mode === "riding") startDismount();
  }
  
  function forceExit() {
    if (S.mode === "idle") return;
    S.mode = "idle";
    releaseRiderPose();
    call("holdPlayerPosition", 0, false);
    call("unlockPlayerAnim", 0);
    call("lockPlayer", 0, false);
    releaseCamera();
    call("setShared", DRV_KEY, "");
    setBodyCollision(true);
  }

  var interactOK = false;
  if (typeof Game.registerInteractAction === "function") {
    try {
      Game.registerInteractAction(root, {
        id: "tuktuk_ride", label: "اضغط F للركوب", icon: "🛺", priority: 5,
        radius: PN("interactRadius", 3.4),
        onActivate: function () { requestToggle(); }
      });
      interactOK = true;
    } catch (e) { interactOK = false; }
  }

  
  
  
  function idleFrame(dt) {
    
    var f = down("KeyF");
    if (!interactOK && f && !S.fPrev) {
      var pp = playerWorldPos(_tmpB);
      if (pp) {
        var dx = pp.x - root.position.x, dz = pp.z - root.position.z;
        if (Math.sqrt(dx * dx + dz * dz) < PN("interactRadius", 3.4)) requestToggle();
      }
    }
    S.fPrev = f;
    if (S.coast) {
      physicsStep(dt, false, false, false, false, false);
      updateChassisVisuals(dt, 0);
      S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y;
      if (Math.abs(S.v) < 0.05) { S.v = 0; S.coast = false; }
    } else {
      measuredVisuals(dt);
    }
  }
  function mountFrame(dt) {
    var e = smooth(0, 1, S.modeT / MOUNT_TIME);
    S.steerIn = damp(S.steerIn, 0, 8, dt);
    physicsStep(dt, false, false, false, false, false);
    updateChassisVisuals(dt, 1);
    seatWorld(_seatW);
    var px = lerp(S.mountFrom.x, _seatW.x, e);
    var pz = lerp(S.mountFrom.z, _seatW.z, e);
    var py = lerp(S.mountFrom.y, _seatW.y, e) + Math.sin(PI * e) * 0.35;
    placePlayer(px, py, pz);
    if (e > 0.25) setPlayerYawSafe(riderYaw());
    if (e > 0.5) calibrateYaw();
    applyRiderPose(e);
    if (S.modeT >= MOUNT_TIME) {
      S.mode = "riding"; S.modeT = 0; S.lastToggle = S.t;
      if (PB("showHint", true)) {
        call("subtitle", "W/S قيادة · A/D توجيه · Space فرامل يد · H كلاكس · الماوس/الأسهم للكاميرا · F نزول");
        S.hintT = S.t + 6;
      }
    }
  }
  function ridingFrame(dt) {
    var fk = down("KeyF");
    if (fk && !S.fPrev) requestToggle();
    S.fPrev = fk;
    var hk = down("KeyH");
    if (hk && !S.hPrev) audioHorn();
    S.hPrev = hk;
    if (S.mode !== "riding") return;
    physicsStep(dt, down("KeyW"), down("KeyS"), down("KeyA"), down("KeyD"), down("Space"));
    updateChassisVisuals(dt, 1);
    seatWorld(_seatW);
    placePlayer(_seatW.x, _seatW.y, _seatW.z);
    setPlayerYawSafe(riderYaw());
    if (S.modeT < 1.5) calibrateYaw();
    applyRiderPose(1);
    if (S.hintT > 0 && S.t > S.hintT) { S.hintT = -1; call("subtitle", ""); }
  }
  function dismountFrame(dt) {
    var e = smooth(0, 1, S.modeT / DISMOUNT_TIME);
    physicsStep(dt, false, false, false, false, true);
    updateChassisVisuals(dt, 1);
    seatWorld(_seatW);
    var px = lerp(_seatW.x, S.exitPos.x, e), pz = lerp(_seatW.z, S.exitPos.z, e);
    var py = lerp(_seatW.y, S.exitPos.y, e) + Math.sin(PI * e) * 0.3;
    placePlayer(px, py, pz);
    applyRiderPose(1 - e);
    if (S.modeT >= DISMOUNT_TIME) finishDismount();
  }

  
  
  
  var pend = { ax: 0, vx: 0, az: 0, vz: 0 };
  var _col = new THREE.Color();
  function emitPuff() {
    var p = null, j;
    for (j = 0; j < puffs.length; j++) { if (puffs[j].life <= 0) { p = puffs[j]; break; } }
    if (!p) return;
    ensureMatrices();
    p.pos.copy(exhaustPos);
    chassis.localToWorld(p.pos);
    var bx = Math.sin(S.yaw), bz = Math.cos(S.yaw);
    p.vel.set(bx * (0.6 + Math.abs(S.v) * 0.05) + (Math.random() - 0.5) * 0.3, 0.5 + Math.random() * 0.3, bz * (0.6 + Math.abs(S.v) * 0.05) + (Math.random() - 0.5) * 0.3);
    p.max = 0.9 + Math.random() * 0.5; p.life = p.max;
    p.mesh.visible = true;
  }
  function updateSmoke(dt) {
    var j, p, anyAlive = false;
    if (S.mode === "riding" || S.mode === "mounting") {
      S.smokeT -= dt;
      if (S.smokeT <= 0) { emitPuff(); S.smokeT = S.throttleOn ? 0.09 : 0.32; }
    }
    for (j = 0; j < puffs.length; j++) {
      p = puffs[j];
      if (p.life <= 0) continue;
      anyAlive = true;
      p.life -= dt;
      if (p.life <= 0) { p.mesh.visible = false; continue; }
      p.pos.x += p.vel.x * dt; p.pos.y += p.vel.y * dt; p.pos.z += p.vel.z * dt;
      var k2 = 1 - p.life / p.max;
      _tmpA.copy(p.pos);
      root.worldToLocal(_tmpA);
      p.mesh.position.copy(_tmpA);
      var sc = 0.5 + k2 * 2.4;
      p.mesh.scale.set(sc, sc, sc);
      p.mesh.material.opacity = (1 - k2) * 0.32;
    }
    return anyAlive;
  }
  function ambient(dt) {
    var active = (S.mode !== "idle");
    
    if (PB("ledRainbow", true)) _col.setHSL((S.t * 0.1) % 1, 1, 0.55);
    else _col.set(PS("ledColor", "#00e5ff"));
    M.led.color.copy(_col);
    var beat = 0.5 + 0.5 * Math.sin(S.t * 9.0);
    M.spkLed.color.copy(_col).multiplyScalar(0.5 + (active ? 0.5 * beat : 0.1));
    if (underLight) { underLight.color.copy(_col); underLight.intensity = active ? 1.3 : 0.7; }
    var j, sc2 = 1 + (active ? 0.05 * beat : 0);
    for (j = 0; j < speakers.length; j++) speakers[j].scale.set(sc2, 1, sc2);
    
    if (headSpot) headSpot.intensity = (PB("headlights", true) && active) ? 2.6 : 0;
    M.head.emissiveIntensity = (PB("headlights", true) && active) ? 1.6 : 0.25;
    
    M.tail.emissiveIntensity = S.brakeOn ? 2.2 : (active ? 0.7 : 0.25);
    M.rev.emissiveIntensity = S.reverseOn ? 1.6 : 0.05;
    var blink = (Math.floor(S.t * 3) % 2 === 0) ? 1 : 0;
    M.sigL.emissiveIntensity = (active && S.steerIn > 0.4) ? 1.8 * blink : 0.05;
    M.sigR.emissiveIntensity = (active && S.steerIn < -0.4) ? 1.8 * blink : 0.05;
    
    var tx = clamp(-S.accel * 0.012, -0.5, 0.5), tz = clamp(S.lat * 0.02, -0.5, 0.5);
    pend.vx += (-30 * (pend.ax - tx) - 3.2 * pend.vx) * dt; pend.ax += pend.vx * dt;
    pend.vz += (-30 * (pend.az - tz) - 3.2 * pend.vz) * dt; pend.az += pend.vz * dt;
    pendant.rotation.x = clamp(pend.ax, -0.8, 0.8);
    pendant.rotation.z = clamp(pend.az, -0.8, 0.8);
    ornament.rotation.y += dt * 0.8;
    updateSmoke(dt);
  }

  
  
  
  function netSync(dt) {
    if (S.mode === "idle" && Math.abs(S.v) < 0.05) return;
    S.syncT += dt;
    if (S.syncT >= 0.05) { S.syncT = 0; call("syncObject", root); }
  }
  function cleanup() {
    if (S.cleaned) return;
    S.cleaned = true;
    try { forceExit(); } catch (e) {}
    try { audioStop(true); } catch (e) {}
    try {
      if (typeof window !== "undefined" && window.removeEventListener) {
        window.removeEventListener("mousedown", onMouseDown, true);
        window.removeEventListener("mouseup", onMouseUp, true);
        window.removeEventListener("mousemove", onMouseMove, true);
        window.removeEventListener("wheel", onWheel, true);
      }
    } catch (e) {}
    try { root.position.copy(spawnPos); root.rotation.y = spawnYaw; } catch (e) {}
    try { root.userData.__tukCleanup = null; } catch (e) {}
  }
  root.userData.__tukCleanup = cleanup;

  function frame(dt) {
    S.frameNo++;
    refreshParams(dt, false);
    if (S.mode === "idle") idleFrame(dt);
    else if (S.mode === "mounting") mountFrame(dt);
    else if (S.mode === "riding") ridingFrame(dt);
    else if (S.mode === "dismounting") dismountFrame(dt);
    ambient(dt);
    if (S.mode !== "idle") { cameraFrame(dt); S.lastPos.copy(root.position); S.lastYawMeasured = root.rotation.y; }
    netSync(dt);
    audioUpdate(dt);
  }

  refreshParams(0, true);
  S.paramT = 0;

  Game.onUpdate(function (dt) {
    if (!root.parent) { cleanup(); return false; }
    if (S.cleaned) return false;
    dt = (dt > 0) ? Math.min(dt, 0.05) : 0.016;
    S.t += dt;
    S.modeT += dt;
    try { frame(dt); } catch (err) {
      if (!S.errLogged) { S.errLogged = true; try { console.error("tuktuk:", err); } catch (e2) {} }
    }
  });
})(typeof Game !== "undefined" ? Game : null, typeof root !== "undefined" ? root : null);
