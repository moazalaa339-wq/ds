(function (Game, root) {
  "use strict";
  if (!Game || !root || typeof Game.onUpdate !== "function") return;
  var THREE = Game.THREE || (typeof window !== "undefined" ? window.THREE : null);
  if (!THREE) return;

  try { root.userData.instanceName = "مشهد_المكعب_الإجباري"; } catch (e) {}
  try {
    if (typeof root.userData.__sceneCleanup === "function") root.userData.__sceneCleanup();
  } catch (e) {}

  if (typeof Game.defineParams === "function") {
    Game.defineParams([
      { key: "markerColor", label: "لون المكعب الظاهر", type: "color", value: "#a78bfa" },
      { key: "markerEmissive", label: "لون الإضاءة الداخلية", type: "color", value: "#6d28d9" },
      { key: "markerSize", label: "حجم المكعب (م)", type: "number", value: 1.0, min: 0.3, max: 3, step: 0.1 },
      { key: "showMarker", label: "إظهار المكعب في الاختبار", type: "boolean", value: true },

      { key: "triggerRadius", label: "مسافة اللمس (متر)", type: "number", value: 1.4, min: 0.5, max: 6, step: 0.1 },
      { key: "triggerOnce", label: "يتشغل مرة واحدة بس", type: "boolean", value: true },

      { key: "useTukRide", label: "تفعيل مشهد التوك توك", type: "boolean", value: true },
      { key: "tukName", label: "اسم التوك توك (زي ما هو في قائمة الكائنات)", type: "text", value: "توك_توك_واقعي" },
      { key: "walkTimeout", label: "أقصى وقت للمشي للتوك توك (ثانية)", type: "number", value: 14, min: 2, max: 60, step: 0.5 },
      { key: "driveSec", label: "أقصى مدة للقيادة (ثانية)", type: "number", value: 10, min: 1, max: 120, step: 0.5 },
      { key: "stopSpeedTime", label: "يوقف لو التوك توك وقف لمدة (ثانية)", type: "number", value: 1.2, min: 0.2, max: 5, step: 0.1 },

      { key: "useStabScene", label: "تفعيل مشهد الطعنة", type: "boolean", value: true },
      { key: "drawSec", label: "مدة سحب السيف (ثانية)", type: "number", value: 1.2, min: 0.3, max: 4, step: 0.1 },
      { key: "stabSec", label: "مدة الطعنة (ثانية)", type: "number", value: 0.4, min: 0.1, max: 2, step: 0.05 },
      { key: "fallSec", label: "مدة السقوط (ثانية)", type: "number", value: 1.0, min: 0.3, max: 3, step: 0.1 },
      { key: "pullbackDist", label: "ابتعاد الكاميرا في المشهد (متر)", type: "number", value: 6, min: 2, max: 20, step: 0.5 },
      { key: "camLerp", label: "نعومة الكاميرا (0.01 بطيء - 1 فوري)", type: "number", value: 0.06, min: 0.01, max: 1, step: 0.01 },
      { key: "swordColor", label: "لون السيف", type: "color", value: "#c9ced6" },
      { key: "flashColor", label: "لون الفلاش والإصابة", type: "color", value: "#8b0000" },
      { key: "getUpKey", label: "زر القيام (كود المفتاح)", type: "text", value: "Space" },
      { key: "hurtMessage", label: "رسالة الإصابة", type: "text", value: "اضغط Space عشان تقوم" }
    ]);
  }

  function PR() { return Game.params || {}; }
  function PN(k, d) {
    var v = PR()[k];
    if (v === undefined || v === null || v === "") return d;
    v = Number(v);
    return isFinite(v) ? v : d;
  }
  function PB(k, d) {
    var v = PR()[k];
    if (v === undefined || v === null) return d;
    if (typeof v === "string") return v === "true" || v === "1";
    return !!v;
  }
  function PS(k, d) {
    var v = PR()[k];
    return (v === undefined || v === null || v === "") ? d : String(v);
  }
  function call(name) {
    var f = Game[name];
    if (typeof f !== "function") return undefined;
    try { return f.apply(Game, Array.prototype.slice.call(arguments, 1)); } catch (e) { return undefined; }
  }

  var S = {
    fired: false, active: false, steps: [], si: -1, cur: null, t: 0,
    tuk: null, stillT: 0, lastTuk: null, prevUp: false,
    anchor: null, fwd: { x: 0, z: 1 },
    pose: { rA: 0, rF: 0, lA: 0, sp: 0 },
    sword: null, overlay: null, cleaned: false, paramT: 0, time: 0
  };

  function lerp(a, b, k) { return a + (b - a) * k; }
  function ease(k) { return k * k * (3 - 2 * k); }
  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
  function dist2(a, b) { var dx = a.x - b.x, dz = a.z - b.z; return Math.sqrt(dx * dx + dz * dz); }
  function snap(v) { return { x: v.x, y: v.y, z: v.z }; }
  function ppos() {
    var p = call("getLocalPlayer");
    return p && p.position ? snap(p.position) : null;
  }
  function posOf(o) {
    if (!o) return null;
    var c = o.position || (o.root && o.root.position) || (o.mesh && o.mesh.position) || (o.group && o.group.position);
    return c ? snap(c) : null;
  }
  function getFwd() {
    var f = call("getPlayerForward");
    if (!f) return { x: 0, z: 1 };
    var l = Math.sqrt(f.x * f.x + f.z * f.z) || 1;
    return { x: f.x / l, z: f.z / l };
  }
  function up(p, h) { return { x: p.x, y: p.y + h, z: p.z }; }
  function addV(p, f, s, dy) { return { x: p.x + f.x * s, y: p.y + (dy || 0), z: p.z + f.z * s }; }
  function side(f) { return { x: f.z, z: -f.x }; }

  // شكل مرئي إلزامي تحت root — بدون ده الكائن يظهر «هوا»
  var markerMat = new THREE.MeshStandardMaterial({
    color: PS("markerColor", "#a78bfa"),
    emissive: PS("markerEmissive", "#6d28d9"),
    emissiveIntensity: 0.45,
    roughness: 0.35,
    metalness: 0.25
  });
  var marker = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), markerMat);
  marker.position.y = 0.5;
  marker.castShadow = true;
  marker.receiveShadow = true;
  marker.userData.noCollision = true;
  root.add(marker);

  var ringMat = new THREE.MeshBasicMaterial({
    color: PS("markerEmissive", "#6d28d9"),
    transparent: true,
    opacity: 0.55,
    side: THREE.DoubleSide,
    depthWrite: false
  });
  var ring = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.72, 32), ringMat);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.03;
  ring.userData.noCollision = true;
  root.add(ring);

  function refreshMarkerVisual() {
    var sz = PN("markerSize", 1);
    marker.scale.set(sz, sz, sz);
    marker.position.y = sz * 0.5;
    markerMat.color.set(PS("markerColor", "#a78bfa"));
    markerMat.emissive.set(PS("markerEmissive", "#6d28d9"));
    ringMat.color.set(PS("markerEmissive", "#6d28d9"));
    if (S.active) {
      marker.visible = false;
      ring.visible = false;
    } else {
      marker.visible = true;
      ring.visible = true;
      if (!PB("showMarker", true)) {
        markerMat.transparent = true;
        markerMat.opacity = 0.35;
      } else {
        markerMat.transparent = false;
        markerMat.opacity = 1;
      }
    }
  }
  refreshMarkerVisual();

  function setCam(pos, look, fov) {
    call("setCamera", {
      pos: [pos.x, pos.y, pos.z],
      lookAt: [look.x, look.y, look.z],
      fov: fov || 55,
      lerp: PN("camLerp", 0.06)
    });
  }
  function setPose(p) {
    if (typeof Game.setPlayerLimb !== "function") return;
    call("setPlayerLimb", 0, "rArm", p.rA, 0, 0, { lock: true });
    call("setPlayerLimb", 0, "rForearm", p.rF, 0, 0, { lock: true });
    call("setPlayerLimb", 0, "lArm", p.lA, 0, 0, { lock: true });
    call("setPlayerLimb", 0, "spine", p.sp, 0, 0, { lock: true });
  }
  function releasePose() {
    if (typeof Game.setPlayerLimb !== "function") return;
    var names = ["rArm", "rForearm", "lArm", "spine"];
    for (var i = 0; i < names.length; i++) call("setPlayerLimb", 0, names[i], 0, 0, 0, { lock: false });
  }
  function key(code, on) { call("setKey", code, !!on); }
  function releaseMoveKeys() {
    key("KeyW", false); key("KeyA", false); key("KeyS", false); key("KeyD", false);
  }

  function makeSword() {
    var g = new THREE.Group();
    g.name = "scene_sword";
    var bladeMat = new THREE.MeshStandardMaterial({
      color: PS("swordColor", "#c9ced6"), metalness: 0.9, roughness: 0.25
    });
    var blade = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.03, 0.9), bladeMat);
    blade.position.z = 0.45;
    var guard = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 0.04, 0.04),
      new THREE.MeshStandardMaterial({ color: "#8a6d2b", metalness: 0.6, roughness: 0.4 })
    );
    guard.position.z = 0.02;
    var grip = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 0.04, 0.2),
      new THREE.MeshStandardMaterial({ color: "#2a1d17" })
    );
    grip.position.z = -0.1;
    g.add(blade, guard, grip);
    g.visible = false;
    root.add(g);
    return g;
  }
  function placeSword(pos, dir) {
    if (!S.sword) return;
    var local = new THREE.Vector3(pos.x, pos.y, pos.z);
    try {
      root.updateMatrixWorld(true);
      root.worldToLocal(local);
    } catch (e) {}
    S.sword.position.copy(local);
    var look = new THREE.Vector3(pos.x + dir.x, pos.y + (dir.y || 0), pos.z + dir.z);
    try {
      root.worldToLocal(look);
      S.sword.lookAt(look);
    } catch (e2) {
      S.sword.lookAt(S.sword.position.x + dir.x, S.sword.position.y, S.sword.position.z + dir.z);
    }
  }
  function makeOverlay() {
    if (typeof document === "undefined") return null;
    try {
      var d = document.createElement("div");
      d.setAttribute("data-script-ui", "1");
      d.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:9999;opacity:0;background:" + PS("flashColor", "#8b0000") + ";";
      document.body.appendChild(d);
      return d;
    } catch (e) { return null; }
  }
  function flash(a) {
    if (S.overlay) {
      S.overlay.style.background = PS("flashColor", "#8b0000");
      S.overlay.style.opacity = String(clamp01(a));
    }
  }

  function nextStep() {
    if (S.cur && S.cur.exit) { try { S.cur.exit(); } catch (e) {} }
    S.si++;
    S.t = 0;
    if (S.si >= S.steps.length) { S.cur = null; finish(); return; }
    S.cur = S.steps[S.si];
    if (S.cur.enter) { try { S.cur.enter(); } catch (e) {} }
  }
  function tickSteps(dt) {
    if (!S.cur) return;
    S.t += dt;
    var done = false;
    try { done = !!S.cur.tick(dt, S.t); } catch (e) { done = true; }
    if (done) nextStep();
  }

  function pressF() {
    return {
      enter: function () { key("KeyF", true); },
      tick: function (dt, t) { if (t > 0.15) key("KeyF", false); return t > 0.7; },
      exit: function () { key("KeyF", false); }
    };
  }
  function walkToTuk() {
    return {
      tick: function (dt, t) {
        var pp = ppos(), tp = posOf(S.tuk);
        if (!pp || !tp || dist2(pp, tp) < 1.8 || t > PN("walkTimeout", 14)) {
          key("KeyW", false);
          return true;
        }
        call("setPlayerYaw", 0, Math.atan2(tp.x - pp.x, tp.z - pp.z));
        key("KeyW", true);
        return false;
      },
      exit: function () { key("KeyW", false); }
    };
  }
  function driveTuk() {
    return {
      enter: function () { S.stillT = 0; S.lastTuk = null; },
      tick: function (dt, t) {
        var tp = posOf(S.tuk);
        key("KeyW", true);
        if (tp && S.lastTuk) {
          var moved = dist2(tp, S.lastTuk);
          S.stillT = moved < 0.01 ? S.stillT + dt : 0;
        }
        if (tp) S.lastTuk = tp;
        if (t > PN("driveSec", 10) || (t > 1.5 && S.stillT > PN("stopSpeedTime", 1.2))) {
          key("KeyW", false);
          return true;
        }
        return false;
      },
      exit: function () { key("KeyW", false); }
    };
  }

  function lockForScene() {
    return {
      enter: function () {
        releaseMoveKeys();
        key("KeyF", false);
        call("lockPlayer", 0, true);
        call("lockPlayerAnim", 0, true);
        S.anchor = ppos() || { x: 0, y: 0, z: 0 };
        S.fwd = getFwd();
        S.pose = { rA: 0, rF: 0, lA: 0, sp: 0 };
        if (!S.sword) S.sword = makeSword();
        if (S.sword) S.sword.visible = true;
        marker.visible = false;
        ring.visible = false;
      },
      tick: function (dt, t) { setPose(S.pose); return t > 0.1; }
    };
  }
  function pullBack() {
    return {
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd, D = PN("pullbackDist", 6);
        var e = ease(clamp01(t / 1.6));
        var cam = addV(up(a, 2.2 + 1.2 * e), f, -D * (0.4 + 0.6 * e));
        setCam(cam, up(a, 1.2), 55);
        setPose(S.pose);
        return t >= 1.6;
      }
    };
  }
  function drawSword() {
    return {
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd, D = PN("pullbackDist", 6);
        var e = ease(clamp01(t / PN("drawSec", 1.2)));
        S.pose.rA = lerp(0, 1.9, e);
        S.pose.rF = lerp(0, -0.5, e);
        setPose(S.pose);
        placeSword(addV(up(a, 1.0), f, -0.35 - 0.1 * e), f);
        setCam(addV(up(a, 1.8), side(f), D * 0.7), up(a, 1.1), 55);
        return t >= PN("drawSec", 1.2);
      }
    };
  }
  function raiseSword() {
    return {
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd, D = PN("pullbackDist", 6);
        var e = ease(clamp01(t / 0.7));
        S.pose.rA = lerp(1.9, -1.6, e);
        S.pose.rF = lerp(-0.5, -0.2, e);
        setPose(S.pose);
        placeSword(addV(up(a, 1.4), f, 0.6), f);
        setCam(addV(up(a, 1.8), side(f), D * 0.7), up(a, 1.1), 55);
        return t >= 0.7;
      }
    };
  }
  function stab() {
    return {
      enter: function () { S.flashed = false; },
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd;
        var k = clamp01(t / PN("stabSec", 0.4)), e = k * k;
        S.pose.rA = lerp(-1.6, -2.3, e);
        S.pose.sp = lerp(0, 0.4, e);
        setPose(S.pose);
        placeSword(addV(up(a, lerp(1.4, 1.0, e)), f, lerp(0.6, 0.05, e)), f);
        setCam(addV(up(a, 1.6), side(f), 1.6), up(a, 1.1), 45);
        if (k >= 1 && !S.flashed) { S.flashed = true; flash(0.9); }
        return t >= PN("stabSec", 0.4);
      }
    };
  }
  function impact() {
    return {
      tick: function (dt, t) {
        var a = S.anchor, D = PN("pullbackDist", 6);
        var ang = t * 0.9, R = D * 0.5;
        var cam = { x: a.x + Math.cos(ang) * R, y: a.y + 1.6, z: a.z + Math.sin(ang) * R };
        setCam(cam, up(a, 1.1), 55);
        flash(0.9 - t * 1.2);
        setPose(S.pose);
        return t >= 1.0;
      },
      exit: function () { flash(0); }
    };
  }
  function fall() {
    return {
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd;
        var e = ease(clamp01(t / PN("fallSec", 1.0)));
        S.pose.sp = lerp(0.4, 1.45, e);
        S.pose.rA = lerp(-2.3, 0.6, e);
        S.pose.lA = lerp(0, 0.6, e);
        S.pose.rF = lerp(-0.2, 0, e);
        setPose(S.pose);
        placeSword(addV(a, f, 0.2, 0.1), f);
        setCam(addV(up(a, 0.8), f, -1.8), up(a, 0.3), 60);
        return t >= PN("fallSec", 1.0);
      }
    };
  }
  function hurtWait() {
    return {
      enter: function () {
        S.prevUp = !!(call("isKeyDown", PS("getUpKey", "Space")));
        call("subtitle", PS("hurtMessage", "اضغط Space عشان تقوم"));
      },
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd;
        setPose(S.pose);
        var push = Math.min(0.6, t * 0.1);
        setCam(addV(up(a, 0.9), f, -(1.8 - push)), up(a, 0.3), 60);
        flash(0.25 + 0.15 * Math.sin(t * 4));
        var down = !!(call("isKeyDown", PS("getUpKey", "Space")));
        var press = down && !S.prevUp;
        S.prevUp = down;
        return t > 0.8 && press;
      },
      exit: function () { flash(0); call("subtitle", ""); }
    };
  }
  function getUp() {
    return {
      tick: function (dt, t) {
        var a = S.anchor, f = S.fwd;
        var e = ease(clamp01(t / 0.9));
        S.pose.sp = lerp(1.45, 0, e);
        S.pose.rA = lerp(0.6, 0, e);
        S.pose.lA = lerp(0.6, 0, e);
        S.pose.rF = lerp(0, 0, e);
        setPose(S.pose);
        setCam(addV(up(a, 2.2), f, -3.2), up(a, 1.1), 55);
        return t >= 0.9;
      }
    };
  }

  function buildSteps() {
    var list = [];
    if (PB("useTukRide", true)) {
      if (S.tuk) list.push(walkToTuk(), pressF(), driveTuk(), pressF());
      else call("subtitle", "التوك توك مش موجود باسم: " + PS("tukName", "توك_توك_واقعي"));
    }
    if (PB("useStabScene", true)) {
      list.push(lockForScene(), pullBack(), drawSword(), raiseSword(), stab(), impact(), fall(), hurtWait(), getUp());
    }
    return list;
  }
  function start() {
    S.fired = true;
    S.active = true;
    S.tuk = PB("useTukRide", true)
      ? call("findByName", PS("tukName", "توك_توك_واقعي"))
      : null;
    S.steps = buildSteps();
    S.si = -1; S.cur = null; S.t = 0;
    if (S.steps.length === 0) { S.active = false; return; }
    nextStep();
  }
  function finish() {
    releaseMoveKeys();
    key("KeyF", false);
    releasePose();
    call("lockPlayerAnim", 0, false);
    call("lockPlayer", 0, false);
    call("clearCamera");
    if (S.sword) S.sword.visible = false;
    flash(0);
    S.active = false;
    S.steps = [];
    refreshMarkerVisual();
    if (!PB("triggerOnce", true)) S.fired = false;
  }
  function cleanup() {
    if (S.cleaned) return;
    S.cleaned = true;
    S.active = false;
    S.cur = null;
    releaseMoveKeys();
    key("KeyF", false);
    try { releasePose(); } catch (e) {}
    try { call("lockPlayer", 0, false); } catch (e) {}
    try { call("lockPlayerAnim", 0, false); } catch (e) {}
    try { call("clearCamera"); } catch (e) {}
    try { call("subtitle", ""); } catch (e) {}
    if (S.overlay && S.overlay.parentNode) {
      try { S.overlay.parentNode.removeChild(S.overlay); } catch (e) {}
    }
    S.overlay = null;
    S.sword = null;
  }
  root.userData.__sceneCleanup = cleanup;
  S.overlay = makeOverlay();

  Game.onUpdate(function (dt) {
    if (!root.parent) { cleanup(); return false; }
    if (S.cleaned) return false;
    var step = Math.min(0.05, dt || 0.016);
    S.paramT += step;
    S.time += step;
    if (S.paramT > 0.4) {
      S.paramT = 0;
      if (!S.active) refreshMarkerVisual();
    }
    if (!S.active && marker.visible) {
      markerMat.emissiveIntensity = 0.42 + 0.12 * Math.sin(S.time * 3);
      ring.rotation.z += step * 0.8;
    }

    if (!S.active) {
      if (PB("triggerOnce", true) && S.fired) return;
      var pp = ppos();
      if (!pp) return;
      var rp = new THREE.Vector3();
      try { root.getWorldPosition(rp); } catch (e) { return; }
      if (dist2(pp, rp) <= PN("triggerRadius", 1.4) && Math.abs(pp.y - rp.y) < 2.5) start();
      return;
    }
    tickSteps(step);
  });
})(typeof Game !== "undefined" ? Game : null, typeof root !== "undefined" ? root : null);
